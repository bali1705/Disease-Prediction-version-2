"""Safe handling of uploaded report files: type sniffing, size limits and guaranteed cleanup."""
from __future__ import annotations

import logging
import os
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

from PIL import Image

from .validation import ValidationError

log = logging.getLogger(__name__)

ALLOWED = {
    "pdf": "application/pdf", "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "webp": "image/webp",
}
Image.MAX_IMAGE_PIXELS = 40_000_000  # refuse decompression bombs


def sniff_type(head: bytes) -> str | None:
    if head.startswith(b"%PDF-"):
        return "application/pdf"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if head.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
        return "image/webp"
    return None


def validate_upload(filename: str, data: bytes, max_bytes: int) -> str:
    """Return the verified MIME type or raise ValidationError."""
    ext = (filename or "").rsplit(".", 1)[-1].lower() if "." in (filename or "") else ""
    if ext not in ALLOWED:
        raise ValidationError("Upload a PDF, JPG, PNG or WEBP file.")
    if not data:
        raise ValidationError("The file is empty.")
    if len(data) > max_bytes:
        raise ValidationError(f"The file is larger than {max_bytes // (1024 * 1024)} MB.")
    mime = sniff_type(data[:16])
    if mime is None or mime != ALLOWED[ext]:
        raise ValidationError("The file contents don't match its extension. Upload the original PDF or image.")
    return mime


def verify_image(path: Path) -> None:
    try:
        with Image.open(path) as img:
            img.verify()
        with Image.open(path) as img:
            if img.width < 200 or img.height < 200:
                raise ValidationError("The image is too small to read. Upload a clearer photo or scan.")
    except ValidationError:
        raise
    except Exception as exc:
        raise ValidationError("The image could not be opened. Upload a JPG, PNG or WEBP photo of the report.") from exc


@contextmanager
def temporary_upload(upload_dir: Path, data: bytes, suffix: str):
    """Write bytes to a uniquely named private temp file and always delete it afterwards."""
    upload_dir.mkdir(parents=True, exist_ok=True)
    path = upload_dir / f"{uuid.uuid4().hex}.{suffix}"
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        yield path
    finally:
        try:
            path.unlink(missing_ok=True)
        except OSError:  # pragma: no cover
            log.warning("could not delete temp upload %s", path)


def sweep_stale(upload_dir: Path, max_age_s: int = 600) -> int:
    """Delete any leftover uploads older than max_age_s (e.g. after a worker crash)."""
    removed = 0
    if not upload_dir.exists():
        return 0
    cutoff = time.time() - max_age_s
    for p in upload_dir.iterdir():
        try:
            if p.is_file() and p.name != ".gitkeep" and p.stat().st_mtime < cutoff:
                p.unlink()
                removed += 1
        except OSError:
            continue
    return removed
