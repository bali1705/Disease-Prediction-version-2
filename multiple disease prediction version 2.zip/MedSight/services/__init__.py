"""Application services: biomarkers, report parsing, assessment fusion, AI assistant, uploads, validation."""
