"""Reference ranges, organ mapping and plain-language explanations for vitals and lab biomarkers.

Ranges are typical adult reference intervals used for *screening display only*;
individual labs differ slightly. Status: "normal" (green), "borderline" (amber),
"high_risk" (red).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

ORGANS = {
    "brain": "Brain & nerves", "thyroid": "Thyroid", "lungs": "Lungs", "heart": "Heart",
    "arteries": "Blood vessels & cholesterol", "liver": "Liver", "stomach": "Stomach",
    "pancreas": "Pancreas & blood sugar", "kidneys": "Kidneys", "intestines": "Intestines",
    "bladder": "Bladder & urinary tract", "blood": "Blood & immunity", "skin": "Skin",
    "joints": "Joints & muscles", "body": "Whole body",
}


@dataclass
class Marker:
    key: str
    label: str
    unit: str
    organ: str
    about: str
    high_means: str
    low_means: str
    normal: dict  # {"any": (lo, hi)} or {"male": (...), "female": (...)}; hi is exclusive
    borderline: dict  # same keys -> list of (lo, hi) intervals
    plausible: tuple  # values outside are rejected as extraction errors
    aliases: list = field(default_factory=list)
    step: float = 1

    def ranges_for(self, sex: str | None):
        sex = sex if sex in ("male", "female") else None
        normal = self.normal.get(sex) or self.normal.get("any") or self.normal.get("male")
        border = self.borderline.get(sex) or self.borderline.get("any") or self.borderline.get("male") or []
        return normal, border


def _m(key, label, unit, organ, about, high, low, normal, borderline, plausible, aliases, step=1):
    if not isinstance(normal, dict):
        normal = {"any": normal}
    if not isinstance(borderline, dict):
        borderline = {"any": borderline}
    return Marker(key, label, unit, organ, about, high, low, normal, borderline, plausible, aliases, step)


INF = math.inf
MARKERS: dict[str, Marker] = {m.key: m for m in [
    # ---- Vitals --------------------------------------------------------------------------------------
    _m("heart_rate", "Heart rate", "bpm", "heart",
       "How many times your heart beats per minute at rest.",
       "A fast resting pulse can come from fever, dehydration, anxiety, anaemia, thyroid over-activity or a heart rhythm problem.",
       "A slow pulse is normal in fit people but can also signal a conduction problem or medication effect.",
       (60, 101), [(50, 60), (101, 121)], (20, 260), ["heart rate", "pulse rate", "pulse"]),
    _m("systolic_bp", "Systolic blood pressure", "mmHg", "heart",
       "The top number of a blood-pressure reading: pressure in your arteries when the heart beats.",
       "Raised values strain the heart, kidneys and blood vessels over time and increase stroke risk.",
       "Low values can cause dizziness or fainting, especially when standing.",
       (90, 120), [(120, 140), (80, 90)], (50, 280), ["systolic"]),
    _m("diastolic_bp", "Diastolic blood pressure", "mmHg", "heart",
       "The bottom number of a blood-pressure reading: pressure while the heart relaxes between beats.",
       "Raised values are part of high blood pressure (hypertension).",
       "Low values are usually harmless unless you feel faint.",
       (60, 80), [(80, 90), (50, 60)], (25, 180), ["diastolic"]),
    _m("spo2", "Oxygen saturation (SpO₂)", "%", "lungs",
       "How much of your blood's haemoglobin is carrying oxygen, usually measured with a finger clip.",
       "", "Low oxygen can mean a lung, heart or breathing problem. Below 92% needs prompt medical attention.",
       (95, 100.01), [(92, 95)], (50, 100.01), ["spo2", "sp o2", "oxygen saturation", "o2 saturation", "saturation"]),
    _m("temperature", "Body temperature", "°C", "body",
       "Your core body temperature.",
       "A temperature of 38 °C or more is a fever, most often from an infection.",
       "A low temperature can occur with cold exposure or, rarely, severe illness.",
       (36.1, 37.6), [(37.6, 38.4), (35.0, 36.1)], (30, 44), ["body temperature", "temperature", "temp"], 0.1),
    _m("respiratory_rate", "Breathing rate", "breaths/min", "lungs",
       "How many breaths you take per minute at rest.",
       "Fast breathing can come from fever, lung infection, asthma, anxiety or heart strain.",
       "Very slow breathing can be caused by sedating medicines.",
       (12, 21), [(21, 25), (9, 12)], (4, 70), ["respiratory rate", "resp rate", "breathing rate"]),
    _m("bmi", "Body-mass index", "kg/m²", "body",
       "Weight relative to height. A rough guide to whether weight is in a healthy range.",
       "A higher BMI raises the risk of diabetes, high blood pressure and heart disease.",
       "A low BMI can mean under-nutrition or an underlying illness causing weight loss.",
       (18.5, 25), [(25, 30), (17, 18.5)], (10, 80), ["bmi", "body mass index"], 0.1),
    # ---- Blood sugar ---------------------------------------------------------------------------------
    _m("fasting_glucose", "Fasting blood glucose", "mg/dL", "pancreas",
       "Blood sugar after at least 8 hours without food.",
       "100–125 mg/dL suggests prediabetes; 126 or more on two tests suggests diabetes.",
       "Below 70 mg/dL is low blood sugar (hypoglycaemia) and can cause shakiness, sweating or confusion.",
       (70, 100), [(100, 126), (54, 70)], (10, 1500),
       ["fasting blood sugar", "fasting plasma glucose", "fasting blood glucose", "fasting glucose",
        "glucose fasting", "glucose, fasting", "glucose (fasting)", "blood sugar fasting", "fbs", "fbg", "fpg"]),
    _m("random_glucose", "Post-meal / random glucose", "mg/dL", "pancreas",
       "Blood sugar measured after a meal or at any time of day.",
       "140–199 mg/dL two hours after food suggests prediabetes; 200 or more suggests diabetes.",
       "Below 70 mg/dL is low blood sugar.",
       (70, 140), [(140, 200), (54, 70)], (10, 1500),
       ["post prandial blood sugar", "postprandial glucose", "post prandial", "postprandial", "ppbs",
        "pp blood sugar", "glucose pp", "glucose (pp)", "random blood sugar", "random blood glucose",
        "random glucose", "glucose random", "rbs", "2 hr glucose", "2-hour glucose", "blood glucose", "glucose",
        "blood sugar"]),
    _m("hba1c", "HbA1c", "%", "pancreas",
       "Your average blood sugar over the past 2–3 months.",
       "5.7–6.4% suggests prediabetes; 6.5% or more is in the diabetes range.", "",
       (0, 5.7), [(5.7, 6.5)], (3, 20),
       ["hba1c", "hb a1c", "glycated haemoglobin", "glycated hemoglobin", "glycosylated haemoglobin",
        "glycosylated hemoglobin", "a1c"], 0.1),
    _m("insulin", "Insulin", "µU/mL", "pancreas",
       "The hormone that moves sugar from blood into cells.",
       "High fasting insulin often signals insulin resistance, an early step towards type 2 diabetes.",
       "Low insulin with high sugar can mean the pancreas is not producing enough.",
       (2, 25), [(25, 40)], (0.1, 1000), ["fasting insulin", "serum insulin", "insulin"]),
    # ---- Lipids --------------------------------------------------------------------------------------
    _m("total_cholesterol", "Total cholesterol", "mg/dL", "arteries",
       "All the cholesterol carried in your blood.",
       "High levels can build up as plaque in the arteries, raising heart-attack and stroke risk.", "",
       (0, 200), [(200, 240)], (50, 1000),
       ["total cholesterol", "cholesterol total", "cholesterol, total", "serum cholesterol", "cholesterol"]),
    _m("ldl", "LDL ('bad') cholesterol", "mg/dL", "arteries",
       "The cholesterol most likely to clog arteries.",
       "Higher LDL means more plaque build-up over time.", "",
       (0, 130), [(130, 160)], (10, 600),
       ["ldl cholesterol", "ldl-cholesterol", "ldl-c", "ldl", "low density lipoprotein"]),
    _m("hdl", "HDL ('good') cholesterol", "mg/dL", "arteries",
       "Cholesterol that helps carry excess cholesterol away from the arteries.", "",
       "Low HDL removes less cholesterol from the arteries and raises heart risk.",
       {"male": (40, INF), "female": (50, INF)}, {"male": [(35, 40)], "female": [(40, 50)]}, (5, 200),
       ["hdl cholesterol", "hdl-cholesterol", "hdl-c", "hdl", "high density lipoprotein"]),
    _m("triglycerides", "Triglycerides", "mg/dL", "arteries",
       "The main type of fat in the blood, from food and from excess calories.",
       "High levels raise heart risk and, when very high, can inflame the pancreas.", "",
       (0, 150), [(150, 200)], (10, 5000), ["triglycerides", "triglyceride", "tg"]),
    # ---- Kidneys -------------------------------------------------------------------------------------
    _m("creatinine", "Creatinine", "mg/dL", "kidneys",
       "A waste product from muscles that healthy kidneys filter out.",
       "A raised level suggests the kidneys are filtering less well, or dehydration.",
       "Low values usually just reflect lower muscle mass.",
       {"male": (0.7, 1.31), "female": (0.5, 1.11)},
       {"male": [(1.31, 2.0), (0.4, 0.7)], "female": [(1.11, 1.8), (0.3, 0.5)]}, (0.1, 25),
       ["serum creatinine", "s. creatinine", "s.creatinine", "creatinine"], 0.01),
    _m("blood_urea", "Blood urea", "mg/dL", "kidneys",
       "A waste product from protein breakdown, cleared by the kidneys.",
       "High urea can mean reduced kidney function, dehydration or a very high-protein diet.",
       "Low urea can occur with liver disease or a low-protein diet.",
       (15, 45), [(45, 80), (7, 15)], (2, 500), ["blood urea", "serum urea", "urea"]),
    _m("bun", "Blood urea nitrogen (BUN)", "mg/dL", "kidneys",
       "The nitrogen part of urea in the blood; another view of kidney clearance.",
       "High BUN suggests reduced kidney function or dehydration.", "",
       (7, 21), [(21, 40), (4, 7)], (1, 250), ["blood urea nitrogen", "urea nitrogen", "bun"]),
    _m("egfr", "eGFR", "mL/min/1.73m²", "kidneys",
       "An estimate of how much blood your kidneys filter each minute.", "",
       "60–89 can be mildly reduced; below 60 for three months or more suggests chronic kidney disease.",
       (90, INF), [(60, 90)], (1, 200), ["egfr", "estimated gfr", "e-gfr", "gfr"]),
    _m("uric_acid", "Uric acid", "mg/dL", "kidneys",
       "A breakdown product of purines from food and cells.",
       "High levels can cause gout and kidney stones.", "",
       {"male": (3.4, 7.3), "female": (2.4, 6.2)},
       {"male": [(7.3, 9.0), (2.0, 3.4)], "female": [(6.2, 8.0), (1.5, 2.4)]}, (0.5, 25),
       ["serum uric acid", "uric acid"], 0.1),
    _m("sodium", "Sodium", "mmol/L", "kidneys",
       "A salt that controls fluid balance and nerve signals.",
       "High sodium usually means dehydration.", "Low sodium can cause confusion, headache and weakness.",
       (135, 146), [(130, 135), (146, 150)], (100, 190), ["serum sodium", "sodium", "na+"]),
    _m("potassium", "Potassium", "mmol/L", "kidneys",
       "A salt essential for heart rhythm and muscles.",
       "High potassium can disturb heart rhythm; often linked to kidney problems or certain medicines.",
       "Low potassium causes weakness and cramps and can disturb heart rhythm.",
       (3.5, 5.1), [(3.0, 3.5), (5.1, 6.0)], (1.5, 10), ["serum potassium", "potassium", "k+"], 0.1),
    # ---- Liver ---------------------------------------------------------------------------------------
    _m("alt", "ALT (SGPT)", "U/L", "liver",
       "A liver enzyme released into blood when liver cells are irritated or damaged.",
       "Raised ALT points to liver inflammation: fatty liver, hepatitis, alcohol or medicines.", "",
       (0, 46), [(46, 135)], (1, 10000),
       ["sgpt", "alt", "alanine aminotransferase", "alanine transaminase", "alt (sgpt)", "sgpt (alt)"]),
    _m("ast", "AST (SGOT)", "U/L", "liver",
       "An enzyme found in the liver, heart and muscles.",
       "Raised AST can come from liver damage, alcohol, heart or muscle injury.", "",
       (0, 41), [(41, 120)], (1, 10000),
       ["sgot", "ast", "aspartate aminotransferase", "aspartate transaminase", "ast (sgot)", "sgot (ast)"]),
    _m("alp", "Alkaline phosphatase", "U/L", "liver",
       "An enzyme from the liver's bile ducts and from bone.",
       "High ALP can mean blocked bile flow or bone disease.", "",
       (40, 151), [(151, 300), (30, 40)], (5, 5000), ["alkaline phosphatase", "alk phos", "alp"]),
    _m("total_bilirubin", "Total bilirubin", "mg/dL", "liver",
       "A yellow pigment from old red blood cells that the liver clears into bile.",
       "Above about 2.5 mg/dL the skin and eyes may turn yellow (jaundice).", "",
       (0, 1.21), [(1.21, 2.5)], (0.05, 50),
       ["total bilirubin", "bilirubin total", "bilirubin, total", "bilirubin (total)", "s. bilirubin",
        "serum bilirubin", "bilirubin"], 0.1),
    _m("direct_bilirubin", "Direct bilirubin", "mg/dL", "liver",
       "The portion of bilirubin already processed by the liver.",
       "High direct bilirubin points to blocked bile ducts or liver-cell injury.", "",
       (0, 0.31), [(0.31, 1.0)], (0.01, 30),
       ["direct bilirubin", "bilirubin direct", "bilirubin, direct", "bilirubin (direct)", "conjugated bilirubin"],
       0.01),
    _m("albumin", "Albumin", "g/dL", "liver",
       "The main protein made by the liver; keeps fluid inside blood vessels.", "",
       "Low albumin can come from liver disease, kidney protein loss or poor nutrition.",
       (3.5, 5.6), [(3.0, 3.5)], (0.5, 8), ["serum albumin", "albumin"], 0.1),
    # ---- Blood count & inflammation ------------------------------------------------------------------
    _m("hemoglobin", "Haemoglobin", "g/dL", "blood",
       "The protein in red blood cells that carries oxygen.",
       "High values can come from dehydration, smoking or living at altitude.",
       "Low haemoglobin is anaemia: tiredness, breathlessness and pale skin.",
       {"male": (13.5, 17.6), "female": (12.0, 15.6)},
       {"male": [(11.0, 13.5), (17.6, 18.5)], "female": [(10.0, 12.0), (15.6, 16.5)]}, (2, 25),
       ["haemoglobin", "hemoglobin", "hb", "hgb"], 0.1),
    _m("wbc", "White blood cells", "×10³/µL", "blood",
       "Infection-fighting cells.",
       "A high count usually means the body is fighting an infection or inflammation.",
       "A low count can follow viral infections or some medicines and lowers defence against infection.",
       (4.0, 11.1), [(3.0, 4.0), (11.1, 15.0)], (0.1, 500),
       ["total leucocyte count", "total leukocyte count", "total wbc count", "wbc count", "total wbc", "tlc",
        "wbc", "white blood cell count", "white blood cells", "white blood cell", "leucocytes", "leukocytes"], 0.1),
    _m("platelets", "Platelets", "×10³/µL", "blood",
       "Cell fragments that help blood clot.",
       "A high count can follow inflammation or iron deficiency.",
       "A low count raises bleeding risk; it is a classic sign in dengue and some viral fevers.",
       (150, 451), [(100, 150), (451, 600)], (1, 3000),
       ["platelet count", "platelets", "platelet", "plt"]),
    _m("rbc", "Red blood cells", "million/µL", "blood",
       "The number of oxygen-carrying red cells.", "High values can come from dehydration or lung disease.",
       "Low values are usually part of anaemia.",
       {"male": (4.5, 6.2), "female": (4.0, 5.6)},
       {"male": [(4.0, 4.5), (6.2, 6.6)], "female": [(3.6, 4.0), (5.6, 6.0)]}, (1, 10),
       ["total rbc count", "rbc count", "rbc", "red blood cell count", "red blood cells", "erythrocytes"], 0.1),
    _m("hematocrit", "Haematocrit (PCV)", "%", "blood",
       "The share of your blood made up of red cells.",
       "High values can mean dehydration.", "Low values usually accompany anaemia.",
       {"male": (40, 52.1), "female": (36, 47.1)}, {"male": [(36, 40), (52.1, 56)], "female": [(32, 36), (47.1, 51)]},
       (10, 75), ["haematocrit", "hematocrit", "packed cell volume", "pcv", "hct"], 0.1),
    _m("mcv", "Mean cell volume (MCV)", "fL", "blood",
       "The average size of your red blood cells.",
       "Large cells can come from low vitamin B12/folate, alcohol or thyroid problems.",
       "Small cells usually mean iron deficiency.",
       (80, 100.1), [(70, 80), (100.1, 110)], (40, 150), ["mean corpuscular volume", "mcv"], 0.1),
    _m("crp", "C-reactive protein (CRP)", "mg/L", "blood",
       "A protein the liver releases during inflammation.",
       "A raised CRP signals active inflammation or infection somewhere in the body.", "",
       (0, 5), [(5, 10)], (0, 500), ["c-reactive protein", "c reactive protein", "hs-crp", "hscrp", "crp"], 0.1),
    _m("esr", "ESR", "mm/hr", "blood",
       "How fast red cells settle in a tube; rises with inflammation.",
       "A raised ESR suggests inflammation, infection or autoimmune disease.", "",
       (0, 21), [(21, 40)], (0, 200), ["erythrocyte sedimentation rate", "esr"]),
    # ---- Thyroid -------------------------------------------------------------------------------------
    _m("tsh", "TSH", "mIU/L", "thyroid",
       "The brain's signal telling the thyroid how hard to work.",
       "High TSH usually means an underactive thyroid (hypothyroidism).",
       "Low TSH usually means an overactive thyroid (hyperthyroidism).",
       (0.4, 4.51), [(4.51, 10), (0.1, 0.4)], (0.001, 200),
       ["thyroid stimulating hormone", "tsh", "thyrotropin"], 0.01),
    _m("free_t4", "Free T4", "ng/dL", "thyroid",
       "The main thyroid hormone circulating freely in the blood.",
       "High free T4 points to an overactive thyroid.", "Low free T4 points to an underactive thyroid.",
       (0.8, 1.81), [(0.6, 0.8), (1.81, 2.3)], (0.05, 10), ["free t4", "ft4", "free thyroxine"], 0.01),
    _m("t3", "Total T3", "ng/dL", "thyroid",
       "The active form of thyroid hormone.", "High T3 points to an overactive thyroid.",
       "Low T3 can occur with an underactive thyroid or during illness.",
       (80, 201), [(60, 80), (201, 250)], (10, 1000), ["total t3", "t3 total", "triiodothyronine", "t3"]),
    # ---- Heart injury --------------------------------------------------------------------------------
    _m("troponin", "Troponin", "ng/mL", "heart",
       "A heart-muscle protein released into blood when the heart is injured.",
       "Any rise can mean heart-muscle damage, such as a heart attack. Seek urgent care.", "",
       (0, 0.04), [(0.04, 0.4)], (0, 100),
       ["high sensitivity troponin", "hs-troponin", "troponin i", "troponin t", "trop i", "troponin"], 0.001),
]}

# Aliases that look like a marker but are something else (longest match wins, these map to nothing)
IGNORE_ALIASES = ["non-hdl", "non hdl", "mean corpuscular hemoglobin", "mean corpuscular haemoglobin", "mchc",
                  "mch", "indirect bilirubin", "free t3", "ft3", "total t4", "t4 total", "microalbumin",
                  "globulin", "creatinine clearance", "nucleated rbc", "rdw", "mpv", "vldl", "a/g ratio",
                  "glucose urine", "urine glucose", "urine sugar"]

STATUS_ORDER = {"normal": 0, "borderline": 1, "high_risk": 2}


def _fmt(x: float) -> str:
    return f"{x:g}"


def range_text(marker: Marker, sex: str | None) -> str:
    (lo, hi), _ = marker.ranges_for(sex)
    if lo <= 0:
        return f"below {_fmt(hi)} {marker.unit}"
    if hi == INF or hi >= marker.plausible[1]:
        return f"{_fmt(lo)} {marker.unit} or more"
    # Upper bounds are exclusive internally; show the last in-range value (e.g. 60–100 bpm)
    return f"{_fmt(lo)}–{_fmt(round(hi - marker.step, 4))} {marker.unit}"


def classify(key: str, value: float, sex: str | None = None) -> dict:
    marker = MARKERS[key]
    (lo, hi), border = marker.ranges_for(sex)
    if lo <= value < hi:
        status, direction = "normal", None
    else:
        direction = "low" if value < lo else "high"
        status = "borderline" if any(b_lo <= value < b_hi for b_lo, b_hi in border) else "high_risk"
    meaning = {"high": marker.high_means, "low": marker.low_means}.get(direction) or ""
    if status == "normal":
        meaning = "Within the typical reference range."
    fin = lambda x: None if x in (INF, -INF) else x  # noqa: E731 - JSON has no infinity
    return {"key": key, "label": marker.label, "value": value, "unit": marker.unit, "organ": marker.organ,
            "organ_title": ORGANS[marker.organ], "status": status, "direction": direction,
            "normal_range": range_text(marker, sex), "about": marker.about, "meaning": meaning,
            "scale": {"normal": [fin(lo), fin(hi)], "borderline": [[fin(a), fin(b)] for a, b in border],
                      "plausible": list(marker.plausible)}}


def analyze(values: dict[str, float], sex: str | None = None) -> tuple[list[dict], dict]:
    """Classify every biomarker and roll results up to organ level (worst status wins)."""
    items = [classify(k, v, sex) for k, v in values.items() if k in MARKERS]
    organs: dict[str, dict] = {}
    for it in items:
        o = organs.setdefault(it["organ"], {"organ": it["organ"], "title": ORGANS[it["organ"]],
                                            "status": "normal", "markers": []})
        o["markers"].append(it["key"])
        if STATUS_ORDER[it["status"]] > STATUS_ORDER[o["status"]]:
            o["status"] = it["status"]
    return items, organs


# ---------------------------------------------------------------------------
# Unit normalisation for values coming from reports / OCR
# ---------------------------------------------------------------------------
def normalize_value(key: str, value: float, unit: str | None = "") -> float | None:
    """Convert common alternative units to the canonical unit; return None if implausible."""
    u = (unit or "").lower().replace(" ", "")
    v = float(value)
    if key in ("fasting_glucose", "random_glucose"):
        if "mmol" in u or v < 35:
            v *= 18.016
    elif key in ("total_cholesterol", "ldl", "hdl"):
        if "mmol" in u or (key != "hdl" and v < 20) or (key == "hdl" and v < 4):
            v *= 38.67
    elif key == "triglycerides":
        if "mmol" in u or v < 15:
            v *= 88.57
    elif key == "creatinine":
        if "mol" in u or v > 25:
            v /= 88.4
    elif key == "blood_urea" and "mmol" in u:
        v *= 6.006
    elif key == "bun" and "mmol" in u:
        v *= 2.801
    elif key == "uric_acid" and ("mol" in u or v > 50):
        v /= 59.48
    elif key == "total_bilirubin" or key == "direct_bilirubin":
        if "mol" in u or v > 50:
            v /= 17.1
    elif key == "albumin" and ("g/l" in u and "dl" not in u or v > 10):
        v /= 10
    elif key == "hemoglobin" and ("g/l" in u and "dl" not in u or v > 30):
        v /= 10
    elif key == "hba1c" and ("mmol/mol" in u or v > 25):
        v = v / 10.929 + 2.15  # IFCC -> NGSP
    elif key == "wbc":
        if v > 500:  # cells/µL or /cumm
            v /= 1000
    elif key == "platelets":
        if "lakh" in u or "lac" in u or v < 10:
            v *= 100
        elif v > 5000:  # per µL
            v /= 1000
    elif key == "rbc" and v > 100:
        v /= 1e6
    elif key == "temperature" and (("f" in u and "c" not in u) or v > 50):
        v = (v - 32) * 5 / 9
    elif key == "troponin" and ("ng/l" in u or "pg/ml" in u):
        v /= 1000
    elif key == "t3" and "nmol" in u:
        v *= 65.1
    elif key == "free_t4" and "pmol" in u:
        v /= 12.87
    lo, hi = MARKERS[key].plausible
    if not (lo <= v <= hi) or math.isnan(v):
        return None
    return round(v, 3)


def catalog_for_ui() -> list[dict]:
    return [{"key": m.key, "label": m.label, "unit": m.unit, "organ": m.organ, "about": m.about,
             "normal_range": range_text(m, None), "step": m.step,
             "plausible": [m.plausible[0], m.plausible[1]]} for m in MARKERS.values()]
