"""Unified multi-disease assessment: fuses symptoms, lab biomarkers and ML model risks.

Fusion approach
---------------
1. The symptom classifier gives P(disease | symptoms) over 41 diseases.
2. Lab findings act as likelihood ratios on that distribution (e.g. low platelets
   raise dengue, a normal HbA1c lowers diabetes), followed by renormalisation.
3. Dedicated tabular models (diabetes, heart disease) add calibrated risk
   estimates when enough inputs are available.
4. Lab-only findings (anaemia, reduced kidney function, ...) are listed with a
   rule-based evidence score, clearly labelled as such.
"""
from __future__ import annotations

from ml_pipeline.predictor import registry, risk_level
from ml_pipeline.symptom_catalog import symptom_label, symptom_organ

from .biomarkers import ORGANS, STATUS_ORDER, analyze


# ---------------------------------------------------------------------------
# Lab-derived findings
# ---------------------------------------------------------------------------
def _cond(cid, name, severity, evidence, organ, specialist, tests, boosts=None, about=""):
    return {"id": cid, "name": name, "severity": severity, "evidence": evidence, "organ": organ,
            "specialist": specialist, "tests": tests, "boosts": boosts or {}, "about": about}


def lab_findings(v: dict, sex: str | None) -> tuple[list[dict], dict]:
    """Return (conditions, contradictions). Contradictions are LR<1 for diseases that normal labs argue against."""
    out: list[dict] = []
    contra: dict[str, float] = {}
    g_f, g_r, a1c = v.get("fasting_glucose"), v.get("random_glucose"), v.get("hba1c")
    ev = []
    if a1c is not None:
        ev.append(f"HbA1c {a1c:g}%")
    if g_f is not None:
        ev.append(f"fasting glucose {g_f:g} mg/dL")
    if g_r is not None:
        ev.append(f"post-meal/random glucose {g_r:g} mg/dL")
    if (a1c or 0) >= 6.5 or (g_f or 0) >= 126 or (g_r or 0) >= 200:
        out.append(_cond("diabetes_lab", "Blood sugar in the diabetes range", "high_risk", ev, "pancreas",
                         "Endocrinologist", ["Repeat fasting glucose", "HbA1c"],
                         {"Diabetes": 4.0, "Hypoglycemia": 0.5},
                         "Diabetes is confirmed when a raised result is repeated on a second test."))
    elif (a1c or 0) >= 5.7 or (g_f or 0) >= 100 or (g_r or 0) >= 140:
        out.append(_cond("prediabetes_lab", "Blood sugar above normal (prediabetes range)", "borderline", ev,
                         "pancreas", "GP / Endocrinologist", ["HbA1c", "Oral glucose tolerance test"],
                         {"Diabetes": 1.8}, "Lifestyle changes at this stage can often prevent diabetes."))
    elif ev:
        contra.update({"Diabetes": 0.35})
    if (g_f is not None and g_f < 70) or (g_r is not None and g_r < 70):
        out.append(_cond("low_glucose", "Low blood sugar", "high_risk" if min(x for x in (g_f, g_r) if x) < 54
                         else "borderline", ev, "pancreas", "GP / Endocrinologist",
                         ["Glucose during symptoms"], {"Hypoglycemia": 4.0, "Diabetes": 0.7}))

    sbp, dbp = v.get("systolic_bp"), v.get("diastolic_bp")
    if sbp is not None or dbp is not None:
        bp_ev = [f"blood pressure {sbp or '–'}/{dbp or '–'} mmHg"]
        if (sbp or 0) >= 140 or (dbp or 0) >= 90:
            out.append(_cond("hypertension_lab", "Blood pressure in the high range", "high_risk", bp_ev, "heart",
                             "Physician / Cardiologist", ["Repeat BP on 2–3 days", "Kidney function", "ECG"],
                             {"Hypertension": 4.0, "Heart attack": 1.3}))
        elif (sbp or 0) >= 130 or (dbp or 0) >= 80:
            out.append(_cond("elevated_bp", "Raised blood pressure (stage 1)", "borderline", bp_ev, "heart",
                             "GP", ["Home BP monitoring"], {"Hypertension": 2.0}))
        else:
            contra["Hypertension"] = 0.35

    ldl, hdl, tc, tg = v.get("ldl"), v.get("hdl"), v.get("total_cholesterol"), v.get("triglycerides")
    lip_ev = [f"{n} {x:g} mg/dL" for n, x in (("LDL", ldl), ("HDL", hdl), ("total cholesterol", tc),
                                               ("triglycerides", tg)) if x is not None]
    hdl_low = hdl is not None and hdl < (50 if sex == "female" else 40)
    if (ldl or 0) >= 160 or (tc or 0) >= 240 or (tg or 0) >= 200 or hdl_low:
        out.append(_cond("dyslipidemia", "Unhealthy cholesterol / blood-fat levels", "high_risk"
                         if (ldl or 0) >= 190 or (tg or 0) >= 500 else "borderline", lip_ev, "arteries",
                         "Physician / Cardiologist", ["Repeat fasting lipid profile"], {"Heart attack": 1.2}))
    elif (ldl or 0) >= 130 or (tc or 0) >= 200 or (tg or 0) >= 150:
        out.append(_cond("borderline_lipids", "Borderline-high cholesterol", "borderline", lip_ev, "arteries",
                         "GP", ["Lipid profile in 6–12 months"]))

    hb = v.get("hemoglobin")
    if hb is not None and hb < (12.0 if sex == "female" else 13.5):
        out.append(_cond("anemia", "Anaemia (low haemoglobin)", "high_risk" if hb < 10 else "borderline",
                         [f"haemoglobin {hb:g} g/dL"], "blood", "GP / Haematologist",
                         ["Iron studies (ferritin)", "Vitamin B12 & folate", "Peripheral smear"],
                         {"Malaria": 1.3}))

    wbc, crp = v.get("wbc"), v.get("crp")
    if (wbc or 0) > 11 or (crp or 0) > 10:
        inf_ev = [x for x in (wbc and f"white cells {wbc:g} ×10³/µL", crp and f"CRP {crp:g} mg/L") if x]
        out.append(_cond("infection", "Signs of infection or inflammation", "high_risk" if (wbc or 0) > 15 or
                         (crp or 0) > 50 else "borderline", inf_ev, "blood", "Physician",
                         ["Clinical exam to find the source", "Blood / urine culture if fever"],
                         {"Pneumonia": 1.8, "Typhoid": 1.6, "Urinary tract infection": 1.5, "Malaria": 1.3,
                          "Gastroenteritis": 1.3, "Tuberculosis": 1.3}))
    if wbc is not None and wbc < 4:
        out.append(_cond("low_wbc", "Low white-cell count", "borderline", [f"white cells {wbc:g} ×10³/µL"],
                         "blood", "Physician", ["Repeat CBC"], {"Dengue": 1.6, "Typhoid": 1.4, "Malaria": 1.3}))

    plt = v.get("platelets")
    if plt is not None and plt < 150:
        out.append(_cond("low_platelets", "Low platelet count", "high_risk" if plt < 100 else "borderline",
                         [f"platelets {plt:g} ×10³/µL"], "blood", "Physician",
                         ["Dengue NS1 / IgM", "Malaria test", "Repeat CBC"], {"Dengue": 3.5, "Malaria": 1.8}))
    elif plt is not None:
        contra["Dengue"] = 0.5

    cr, egfr, urea, bun = v.get("creatinine"), v.get("egfr"), v.get("blood_urea"), v.get("bun")
    k_ev = [x for x in (cr and f"creatinine {cr:g} mg/dL", egfr and f"eGFR {egfr:g}", urea and f"urea {urea:g} mg/dL",
                        bun and f"BUN {bun:g} mg/dL") if x]
    cr_hi = cr is not None and cr > (1.1 if sex == "female" else 1.3)
    if cr_hi or (egfr is not None and egfr < 60) or (urea or 0) > 45 or (bun or 0) > 21:
        severe = (cr or 0) >= 2 or (egfr is not None and egfr < 30)
        out.append(_cond("kidney", "Reduced kidney filtering", "high_risk" if severe else "borderline", k_ev,
                         "kidneys", "Nephrologist", ["Repeat creatinine & eGFR", "Urine albumin", "Kidney ultrasound"],
                         {"Urinary tract infection": 1.2, "Hypertension": 1.3}))

    alt, ast, bili, dbili, alp = (v.get(k) for k in ("alt", "ast", "total_bilirubin", "direct_bilirubin", "alp"))
    l_ev = [x for x in (alt and f"ALT {alt:g} U/L", ast and f"AST {ast:g} U/L", bili and f"bilirubin {bili:g} mg/dL",
                        alp and f"ALP {alp:g} U/L") if x]
    liver_dis = ["hepatitis A", "Hepatitis B", "Hepatitis C", "Hepatitis D", "Hepatitis E", "Alcoholic hepatitis"]
    if (alt or 0) > 46 or (ast or 0) > 41 or (bili or 0) > 1.2 or (dbili or 0) > 0.3 or (alp or 0) > 150:
        severe = (alt or 0) > 135 or (ast or 0) > 120 or (bili or 0) > 2.5
        boosts = {d: 2.5 for d in liver_dis}
        if (bili or 0) > 1.2 or (dbili or 0) > 0.3:
            boosts.update({"Jaundice": 3.0, "Chronic cholestasis": 2.0})
        if (alp or 0) > 150:
            boosts["Chronic cholestasis"] = boosts.get("Chronic cholestasis", 1) * 1.5
        out.append(_cond("liver", "Liver under stress (raised liver tests)", "high_risk" if severe else "borderline",
                         l_ev, "liver", "Gastroenterologist / Hepatologist",
                         ["Hepatitis viral markers", "Liver ultrasound", "Repeat LFT"], boosts))
    elif l_ev:
        contra.update({d: 0.5 for d in [*liver_dis, "Jaundice", "Chronic cholestasis"]})

    tsh, ft4 = v.get("tsh"), v.get("free_t4")
    if tsh is not None:
        if tsh > 4.5:
            out.append(_cond("hypothyroid_lab", "Underactive thyroid pattern (high TSH)", "high_risk" if tsh > 10
                             else "borderline", [f"TSH {tsh:g} mIU/L"] + ([f"free T4 {ft4:g} ng/dL"] if ft4 else []),
                             "thyroid", "Endocrinologist", ["Free T4", "Thyroid antibodies (anti-TPO)"],
                             {"Hypothyroidism": 4.0, "Hyperthyroidism": 0.2}))
        elif tsh < 0.4:
            out.append(_cond("hyperthyroid_lab", "Overactive thyroid pattern (low TSH)", "high_risk" if tsh < 0.1
                             else "borderline", [f"TSH {tsh:g} mIU/L"] + ([f"free T4 {ft4:g} ng/dL"] if ft4 else []),
                             "thyroid", "Endocrinologist", ["Free T4 / T3", "Thyroid scan"],
                             {"Hyperthyroidism": 4.0, "Hypothyroidism": 0.2}))
        else:
            contra.update({"Hypothyroidism": 0.3, "Hyperthyroidism": 0.3})

    trop = v.get("troponin")
    if trop is not None and trop >= 0.04:
        out.append(_cond("cardiac_injury", "Possible heart-muscle injury (raised troponin)", "high_risk",
                         [f"troponin {trop:g} ng/mL"], "heart", "Emergency care / Cardiologist",
                         ["Repeat troponin", "ECG", "Echocardiogram"], {"Heart attack": 5.0}))
    spo2 = v.get("spo2")
    if spo2 is not None and spo2 < 95:
        out.append(_cond("low_oxygen", "Low blood oxygen", "high_risk" if spo2 < 92 else "borderline",
                         [f"SpO₂ {spo2:g}%"], "lungs", "Physician / Pulmonologist", ["Chest X-ray", "Arterial blood gas"],
                         {"Pneumonia": 2.0, "Bronchial Asthma": 1.6, "Tuberculosis": 1.3}))
    temp = v.get("temperature")
    if temp is not None and temp >= 37.6:
        out.append(_cond("fever", "Fever", "high_risk" if temp >= 39 else "borderline", [f"temperature {temp:g} °C"],
                         "body", "GP / Physician", ["CBC", "Malaria & dengue tests if in an endemic area"],
                         {"Malaria": 1.5, "Dengue": 1.5, "Typhoid": 1.5, "Pneumonia": 1.4, "Common Cold": 1.2,
                          "Chicken pox": 1.2}))
    bmi = v.get("bmi")
    if bmi is not None and bmi >= 30:
        out.append(_cond("obesity", "Obesity range BMI", "borderline", [f"BMI {bmi:g}"], "body", "GP / Dietitian",
                         ["Waist circumference", "HbA1c", "Lipid profile"], {"Diabetes": 1.3, "Hypertension": 1.3}))
    return out, contra


# ---------------------------------------------------------------------------
# Red flags
# ---------------------------------------------------------------------------
SYMPTOM_RED_FLAGS = [
    ({"chest_pain"}, {"breathlessness", "sweating", "fast_heart_rate", "palpitations"},
     "Chest pain with breathlessness, sweating or a racing heart can be a heart attack."),
    ({"weakness_of_one_body_side"}, set(), "Sudden weakness on one side of the body can be a stroke."),
    ({"slurred_speech"}, set(), "Sudden slurred speech can be a stroke."),
    ({"altered_sensorium"}, set(), "Confusion or reduced alertness needs urgent assessment."),
    ({"coma"}, set(), "Unresponsiveness is a medical emergency."),
    ({"blood_in_sputum"}, set(), "Coughing up blood needs prompt medical assessment."),
    ({"stomach_bleeding"}, set(), "Vomiting blood or black stools can mean internal bleeding."),
    ({"acute_liver_failure"}, set(), "Signs of liver failure need emergency care."),
]


def red_flags(symptoms: set, v: dict) -> list[str]:
    flags = []
    for required, any_of, msg in SYMPTOM_RED_FLAGS:
        if required <= symptoms and (not any_of or any_of & symptoms):
            flags.append(msg)
    checks = [
        (v.get("spo2") is not None and v["spo2"] < 92, "Oxygen saturation below 92%."),
        (v.get("troponin") is not None and v["troponin"] >= 0.04, "Raised troponin suggests heart-muscle injury."),
        ((v.get("systolic_bp") or 0) >= 180 or (v.get("diastolic_bp") or 0) >= 120,
         "Blood pressure at crisis level (180/120 or higher)."),
        (any(v.get(k) is not None and v[k] < 54 for k in ("fasting_glucose", "random_glucose")),
         "Very low blood sugar (below 54 mg/dL)."),
        (any((v.get(k) or 0) > 400 for k in ("fasting_glucose", "random_glucose")), "Very high blood sugar (above 400 mg/dL)."),
        (v.get("potassium") is not None and (v["potassium"] > 6 or v["potassium"] < 3),
         "Potassium at a level that can disturb heart rhythm."),
        (v.get("platelets") is not None and v["platelets"] < 50, "Platelets below 50 ×10³/µL (bleeding risk)."),
        (v.get("hemoglobin") is not None and v["hemoglobin"] < 7, "Severe anaemia (haemoglobin below 7 g/dL)."),
        ((v.get("temperature") or 0) >= 39.5, "High fever (39.5 °C or more)."),
    ]
    flags += [msg for cond, msg in checks if cond]
    return flags


# ---------------------------------------------------------------------------
# ML model inputs derived from the user's data
# ---------------------------------------------------------------------------
def diabetes_inputs(v: dict, patient: dict, clinical: dict) -> dict:
    x = dict(clinical or {})
    x.setdefault("Glucose", v.get("random_glucose") or v.get("fasting_glucose"))
    x.setdefault("BloodPressure", v.get("diastolic_bp"))
    x.setdefault("BMI", v.get("bmi"))
    x.setdefault("Insulin", v.get("insulin"))
    x.setdefault("Age", patient.get("age"))
    if patient.get("sex") == "male":
        x.setdefault("Pregnancies", 0)
    return {k: val for k, val in x.items() if val is not None}


def heart_inputs(v: dict, patient: dict, clinical: dict) -> dict:
    x = dict(clinical or {})
    x.setdefault("age", patient.get("age"))
    if patient.get("sex") in ("male", "female"):
        x.setdefault("sex", 1 if patient["sex"] == "male" else 0)
    x.setdefault("trestbps", v.get("systolic_bp"))
    x.setdefault("chol", v.get("total_cholesterol"))
    if v.get("fasting_glucose") is not None:
        x.setdefault("fbs", 1 if v["fasting_glucose"] > 120 else 0)
    return {k: val for k, val in x.items() if val is not None}


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def assess(data: dict) -> dict:
    mode = data["mode"]
    symptoms: list[str] = data.get("symptoms", []) if mode != "report" else []
    denied: list[str] = data.get("denied", []) if mode != "report" else []
    values: dict = dict(data.get("biomarkers", {})) if mode != "symptoms" else {}
    patient: dict = data.get("patient", {})
    clinical: dict = data.get("clinical", {})
    sex = patient.get("sex")
    if "bmi" not in values and patient.get("height_cm") and patient.get("weight_kg"):
        values["bmi"] = round(patient["weight_kg"] / (patient["height_cm"] / 100) ** 2, 1)

    items, organs = analyze(values, sex)
    findings, contra = lab_findings(values, sex) if values else ([], {})
    flags = red_flags(set(symptoms), values)

    # --- ML tabular risks
    ml_risks = []
    d_in = diabetes_inputs(values, patient, clinical.get("diabetes"))
    if d_in.get("Glucose") is not None:
        ml_risks.append(registry.predict_tabular("diabetes", d_in))
    h_in = heart_inputs(values, patient, clinical.get("heart"))
    if h_in.get("age") is not None and len(h_in) >= 4:
        ml_risks.append(registry.predict_tabular("heart", h_in))
    if clinical.get("parkinsons"):
        ml_risks.append(registry.predict_tabular("parkinsons", clinical["parkinsons"]))
    for r in ml_risks:
        r["inputs_used"] = {"diabetes": d_in, "heart": h_in}.get(r["model"], clinical.get("parkinsons", {}))

    # --- Symptom model + lab fusion
    symptom_preds: list[dict] = []
    if symptoms:
        raw = registry.predict_symptoms(symptoms, denied, top=41)
        if findings or contra:
            for p in raw:
                factor = contra.get(p["disease"], 1.0)
                for f in findings:
                    factor *= f["boosts"].get(p["disease"], 1.0)
                p["lab_factor"] = round(factor, 2)
                p["probability"] *= factor
            total = sum(p["probability"] for p in raw) or 1.0
            for p in raw:
                p["probability"] = round(p["probability"] / total, 4)
            raw.sort(key=lambda p: p["probability"], reverse=True)
        symptom_preds = raw[:8]

    # --- Differential diagnosis
    differential = []
    used_findings = set()
    for p in symptom_preds[:6]:
        if p["probability"] < 0.03 and differential:
            continue
        support = [f for f in findings if f["boosts"].get(p["disease"], 1) > 1.4]
        used_findings.update(f["id"] for f in support)
        sources = ["symptoms"] + (["labs"] if support else [])
        differential.append({
            "name": p["name"], "confidence": p["probability"], "kind": "probability", "sources": sources,
            "organ": p["organ"], "urgency": p["urgency"], "specialist": p["specialist"], "tests": p["tests"],
            "evidence": [", ".join(symptom_label(s).lower() for s in symptoms[:6])] +
                        [e for f in support for e in f["evidence"]],
        })
    sev_score = {"high_risk": 0.85, "borderline": 0.55}
    for f in findings:
        if f["id"] in used_findings:
            continue
        score = min(0.95, sev_score[f["severity"]] + 0.04 * (len(f["evidence"]) - 1))
        differential.append({
            "name": f["name"], "confidence": round(score, 2), "kind": "lab_evidence", "sources": ["labs"],
            "organ": f["organ"], "urgency": "urgent" if f["id"] in ("cardiac_injury", "low_oxygen") and
            f["severity"] == "high_risk" else ("soon" if f["severity"] == "high_risk" else "routine"),
            "specialist": f["specialist"], "tests": f["tests"], "evidence": f["evidence"], "about": f["about"],
        })
    for r in ml_risks:
        differential.append({
            "name": f"{r['title']} risk (ML model)", "confidence": r["probability"], "kind": "model_risk",
            "sources": ["ml_model"], "organ": {"diabetes": "pancreas", "heart": "heart", "parkinsons": "brain"}[r["model"]],
            "urgency": "soon" if r["level"] == "high_risk" else "routine",
            "specialist": {"diabetes": "Endocrinologist", "heart": "Cardiologist", "parkinsons": "Neurologist"}[r["model"]],
            "tests": {"diabetes": ["HbA1c", "Fasting glucose"], "heart": ["ECG", "Lipid profile", "Stress test"],
                      "parkinsons": ["Neurological examination"]}[r["model"]],
            "evidence": [f"{r['inputs_provided']} of {r['inputs_total']} model inputs provided"],
        })
    urgency_rank = {"urgent": 2, "soon": 1, "routine": 0}
    # Confident urgent items first, then everything by confidence
    differential.sort(key=lambda d: (-(urgency_rank[d["urgency"]] if d["confidence"] >= 0.25 else 0),
                                     -d["confidence"]))

    # --- Organ overlay (labs + ML + symptoms)
    organ_view: dict[str, dict] = {k: {**o, "symptoms": [], "sources": ["labs"]} for k, o in organs.items()}

    def bump(organ, status, source):
        o = organ_view.setdefault(organ, {"organ": organ, "title": ORGANS[organ], "status": "normal",
                                          "markers": [], "symptoms": [], "sources": []})
        if STATUS_ORDER[status] > STATUS_ORDER[o["status"]]:
            o["status"] = status
        if source not in o["sources"]:
            o["sources"].append(source)
        return o

    for r in ml_risks:
        organ = {"diabetes": "pancreas", "heart": "heart", "parkinsons": "brain"}[r["model"]]
        bump(organ, r["level"], "ml_model")["ml_risk"] = {"title": r["title"], "probability": r["probability"]}
    for s in symptoms:
        organ = symptom_organ(s)
        if organ:
            bump(organ, "borderline", "symptoms")["symptoms"].append(symptom_label(s))

    # --- Next steps
    steps = []
    if flags:
        steps.append({"priority": "urgent", "text": "Seek emergency medical care now (call your local emergency "
                      "number) because of: " + " ".join(flags)})
    seen = set()
    for d in differential[:4]:
        if d["confidence"] < 0.15 or d["specialist"] in seen:
            continue
        seen.add(d["specialist"])
        steps.append({"priority": "soon" if d["urgency"] != "routine" else "routine",
                      "text": f"Discuss {d['name'].lower()} with a {d['specialist'].lower()}. "
                              f"Useful tests: {', '.join(d['tests'][:3])}."})
    if mode == "symptoms" and not values:
        steps.append({"priority": "routine", "text": "Upload a recent blood report to check these "
                      "possibilities against lab values."})
    if any(i["status"] != "normal" for i in items):
        steps.append({"priority": "routine", "text": "Repeat any out-of-range lab values to confirm them; one "
                      "abnormal result is not a diagnosis."})
    steps.append({"priority": "routine", "text": "Keep a short diary of symptoms (start date, severity, triggers) "
                  "to share with your doctor."})

    followup = registry.next_question(symptoms, denied) if symptoms else None
    return {
        "mode": mode, "patient": patient, "biomarkers": items, "organs": organ_view, "findings": [
            {k: f[k] for k in ("id", "name", "severity", "evidence", "organ", "specialist", "tests", "about")}
            for f in findings],
        "symptoms": [{"key": s, "label": symptom_label(s), "organ": symptom_organ(s)} for s in symptoms],
        "denied": [{"key": s, "label": symptom_label(s)} for s in denied],
        "symptom_predictions": symptom_preds, "ml_risks": ml_risks, "differential": differential[:8],
        "red_flags": flags, "next_steps": steps, "followup": followup,
        "summary": {"abnormal_markers": sum(1 for i in items if i["status"] != "normal"),
                    "markers": len(items), "top": differential[0]["name"] if differential else None,
                    "overall": max((o["status"] for o in organ_view.values()), key=lambda s: STATUS_ORDER[s],
                                   default="normal") if not flags else "high_risk"},
    }


def context_text(result: dict) -> str:
    """Compact, model-readable summary of an assessment for the chatbot."""
    lines = []
    p = result.get("patient") or {}
    if p:
        lines.append("Patient: " + ", ".join(f"{k}={v}" for k, v in p.items() if v is not None))
    if result["symptoms"]:
        lines.append("Reported symptoms: " + ", ".join(s["label"] for s in result["symptoms"]))
    if result["denied"]:
        lines.append("Symptoms the user said they do NOT have: " + ", ".join(s["label"] for s in result["denied"]))
    abnormal = [b for b in result["biomarkers"] if b["status"] != "normal"]
    normal = [b for b in result["biomarkers"] if b["status"] == "normal"]
    if abnormal:
        lines.append("Out-of-range lab values: " + "; ".join(
            f"{b['label']} {b['value']:g} {b['unit']} ({b['status'].replace('_', ' ')}, {b['direction']}; "
            f"normal {b['normal_range']})" for b in abnormal))
    if normal:
        lines.append("Normal lab values: " + "; ".join(f"{b['label']} {b['value']:g} {b['unit']}" for b in normal))
    if result["differential"]:
        lines.append("Screening results (not diagnoses): " + "; ".join(
            f"{d['name']} {round(d['confidence'] * 100)}% [{d['kind'].replace('_', ' ')}]"
            for d in result["differential"][:6]))
    if result["red_flags"]:
        lines.append("RED FLAGS: " + " ".join(result["red_flags"]))
    if result.get("followup"):
        lines.append("Suggested next clarifying symptom to ask about: " + result["followup"]["label"])
    return "\n".join(lines) or "No data entered yet."
