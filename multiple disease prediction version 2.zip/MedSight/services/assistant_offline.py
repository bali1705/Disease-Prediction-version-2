"""Rule-based fallback for the assistant when Gemini is not configured or unavailable.

It still uses the user's assessment data, explains abnormal markers, and asks
one clarifying question at a time, so the app stays useful without an API key.
"""
from __future__ import annotations

import re

from .biomarkers import MARKERS

GENERIC_QUESTIONS = [
    "How many days have you had these symptoms, and are they getting better, worse or staying the same?",
    "On a scale of 1 to 10, how severe is the main symptom right now?",
    "Do you have any long-term conditions or take regular medicines?",
    "Have you had a fever, and if so, how high did it go?",
    "Has anyone around you had similar symptoms recently, or have you travelled lately?",
]

REPORT_QUESTIONS = [
    "Were these blood tests taken after fasting (no food for 8 hours or more)?",
    "Are you having any symptoms at the moment, such as tiredness, thirst, headaches or breathlessness?",
    "Do you have any long-term conditions or take regular medicines?",
    "Do any close relatives have diabetes, heart disease or kidney disease?",
]


def _mentioned_marker(message: str, result: dict):
    low = message.lower()
    by_key = {b["key"]: b for b in result.get("biomarkers", [])}
    for key, m in MARKERS.items():
        names = [m.label.lower(), *m.aliases]
        if any(re.search(r"(?<![a-z0-9])" + re.escape(n) + r"(?![a-z0-9])", low) for n in names):
            return m, by_key.get(key)
    return None, None


def _next_question(result: dict, history: list[dict]) -> str:
    asked = " ".join(t.get("content", "") for t in history if t.get("role") == "assistant").lower()
    f = result.get("followup")
    if f and f["label"].lower() not in asked:
        return f"{f['question']} {f['why']}"
    questions = GENERIC_QUESTIONS if result.get("symptoms") else REPORT_QUESTIONS
    for q in questions:
        if q[:40].lower() not in asked:
            return q
    return "Is there anything else about how you feel that you haven't mentioned yet?"


def reply(message: str, history: list[dict], result: dict) -> str:
    parts = []
    if result.get("red_flags"):
        parts.append("Important: " + " ".join(result["red_flags"]) +
                     " Please contact emergency services or go to the nearest emergency department now.")
    marker, value = _mentioned_marker(message, result)
    low = message.lower()
    if marker:
        text = f"{marker.label}: {marker.about}"
        if value:
            status = {"normal": "within the normal range", "borderline": "slightly outside the normal range",
                      "high_risk": "clearly outside the normal range"}[value["status"]]
            text += f" Your value of {value['value']:g} {marker.unit} is {status} (typical: {value['normal_range']})."
            if value["meaning"] and value["status"] != "normal":
                text += " " + value["meaning"]
        parts.append(text)
    elif any(w in low for w in ("what should i do", "next", "doctor", "specialist", "treatment", "what now")):
        steps = [s["text"] for s in result.get("next_steps", [])[:3]]
        parts.append("Here is what I'd suggest based on your results: " + " ".join(steps) if steps else
                     "Start by entering your symptoms or uploading a report so I can tailor suggestions.")
    else:
        diff = result.get("differential") or []
        abnormal = [b for b in result.get("biomarkers", []) if b["status"] != "normal"]
        if diff:
            top = ", ".join(f"{d['name']} ({round(d['confidence'] * 100)}%)" for d in diff[:3])
            parts.append(f"Based on what you've shared, the screening points most towards: {top}. These are "
                         "statistical estimates from screening models, not a diagnosis.")
        if abnormal:
            parts.append("Values worth discussing with a doctor: " + "; ".join(
                f"{b['label']} {b['value']:g} {b['unit']} ({b['direction']})" for b in abnormal[:4]) + ".")
        if not diff and not abnormal:
            parts.append("I don't see any symptoms or lab values yet. Tick your symptoms or upload a report, and "
                         "I'll explain what the results mean.")
    parts.append(_next_question(result, history))
    return "\n\n".join(parts)
