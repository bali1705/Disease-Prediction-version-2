"""Strict input validation for every public endpoint."""
from __future__ import annotations

import math

from ml_pipeline.config import MODEL_SPECS
from ml_pipeline.symptom_catalog import ALL_SYMPTOMS

from .biomarkers import MARKERS

MAX_SYMPTOMS = 40
MAX_MESSAGE_CHARS = 1200
MAX_HISTORY_TURNS = 12
_SYMPTOM_SET = set(ALL_SYMPTOMS)


class ValidationError(ValueError):
    """Raised with a user-facing message describing exactly what to fix."""


def _num(value, name: str, lo: float, hi: float, allow_none=True):
    if value is None or value == "":
        if allow_none:
            return None
        raise ValidationError(f"{name} is required.")
    if isinstance(value, bool):
        raise ValidationError(f"{name} must be a number.")
    try:
        x = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{name} must be a number.") from None
    if math.isnan(x) or math.isinf(x):
        raise ValidationError(f"{name} must be a number.")
    if not lo <= x <= hi:
        raise ValidationError(f"{name} must be between {lo:g} and {hi:g}.")
    return x


def symptoms(values, field="symptoms") -> list[str]:
    if values is None:
        return []
    if not isinstance(values, list):
        raise ValidationError(f"{field} must be a list.")
    out = []
    for s in values[:MAX_SYMPTOMS * 2]:
        if isinstance(s, str) and s in _SYMPTOM_SET and s not in out:
            out.append(s)
    return out[:MAX_SYMPTOMS]


def biomarkers(values) -> dict[str, float]:
    if values is None:
        return {}
    if not isinstance(values, dict):
        raise ValidationError("biomarkers must be an object of {name: value}.")
    out = {}
    for key, raw in values.items():
        if key not in MARKERS or raw in (None, ""):
            continue
        m = MARKERS[key]
        lo, hi = m.plausible
        out[key] = _num(raw, m.label, lo, hi)
    return out


def patient(values) -> dict:
    values = values or {}
    if not isinstance(values, dict):
        raise ValidationError("patient must be an object.")
    out = {}
    age = _num(values.get("age"), "Age", 1, 120)
    if age is not None:
        out["age"] = int(round(age))
    sex = values.get("sex")
    if sex not in (None, "", "male", "female"):
        raise ValidationError("Sex must be 'male' or 'female'.")
    if sex:
        out["sex"] = sex
    h = _num(values.get("height_cm"), "Height", 50, 250)
    w = _num(values.get("weight_kg"), "Weight", 2, 350)
    if h:
        out["height_cm"] = h
    if w:
        out["weight_kg"] = w
    return out


def model_features(model: str, values) -> dict:
    if model not in MODEL_SPECS:
        raise ValidationError("Unknown model.")
    if values is None:
        return {}
    if not isinstance(values, dict):
        raise ValidationError("Model inputs must be an object.")
    out = {}
    for f in MODEL_SPECS[model]["features"]:
        raw = values.get(f["name"])
        if raw in (None, ""):
            continue
        if f.get("type") == "select":
            allowed = {float(o[0]) for o in f["options"]}
            x = _num(raw, f["label"], -1e9, 1e9)
            if x not in allowed:
                raise ValidationError(f"{f['label']}: choose one of the listed options.")
            out[f["name"]] = x
        else:
            out[f["name"]] = _num(raw, f["label"], f["min"], f["max"])
    return out


def assessment_payload(data) -> dict:
    if not isinstance(data, dict):
        raise ValidationError("Request body must be a JSON object.")
    mode = data.get("mode", "combined")
    if mode not in ("symptoms", "report", "combined"):
        raise ValidationError("mode must be 'symptoms', 'report' or 'combined'.")
    clinical_raw = data.get("clinical") or {}
    if not isinstance(clinical_raw, dict):
        raise ValidationError("clinical must be an object.")
    clinical = {m: model_features(m, clinical_raw.get(m)) for m in MODEL_SPECS if clinical_raw.get(m)}
    if "parkinsons" in clinical and len(clinical["parkinsons"]) < len(MODEL_SPECS["parkinsons"]["features"]):
        raise ValidationError("The Parkinson's voice model needs all 22 voice measurements.")
    out = {"mode": mode, "symptoms": symptoms(data.get("symptoms")), "denied": symptoms(data.get("denied"), "denied"),
           "biomarkers": biomarkers(data.get("biomarkers")), "patient": patient(data.get("patient")),
           "clinical": {k: v for k, v in clinical.items() if v}}
    out["denied"] = [s for s in out["denied"] if s not in out["symptoms"]]
    return out


def chat_payload(data) -> tuple[str, list[dict], dict]:
    if not isinstance(data, dict):
        raise ValidationError("Request body must be a JSON object.")
    message = data.get("message")
    if not isinstance(message, str) or not message.strip():
        raise ValidationError("Type a message first.")
    message = message.strip()
    if len(message) > MAX_MESSAGE_CHARS:
        raise ValidationError(f"Messages can be at most {MAX_MESSAGE_CHARS} characters.")
    history = []
    for turn in (data.get("history") or [])[-MAX_HISTORY_TURNS:]:
        if isinstance(turn, dict) and turn.get("role") in ("user", "assistant") and isinstance(turn.get("content"), str):
            history.append({"role": turn["role"], "content": turn["content"][:2000]})
    assessment = assessment_payload(data.get("assessment") or {"mode": "combined"})
    return message, history, assessment
