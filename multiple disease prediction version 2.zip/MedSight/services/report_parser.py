"""Extract vitals and lab biomarkers from uploaded medical reports.

Order of strategies:
  1. Gemini multimodal vision (images and PDFs) when GEMINI_API_KEY is set.
  2. Text-layer parsing of digital PDFs with pypdf + a rule-based parser.
  3. Pasted report text with the same rule-based parser.
"""
from __future__ import annotations

import logging
import re

from pypdf import PdfReader

from .biomarkers import IGNORE_ALIASES, MARKERS, normalize_value

log = logging.getLogger(__name__)

NUM = r"(?<![A-Za-z0-9.])[-+]?\d+(?:[.,]\d+)?"  # skip digits glued to words (e.g. the 1 in HbA1c)

# (alias, key) sorted longest first so "glycated hemoglobin" beats "hemoglobin"
_ALIAS_TABLE = sorted(
    [(a.lower(), m.key) for m in MARKERS.values() for a in m.aliases] + [(a, None) for a in IGNORE_ALIASES],
    key=lambda t: len(t[0]), reverse=True,
)
_ALIAS_RES = [(re.compile(r"(?<![a-z0-9])" + re.escape(a) + r"(?![a-z0-9])"), a, k) for a, k in _ALIAS_TABLE]
_BP_RE = re.compile(r"(?:blood\s*pressure|\bb\.?p\.?\b)[^0-9\n]{0,25}(\d{2,3})\s*/\s*(\d{2,3})", re.I)
_AGE_RE = re.compile(r"\bage\b[^0-9\n]{0,12}(\d{1,3})", re.I)
_SEX_RE = re.compile(r"\b(?:sex|gender)\b[^a-z\n]{0,6}(male|female|m|f)\b", re.I)
_AGE_SEX_RE = re.compile(r"(\d{1,3})\s*(?:y|yr|yrs|years?)\b\s*[/,|-]?\s*(male|female|m|f)\b", re.I)
_SKIP_LINE = re.compile(r"\b(ratio|urine|urinary)\b", re.I)


def _parse_number(s: str) -> float:
    return float(s.replace(",", "."))


def parse_report_text(text: str) -> dict:
    """Rule-based extraction from report text. Returns {"biomarkers": {key: value}, "patient": {...}}."""
    found: dict[str, float] = {}
    patient: dict = {}
    text = text.replace(" ", " ")
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        low = line.lower()
        bp = _BP_RE.search(line)
        if bp:
            found.setdefault("systolic_bp", float(bp.group(1)))
            found.setdefault("diastolic_bp", float(bp.group(2)))
            continue
        if "age" not in patient:
            m = _AGE_SEX_RE.search(line)
            if m:
                patient["age"] = int(m.group(1))
                patient["sex"] = "male" if m.group(2).lower().startswith("m") else "female"
            else:
                m = _AGE_RE.search(line)
                if m and 0 < int(m.group(1)) < 120:
                    patient["age"] = int(m.group(1))
        if "sex" not in patient:
            m = _SEX_RE.search(line)
            if m:
                patient["sex"] = "male" if m.group(1).lower().startswith("m") else "female"
        if _SKIP_LINE.search(low):
            continue
        # Pick the earliest, longest alias in the line
        best = None
        for rx, alias, key in _ALIAS_RES:
            m = rx.search(low)
            if m and (best is None or m.start() < best[0].start()):
                best = (m, alias, key)
        if not best or best[2] is None:
            continue
        m, alias, key = best
        tail = line[m.end():]
        num = re.search(NUM, tail)
        if not num:
            continue
        unit_text = tail[num.end():num.end() + 24]
        value = normalize_value(key, _parse_number(num.group(0)), unit_text)
        if value is not None and key not in found:
            found[key] = value
    return {"biomarkers": found, "patient": patient}


def extract_pdf_text(path: str, max_pages: int = 12) -> str:
    reader = PdfReader(path)
    if reader.is_encrypted:
        try:
            reader.decrypt("")
        except Exception as exc:  # pragma: no cover - depends on file
            raise ValueError("This PDF is password-protected. Remove the password and upload it again.") from exc
    parts = []
    for page in reader.pages[:max_pages]:
        parts.append(page.extract_text() or "")
    return "\n".join(parts)


def normalize_ai_extraction(data: dict) -> dict:
    """Map Gemini's structured output onto canonical keys and units."""
    found: dict[str, float] = {}
    for test in data.get("tests") or []:
        key = (test.get("key") or "").strip()
        if key not in MARKERS:
            # Fall back to alias matching on the printed test name
            name = (test.get("name") or "").lower()
            key = next((k for rx, _a, k in _ALIAS_RES if k and rx.search(name)), None)
        if not key or key in found:
            continue
        try:
            raw = float(str(test.get("value")).replace(",", "."))
        except (TypeError, ValueError):
            continue
        value = normalize_value(key, raw, test.get("unit") or "")
        if value is not None:
            found[key] = value
    patient = {}
    age = data.get("patient_age")
    if isinstance(age, (int, float)) and 0 < age < 120:
        patient["age"] = int(age)
    sex = (data.get("patient_sex") or "").lower()
    if sex in ("male", "female"):
        patient["sex"] = sex
    return {"biomarkers": found, "patient": patient, "summary": (data.get("summary") or "")[:600]}
