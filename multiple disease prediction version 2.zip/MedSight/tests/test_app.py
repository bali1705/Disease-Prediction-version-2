"""End-to-end API tests. Run with:  pytest -q"""
from __future__ import annotations

import io
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ["GEMINI_API_KEY"] = ""  # tests never call the real API

import app as app_module  # noqa: E402
from services.report_parser import parse_report_text  # noqa: E402


@pytest.fixture()
def client():
    app_module.app.config.update(TESTING=True)
    app_module.limiter.reset()
    with app_module.app.test_client() as c:
        yield c


def make_text_pdf(lines: list[str]) -> bytes:
    """Build a minimal valid PDF with a real text layer (no external libraries)."""
    content = "BT /F1 11 Tf 50 780 Td 14 TL " + " ".join(
        "(" + ln.replace("(", "\\(").replace(")", "\\)") + ") Tj T*" for ln in lines) + " ET"
    objs = [
        "<< /Type /Catalog /Pages 2 0 R >>",
        "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R "
        "/Resources << /Font << /F1 5 0 R >> >> >>",
        f"<< /Length {len(content)} >>\nstream\n{content}\nendstream",
        "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out = b"%PDF-1.4\n"
    offsets = []
    for i, o in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n{o}\nendobj\n".encode()
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    out += "".join(f"{off:010d} 00000 n \n" for off in offsets).encode()
    out += f"trailer\n<< /Size {len(objs) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return out


SAMPLE_REPORT = [
    "Patient: Test  Age/Sex: 52 Y / M",
    "Blood Pressure: 148/94 mmHg",
    "Pulse Rate 96 bpm",
    "Glycated Haemoglobin (HbA1c) 7.4 %",
    "Fasting Blood Sugar 152 mg/dL 70-100",
    "Haemoglobin 11.2 g/dL 13.0-17.0",
    "Platelet Count 1.1 lakhs/cumm",
    "Total Leucocyte Count 12500 cells/cumm",
    "Serum Creatinine 1.6 mg/dL",
    "SGPT (ALT) 88 U/L",
    "Total Cholesterol 236 mg/dL",
    "LDL Cholesterol 162 mg/dL",
    "HDL Cholesterol 36 mg/dL",
    "Cholesterol/HDL Ratio 6.5",
    "TSH 6.2 uIU/mL",
]


# ---------------------------------------------------------------- basics
def test_health_and_index(client):
    assert client.get("/healthz").json["status"] == "ok"
    r = client.get("/")
    assert r.status_code == 200 and b"Health" in r.data
    assert "Content-Security-Policy" in r.headers


def test_meta(client):
    m = client.get("/api/meta").json
    assert sum(len(c["symptoms"]) for c in m["symptoms"]) == 131
    assert {"diabetes", "heart", "parkinsons"} <= set(m["models"])
    assert any(b["key"] == "hba1c" for b in m["biomarkers"])


def test_performance_report(client):
    p = client.get("/api/performance").json
    assert {row["key"] for row in p["comparison"]} >= {"diabetes", "heart", "parkinsons", "symptoms"}


# ---------------------------------------------------------------- parsing
def test_text_parser_units_and_aliases():
    out = parse_report_text("\n".join(SAMPLE_REPORT))
    b = out["biomarkers"]
    assert b["systolic_bp"] == 148 and b["diastolic_bp"] == 94
    assert b["hba1c"] == 7.4  # not confused with haemoglobin
    assert b["hemoglobin"] == 11.2
    assert b["platelets"] == 110  # 1.1 lakh/cumm -> 110 x10^3/uL
    assert b["wbc"] == 12.5  # 12500/cumm -> 12.5 x10^3/uL
    assert b["hdl"] == 36 and "ratio" not in str(b)
    assert b["tsh"] == 6.2
    assert out["patient"] == {"age": 52, "sex": "male"}


def test_mmol_conversion():
    b = parse_report_text("Fasting glucose 7.2 mmol/L\nCreatinine 132 umol/L")["biomarkers"]
    assert 125 < b["fasting_glucose"] < 135
    assert 1.4 < b["creatinine"] < 1.6


# ---------------------------------------------------------------- assessment
def test_symptom_mode(client):
    r = client.post("/api/assess", json={"mode": "symptoms", "symptoms": ["itching", "skin_rash",
                                                                         "nodal_skin_eruptions"]})
    d = r.json
    assert r.status_code == 200
    assert d["differential"][0]["name"] == "Fungal skin infection"
    assert d["followup"] is None or d["followup"]["symptom"] not in ("itching", "skin_rash")
    assert "skin" in d["organs"]


def test_report_mode_flags_organs(client):
    vals = parse_report_text("\n".join(SAMPLE_REPORT))["biomarkers"]
    d = client.post("/api/assess", json={"mode": "report", "biomarkers": vals,
                                         "patient": {"age": 52, "sex": "male"}}).json
    assert d["organs"]["pancreas"]["status"] == "high_risk"
    assert d["organs"]["blood"]["status"] in ("borderline", "high_risk")
    ids = {f["id"] for f in d["findings"]}
    assert {"diabetes_lab", "hypertension_lab", "anemia", "low_platelets", "kidney", "liver",
            "hypothyroid_lab", "dyslipidemia"} <= ids
    models = {r["model"] for r in d["ml_risks"]}
    assert models == {"diabetes", "heart"}
    assert all(0 <= r["probability"] <= 1 for r in d["ml_risks"])


def test_combined_fusion_boosts_dengue(client):
    sym = ["high_fever", "headache", "joint_pain", "muscle_pain", "nausea"]
    base = client.post("/api/assess", json={"mode": "symptoms", "symptoms": sym}).json
    fused = client.post("/api/assess", json={"mode": "combined", "symptoms": sym,
                                             "biomarkers": {"platelets": 70, "wbc": 3.2}}).json

    def prob(d, name):
        return next((x["confidence"] for x in d["differential"] if x["name"] == name), 0)

    assert prob(fused, "Dengue fever") > prob(base, "Dengue fever")
    assert "labs" in next(x for x in fused["differential"] if x["name"] == "Dengue fever")["sources"]


def test_red_flags(client):
    d = client.post("/api/assess", json={"mode": "combined", "symptoms": ["chest_pain", "breathlessness"],
                                         "biomarkers": {"spo2": 89}}).json
    assert len(d["red_flags"]) >= 2
    assert d["next_steps"][0]["priority"] == "urgent"


def test_followup_and_denied(client):
    d = client.post("/api/followup", json={"symptoms": ["cough", "high_fever"], "denied": []}).json
    q = d["followup"]
    assert q and q["symptom"] not in ("cough", "high_fever")
    d2 = client.post("/api/followup", json={"symptoms": ["cough", "high_fever"], "exclude": [q["symptom"]]}).json
    assert d2["followup"] is None or d2["followup"]["symptom"] != q["symptom"]


@pytest.mark.parametrize("payload,msg", [
    ({"mode": "nonsense"}, "mode"),
    ({"mode": "report", "biomarkers": {"hba1c": 80}}, "HbA1c"),
    ({"mode": "report", "patient": {"age": 400}}, "Age"),
    ({"mode": "report", "patient": {"sex": "x"}}, "Sex"),
    ({"mode": "report", "clinical": {"heart": {"cp": 9}}}, "Chest-pain"),
])
def test_validation_errors(client, payload, msg):
    r = client.post("/api/assess", json=payload)
    assert r.status_code == 400 and msg in r.json["error"]


def test_non_json_rejected(client):
    r = client.post("/api/assess", data="hello", content_type="text/plain")
    assert r.status_code == 400


# ---------------------------------------------------------------- clinical models
def test_predict_models(client):
    d = client.post("/api/predict/diabetes", json={"Glucose": 168, "BMI": 34, "Age": 50}).json
    assert 0 <= d["probability"] <= 1 and d["inputs_provided"] == 3
    healthy = client.post("/api/predict/heart", json={"age": 40, "sex": 0, "cp": 2, "thalach": 175, "exang": 0,
                                                      "oldpeak": 0, "ca": 0, "thal": 2}).json
    sick = client.post("/api/predict/heart", json={"age": 63, "sex": 1, "cp": 0, "thalach": 115, "exang": 1,
                                                   "oldpeak": 2.8, "ca": 2, "thal": 3}).json
    assert sick["probability"] > healthy["probability"]  # label direction is correct
    meta = client.get("/api/meta").json
    pk = client.post("/api/predict/parkinsons", json=meta["parkinsons_samples"]["parkinsons"]).json
    ok = client.post("/api/predict/parkinsons", json=meta["parkinsons_samples"]["healthy"]).json
    assert pk["probability"] > ok["probability"]
    assert client.post("/api/predict/parkinsons", json={"NHR": 0.02}).status_code == 400
    assert client.post("/api/predict/unknown", json={}).status_code == 404


# ---------------------------------------------------------------- uploads
def test_pdf_upload_text_layer_and_cleanup(client):
    pdf = make_text_pdf(SAMPLE_REPORT)
    r = client.post("/api/report", data={"file": (io.BytesIO(pdf), "report.pdf")},
                    content_type="multipart/form-data")
    assert r.status_code == 200, r.json
    assert r.json["method"] == "pdf_text" and r.json["biomarkers"]["hba1c"] == 7.4
    leftovers = [p for p in app_module.UPLOAD_DIR.iterdir() if p.name != ".gitkeep"]
    assert leftovers == []


def test_upload_rejects_spoofed_and_unknown_types(client):
    r = client.post("/api/report", data={"file": (io.BytesIO(b"MZ\x90\x00 not a pdf"), "evil.pdf")},
                    content_type="multipart/form-data")
    assert r.status_code == 400
    r = client.post("/api/report", data={"file": (io.BytesIO(b"hello"), "notes.txt")},
                    content_type="multipart/form-data")
    assert r.status_code == 400


def test_image_upload_without_ai_explains_alternative(client):
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (400, 400), "white").save(buf, "PNG")
    r = client.post("/api/report", data={"file": (io.BytesIO(buf.getvalue()), "scan.png")},
                    content_type="multipart/form-data")
    assert r.status_code == 422 and "Paste the report text" in r.json["error"]


def test_oversized_upload(client):
    big = b"%PDF-1.4\n" + b"0" * (app_module.MAX_UPLOAD_BYTES + 10)
    r = client.post("/api/report", data={"file": (io.BytesIO(big), "big.pdf")}, content_type="multipart/form-data")
    assert r.status_code in (400, 413)


def test_pasted_text(client):
    r = client.post("/api/report", json={"text": "\n".join(SAMPLE_REPORT)})
    assert r.status_code == 200 and r.json["found"] >= 12


# ---------------------------------------------------------------- chat
def test_chat_offline_fallback_asks_one_question(client):
    r = client.post("/api/chat", json={"message": "What does my HbA1c mean?", "history": [],
                                       "assessment": {"mode": "report", "biomarkers": {"hba1c": 7.1}}})
    assert r.status_code == 200 and r.json["source"] == "offline"
    assert "HbA1c" in r.json["reply"] and r.json["reply"].strip().endswith("?")


def test_chat_uses_gemini_when_available(client, monkeypatch):
    captured = {}

    def fake_chat(message, history, ctx):
        captured["ctx"] = ctx
        return "Your HbA1c is in the diabetes range. How long have you felt thirsty?"

    monkeypatch.setattr(app_module.gemini, "api_key", "test-key")
    monkeypatch.setattr(app_module.gemini, "chat", fake_chat)
    r = client.post("/api/chat", json={"message": "Explain", "assessment": {"mode": "report",
                                                                            "biomarkers": {"hba1c": 7.1}}})
    assert r.json["source"] == "gemini"
    assert "HbA1c 7.1" in captured["ctx"]


def test_chat_falls_back_when_gemini_errors(client, monkeypatch):
    def boom(*a, **k):
        raise RuntimeError("quota exceeded")

    monkeypatch.setattr(app_module.gemini, "api_key", "test-key")
    monkeypatch.setattr(app_module.gemini, "chat", boom)
    r = client.post("/api/chat", json={"message": "hi"})
    assert r.status_code == 200 and r.json["source"] == "offline" and "notice" in r.json


def test_gemini_extraction_path(client, monkeypatch):
    monkeypatch.setattr(app_module.gemini, "api_key", "test-key")
    monkeypatch.setattr(app_module.gemini, "extract_report", lambda data, mime: {
        "patient_age": 61, "patient_sex": "female", "summary": "CBC and lipid panel",
        "tests": [{"key": "hemoglobin", "name": "Hb", "value": 105, "unit": "g/L"},
                  {"key": "other", "name": "Platelet count", "value": 95000, "unit": "/uL"},
                  {"key": "ldl", "name": "LDL", "value": 4.2, "unit": "mmol/L"}]})
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (600, 800), "white").save(buf, "JPEG")
    r = client.post("/api/report", data={"file": (io.BytesIO(buf.getvalue()), "photo.jpg")},
                    content_type="multipart/form-data")
    d = r.json
    assert r.status_code == 200 and d["method"] == "gemini_vision"
    assert d["biomarkers"]["hemoglobin"] == 10.5 and d["biomarkers"]["platelets"] == 95
    assert 160 < d["biomarkers"]["ldl"] < 165
    assert d["patient"] == {"age": 61, "sex": "female"}


def test_chat_validation(client):
    assert client.post("/api/chat", json={"message": ""}).status_code == 400
    assert client.post("/api/chat", json={"message": "x" * 5000}).status_code == 400


# ---------------------------------------------------------------- rate limiting (keep last)
def test_rate_limit_on_report_endpoint(client):
    codes = [client.post("/api/report", json={"text": "HbA1c 6.1 %"}).status_code for _ in range(8)]
    assert codes[:6] == [200] * 6 and 429 in codes[6:]
