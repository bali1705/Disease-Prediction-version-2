# Before vs. after performance comparison

Generated 2026-11-15 17:13 UTC · scikit-learn 1.9.1

Primary protocol: identical outer stratified 5-fold splits for both models; upgraded models are tuned with nested CV (selection on training folds only). Values are mean across folds. Δ = absolute change in percentage points (relative change in brackets).

## Diabetes — Stratified 5-fold CV

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 77.08% | 75.51% | -1.57 pp (-2.0%) |
| Precision | 72.17% | 69.96% | -2.22 pp (-3.1%) |
| Recall | 56.74% | 58.23% | +1.50 pp (+2.6%) |
| F1-score | 63.34% | 62.08% | -1.26 pp (-2.0%) |
| ROC-AUC | 83.21% | 83.53% | +0.31 pp (+0.4%) |

Upgraded model: Soft-voting ensemble (Random forest, Extra trees, Logistic regression)

## Heart disease — Stratified 5-fold CV

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 81.86% | 84.50% | +2.64 pp (+3.2%) |
| Precision | 82.53% | 85.82% | +3.29 pp (+4.0%) |
| Recall | 76.14% | 78.99% | +2.86 pp (+3.8%) |
| F1-score | 78.96% | 81.93% | +2.97 pp (+3.8%) |
| ROC-AUC | 88.82% | 91.21% | +2.39 pp (+2.7%) |

Upgraded model: Logistic regression

## Parkinson's disease — Person-grouped 5-fold CV (leakage-free)

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 83.05% | 79.62% | -3.43 pp (-4.1%) |
| Precision | 85.31% | 81.51% | -3.80 pp (-4.5%) |
| Recall | 93.89% | 94.02% | +0.13 pp (+0.1%) |
| F1-score | 89.20% | 87.24% | -1.96 pp (-2.2%) |
| ROC-AUC | 83.65% | 80.21% | -3.44 pp (-4.1%) |

Upgraded model: Extra trees

## Parkinson's disease — Random 5-fold CV (legacy protocol, leaks people across folds)

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 85.64% | 92.31% | +6.67 pp (+7.8%) |
| Precision | 87.41% | 94.08% | +6.67 pp (+7.6%) |
| Recall | 95.22% | 95.93% | +0.71 pp (+0.7%) |
| F1-score | 90.90% | 94.95% | +4.05 pp (+4.5%) |
| ROC-AUC | 88.57% | 97.55% | +8.98 pp (+10.1%) |

Upgraded model: Extra trees

## Symptom-based disease classifier (41 diseases) — All symptoms entered (unique profiles, 5-fold)

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 79.42% | 97.88% | +18.46 pp (+23.2%) |
| Precision | 76.90% | 98.52% | +21.62 pp (+28.1%) |
| Recall | 72.22% | 98.42% | +26.20 pp (+36.3%) |
| F1-score | 73.78% | 98.44% | +24.66 pp (+33.4%) |
| ROC-AUC | 93.69% | 99.98% | +6.28 pp (+6.7%) |

Upgraded model: Logistic regression

## Symptom-based disease classifier (41 diseases) — Partial & shuffled symptoms (realistic input, 5-fold)

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 10.40% | 91.82% | +81.42 pp (+783.1%) |
| Precision | 8.75% | 93.93% | +85.18 pp (+973.4%) |
| Recall | 15.14% | 94.28% | +79.14 pp (+522.6%) |
| F1-score | 8.11% | 94.04% | +85.92 pp (+1058.8%) |
| ROC-AUC | 63.11% | 99.89% | +36.78 pp (+58.3%) |

Upgraded model: Logistic regression

## Notes

- Heart: the Kaggle heart.csv stores the label inverted (target=1 is the healthy group). Both models are scored against the corrected label (1 = heart disease); the legacy app therefore reported 'heart disease' for the healthier profile.
- Heart: the upgraded model uses all 13 features (legacy dropped resting BP, resting ECG and vessel count) and treats invalid codes (ca=4, thal=0) as missing.
- Diabetes: zero values for glucose, blood pressure, skin thickness, insulin and BMI are treated as missing and imputed inside the pipeline (legacy model learned from them as real zeros).
- Parkinson's: ≈6 recordings per person; leakage-free scores split folds by person. The random-split row is shown only to compare with the legacy notebook protocol.
- Symptoms: 94% of the 4,920 training rows are duplicates, so any random split scores ~100%. Folds here are over unique symptom profiles. The legacy model needs symptoms in a fixed order and an exact count; in the partial/shuffled test it often cannot answer.
