# Before vs. after performance comparison

Generated 2026-11-15 17:48 UTC · scikit-learn 1.9.1

Primary protocol: identical outer stratified 5-fold splits for both models; upgraded models are tuned with nested CV (selection on training folds only, one-standard-error rule). Values are mean across folds. Δ = absolute change in percentage points (relative change in brackets).

## Diabetes — Stratified 5-fold CV

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 77.08% | 76.82% | -0.26 pp (-0.3%) |
| Precision | 72.17% | 71.68% | -0.50 pp (-0.7%) |
| Recall | 56.74% | 56.74% | +0.01 pp (+0.0%) |
| F1-score | 63.34% | 63.05% | -0.29 pp (-0.5%) |
| ROC-AUC | 83.21% | 83.68% | +0.47 pp (+0.6%) |

Deployed model (selected on all data): Logistic regression

## Heart disease — Stratified 5-fold CV

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 81.86% | 86.48% | +4.61 pp (+5.6%) |
| Precision | 82.53% | 89.14% | +6.61 pp (+8.0%) |
| Recall | 76.14% | 80.45% | +4.31 pp (+5.7%) |
| F1-score | 78.96% | 83.91% | +4.95 pp (+6.3%) |
| ROC-AUC | 88.82% | 91.82% | +3.00 pp (+3.4%) |

Deployed model (selected on all data): Logistic regression

## Parkinson's disease — Person-grouped 5-fold CV (leakage-free)

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 83.05% | 82.42% | -0.62 pp (-0.8%) |
| Precision | 85.31% | 84.98% | -0.33 pp (-0.4%) |
| Recall | 93.89% | 94.04% | +0.15 pp (+0.2%) |
| F1-score | 89.20% | 89.05% | -0.15 pp (-0.2%) |
| ROC-AUC | 83.65% | 81.45% | -2.20 pp (-2.6%) |

Deployed model (selected on all data): Logistic regression

## Parkinson's disease — Random 5-fold CV (legacy protocol, leaks people across folds)

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 85.64% | 93.85% | +8.21 pp (+9.6%) |
| Precision | 87.41% | 94.77% | +7.35 pp (+8.4%) |
| Recall | 95.22% | 97.31% | +2.09 pp (+2.2%) |
| F1-score | 90.90% | 95.98% | +5.08 pp (+5.6%) |
| ROC-AUC | 88.57% | 97.90% | +9.33 pp (+10.5%) |

Deployed model (selected on all data): Logistic regression

## Symptom-based disease classifier (41 diseases) — All symptoms entered (unique profiles, 5-fold)

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 79.42% | 97.88% | +18.46 pp (+23.2%) |
| Precision | 76.90% | 98.52% | +21.62 pp (+28.1%) |
| Recall | 72.22% | 98.42% | +26.20 pp (+36.3%) |
| F1-score | 73.78% | 98.44% | +24.66 pp (+33.4%) |
| ROC-AUC | 93.69% | 99.98% | +6.28 pp (+6.7%) |

Deployed model (selected on all data): Logistic regression

## Symptom-based disease classifier (41 diseases) — Partial & shuffled symptoms (realistic input, 5-fold)

| Metric | Before | After | Δ |
|---|---|---|---|
| Accuracy | 10.40% | 91.82% | +81.42 pp (+783.1%) |
| Precision | 8.75% | 93.93% | +85.18 pp (+973.4%) |
| Recall | 15.14% | 94.28% | +79.14 pp (+522.6%) |
| F1-score | 8.11% | 94.04% | +85.92 pp (+1058.8%) |
| ROC-AUC | 63.11% | 99.89% | +36.78 pp (+58.3%) |

Deployed model (selected on all data): Logistic regression

## Notes

- Heart: the Kaggle heart.csv stores the label inverted (target=1 is the healthy group). Both models are scored against the corrected label (1 = heart disease); the legacy app therefore reported 'heart disease' for the healthier profile.
- Heart: the upgraded model uses all 13 features (legacy dropped resting BP, resting ECG and vessel count) and treats invalid codes (ca=4, thal=0) as missing.
- Diabetes: zero values for glucose, blood pressure, skin thickness, insulin and BMI are treated as missing and imputed inside the pipeline (legacy model learned from them as real zeros).
- Parkinson's: ≈6 recordings per person; leakage-free scores split folds by person. The random-split row is shown only to compare with the legacy notebook protocol.
- Model selection (tabular models): each family is tuned by randomized search on 2x4-fold repeated inner CV, then the simplest model within one standard error of the best inner score is chosen. An earlier run that always picked the top inner score overfitted on the small diabetes and Parkinson's datasets; its results are kept in reports/backtest_report_v1_selection.md.
- Symptoms: 94% of the 4,920 training rows are duplicates, so any random split scores ~100%. Folds here are over unique symptom profiles. The legacy model needs symptoms in a fixed order and an exact count; in the partial/shuffled test it often cannot answer.
