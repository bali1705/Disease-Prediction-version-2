"""MedSight — multi-disease screening web application (Flask).

Run locally:   python app.py
Production:    gunicorn app:app --workers 2 --threads 4 --timeout 120 --preload
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()  # local development only; production reads real environment variables

from flask import Flask, jsonify, render_template, request  # noqa: E402
from flask_limiter import Limiter  # noqa: E402
from flask_limiter.util import get_remote_address  # noqa: E402
from werkzeug.exceptions import HTTPException  # noqa: E402
from werkzeug.middleware.proxy_fix import ProxyFix  # noqa: E402

from ml_pipeline.config import MODEL_SPECS, REPORTS_DIR  # noqa: E402
from ml_pipeline.predictor import registry  # noqa: E402
from ml_pipeline.symptom_catalog import catalog_for_ui as symptom_catalog  # noqa: E402
from services import validation  # noqa: E402
from services.assessment import assess, context_text  # noqa: E402
from services.assistant_offline import reply as offline_reply  # noqa: E402
from services.biomarkers import ORGANS  # noqa: E402
from services.biomarkers import catalog_for_ui as biomarker_catalog  # noqa: E402
from services.gemini_client import GeminiService  # noqa: E402
from services.report_parser import extract_pdf_text, normalize_ai_extraction, parse_report_text  # noqa: E402
from services.uploads import sweep_stale, temporary_upload, validate_upload, verify_image  # noqa: E402
from services.validation import ValidationError  # noqa: E402

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("medsight")

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", BASE_DIR / "tmp_uploads"))
MAX_UPLOAD_MB = int(os.environ.get("MAX_UPLOAD_MB", "8"))
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024

app = Flask(__name__)
app.config.update(MAX_CONTENT_LENGTH=MAX_UPLOAD_BYTES + 512 * 1024, JSON_SORT_KEYS=False,
                  TEMPLATES_AUTO_RELOAD=False)
# Render/Railway/HF sit behind one reverse proxy; trust it for the client IP used by rate limiting
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=int(os.environ.get("PROXY_HOPS", "1")), x_proto=1, x_host=1)

limiter = Limiter(
    get_remote_address, app=app,
    default_limits=["600 per hour"],
    storage_uri=os.environ.get("RATELIMIT_STORAGE_URI", "memory://"),
    headers_enabled=True, strategy="fixed-window",
)

gemini = GeminiService()
registry.warm_up()
sweep_stale(UPLOAD_DIR, max_age_s=0)


def _load_performance() -> dict:
    path = REPORTS_DIR / "backtest_results.json"
    if not path.exists():
        return {}
    data = json.loads(path.read_text())
    models = data.get("models", {})
    return {"generated_at": data.get("generated_at"), "comparison": data.get("comparison", []),
            "notes": data.get("notes", []),
            "leaderboards": {k: v.get("production_model", {}).get("leaderboard", []) for k, v in models.items()},
            "selected": {k: v.get("production_model", {}).get("selected") for k, v in models.items()}}


PERFORMANCE = _load_performance()


def _parkinsons_samples() -> dict:
    """One real recording per class from the public dataset, so visitors can try the voice model."""
    import pandas as pd
    from ml_pipeline.config import DATA_DIR, PARKINSONS_FEATURE_NAMES
    df = pd.read_csv(DATA_DIR / "parkinsons.csv")
    pick = {"healthy": df[df.status == 0].iloc[0], "parkinsons": df[df.status == 1].iloc[0]}
    return {k: {f: float(row[f]) for f in PARKINSONS_FEATURE_NAMES} for k, row in pick.items()}


PARKINSONS_SAMPLES = _parkinsons_samples()


# ---------------------------------------------------------------------------
# Hooks & error handling
# ---------------------------------------------------------------------------
@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    resp.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; "
        "frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.errorhandler(ValidationError)
def handle_validation(exc):
    return jsonify(error=str(exc)), 400


@app.errorhandler(413)
def too_large(_exc):
    return jsonify(error=f"The upload is larger than {MAX_UPLOAD_MB} MB. Compress it or upload fewer pages."), 413


@app.errorhandler(429)
def rate_limited(exc):
    return jsonify(error="Too many requests from your network. Wait a minute and try again.",
                   limit=str(getattr(exc, "description", ""))), 429


@app.errorhandler(HTTPException)
def http_error(exc):
    if request.path.startswith("/api/"):
        return jsonify(error=exc.description or exc.name), exc.code
    return exc


@app.errorhandler(Exception)
def unhandled(exc):
    log.exception("unhandled error on %s", request.path)
    return jsonify(error="Something went wrong on our side. Try again in a moment."), 500


def _json_body() -> dict:
    data = request.get_json(silent=True)
    if data is None:
        raise ValidationError("Send a JSON body with Content-Type: application/json.")
    return data


# ---------------------------------------------------------------------------
# Pages
# ---------------------------------------------------------------------------
@app.get("/")
def index():
    return render_template("index.html", ai_available=gemini.available)


@app.get("/healthz")
@limiter.exempt
def healthz():
    return jsonify(status="ok", ai=gemini.available)


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
@app.get("/api/meta")
@limiter.limit("60 per minute")
def meta():
    return jsonify(
        symptoms=symptom_catalog(), biomarkers=biomarker_catalog(), organs=ORGANS,
        models={k: {"title": v["title"], "features": v["features"]} for k, v in MODEL_SPECS.items()},
        ai_available=gemini.available, max_upload_mb=MAX_UPLOAD_MB, parkinsons_samples=PARKINSONS_SAMPLES,
    )


@app.get("/api/performance")
@limiter.limit("60 per minute")
def performance():
    return jsonify(PERFORMANCE)


@app.post("/api/assess")
@limiter.limit("40 per minute")
def api_assess():
    payload = validation.assessment_payload(_json_body())
    return jsonify(assess(payload))


@app.post("/api/followup")
@limiter.limit("60 per minute")
def api_followup():
    data = _json_body()
    q = registry.next_question(validation.symptoms(data.get("symptoms")),
                               validation.symptoms(data.get("denied"), "denied"),
                               exclude=validation.symptoms(data.get("exclude"), "exclude"))
    return jsonify(followup=q)


@app.post("/api/predict/<model>")
@limiter.limit("40 per minute")
def api_predict(model: str):
    if model not in MODEL_SPECS:
        return jsonify(error="Unknown model. Use diabetes, heart or parkinsons."), 404
    values = validation.model_features(model, _json_body())
    if not values:
        raise ValidationError("Enter at least one value.")
    if model == "parkinsons" and len(values) < len(MODEL_SPECS["parkinsons"]["features"]):
        raise ValidationError("The Parkinson's voice model needs all 22 voice measurements.")
    return jsonify(registry.predict_tabular(model, values))


@app.post("/api/report")
@limiter.limit("6 per minute; 60 per day")
def api_report():
    """Extract biomarkers from an uploaded report (multipart 'file') or pasted text (JSON 'text')."""
    sweep_stale(UPLOAD_DIR)
    warnings: list[str] = []
    if request.files.get("file"):
        f = request.files["file"]
        data = f.read(MAX_UPLOAD_BYTES + 1)
        mime = validate_upload(f.filename or "", data, MAX_UPLOAD_BYTES)
        ext = "pdf" if mime == "application/pdf" else mime.split("/")[1]
        with temporary_upload(UPLOAD_DIR, data, ext) as path:
            if mime != "application/pdf":
                verify_image(path)
            result, method = None, None
            if gemini.available:
                try:
                    result = normalize_ai_extraction(gemini.extract_report(data, mime))
                    method = "gemini_vision"
                except Exception as exc:  # network / quota / parsing problems -> fall back
                    log.warning("Gemini extraction failed: %s", exc)
                    warnings.append("AI report reading is temporarily unavailable, so a basic text reader "
                                    "was used.")
            if (result is None or not result["biomarkers"]) and mime == "application/pdf":
                text = extract_pdf_text(str(path))
                if len(text.strip()) > 40:
                    parsed = parse_report_text(text)
                    if result is None or len(parsed["biomarkers"]) > len(result["biomarkers"]):
                        result, method = parsed, "pdf_text"
                elif result is None:
                    warnings.append("This PDF is a scanned image with no text layer.")
            if result is None:
                msg = ("Reading photos and scanned reports needs the AI service, which is "
                       + ("unavailable right now" if gemini.available else "not configured on this server")
                       + ". Paste the report text instead, or type the values in manually.")
                return jsonify(error=msg, warnings=warnings), 422
    else:
        body = request.get_json(silent=True) or {}
        text = body.get("text")
        if not isinstance(text, str) or len(text.strip()) < 5:
            raise ValidationError("Upload a file or paste the report text.")
        if len(text) > 30_000:
            raise ValidationError("Pasted text is too long (max 30,000 characters).")
        result, method = parse_report_text(text), "text"
    if not result["biomarkers"]:
        warnings.append("No recognisable lab values were found. Check that the report is readable, or enter "
                        "values manually.")
    clean_values = validation.biomarkers(result["biomarkers"])
    return jsonify(biomarkers=clean_values, patient=result.get("patient", {}), method=method,
                   summary=result.get("summary", ""), found=len(clean_values), warnings=warnings)


@app.post("/api/chat")
@limiter.limit("12 per minute; 150 per day")
def api_chat():
    message, history, assessment_input = validation.chat_payload(_json_body())
    result = assess(assessment_input)
    ctx = context_text(result)
    if gemini.available:
        try:
            return jsonify(reply=gemini.chat(message, history, ctx), source="gemini")
        except Exception as exc:
            log.warning("Gemini chat failed, using offline assistant: %s", exc)
            return jsonify(reply=offline_reply(message, history, result), source="offline",
                           notice="The AI assistant is temporarily unavailable; showing built-in guidance.")
    return jsonify(reply=offline_reply(message, history, result), source="offline")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=os.environ.get("FLASK_DEBUG") == "1")
