/* MedSight dashboard — vanilla JS, no external dependencies (CSP: script-src 'self'). */
(() => {
  "use strict";

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const fmt = (n) => (n == null || Number.isNaN(n) ? "–" : Number(n).toLocaleString(undefined, { maximumFractionDigits: n < 10 ? 2 : 1 }));
  const pct = (p) => `${Math.min(99, Math.round(p * 100))}%`; // screening estimates never shown as certain
  const STATUS_TEXT = { normal: "Normal", borderline: "Borderline", high_risk: "High risk" };
  const RISK_TEXT = { normal: "Low risk", borderline: "Moderate risk", high_risk: "High risk" };

  const state = {
    meta: null, mode: "symptoms", step: "symptoms",
    symptoms: new Set(), denied: new Set(), skipped: new Set(),
    biomarkers: {}, patient: {}, clinical: {},
    result: null, zoom: 1, chat: [], chatFresh: false, busy: false,
  };

  // Organ anchor points in body-SVG coordinates and the side their callout sits on
  const ANCHORS = {
    brain: [200, 52, "L"], lungs: [166, 236, "L"], liver: [176, 304, "L"], kidneys: [166, 346, "L"],
    blood: [99, 350, "L"], intestines: [186, 394, "L"], body: [160, 470, "L"],
    thyroid: [200, 140, "R"], arteries: [203, 214, "R"], heart: [212, 258, "R"], skin: [298, 262, "R"],
    stomach: [240, 316, "R"], pancreas: [228, 338, "R"], bladder: [200, 444, "R"], joints: [230, 612, "R"],
  };
  const SHORT = {
    heart_rate: "HR", spo2: "SpO₂", temperature: "Temp", respiratory_rate: "Resp", bmi: "BMI",
    fasting_glucose: "Fasting glucose", random_glucose: "Glucose", hba1c: "HbA1c", insulin: "Insulin",
    total_cholesterol: "Chol", ldl: "LDL", hdl: "HDL", triglycerides: "TG", creatinine: "Creatinine",
    blood_urea: "Urea", bun: "BUN", egfr: "eGFR", uric_acid: "Uric acid", sodium: "Na", potassium: "K",
    alt: "SGPT", ast: "SGOT", alp: "ALP", total_bilirubin: "Bilirubin", direct_bilirubin: "D. bilirubin",
    albumin: "Albumin", hemoglobin: "Hb", wbc: "WBC", platelets: "Platelets", rbc: "RBC", hematocrit: "PCV",
    mcv: "MCV", crp: "CRP", esr: "ESR", tsh: "TSH", free_t4: "Free T4", t3: "T3", troponin: "Troponin",
  };
  const KEY_FIELDS = ["heart_rate", "systolic_bp", "diastolic_bp", "spo2", "temperature", "fasting_glucose",
    "hba1c", "total_cholesterol", "ldl", "hdl", "triglycerides", "hemoglobin", "platelets", "creatinine"];
  const MODE_HINT = {
    symptoms: "Pick your symptoms. We'll ask follow-up questions to narrow things down.",
    report: "Upload a lab report or type values in. Out-of-range results are flagged on the body.",
    combined: "Combine symptoms with lab results for the most complete picture.",
  };
  const RUN_LABEL = { symptoms: "Analyse symptoms", report: "Analyse report", combined: "Run combined assessment" };

  // ---------------------------------------------------------------- utilities
  let toastTimer;
  function toast(msg, isError = false) {
    let el = $(".toast");
    if (!el) { el = document.createElement("div"); el.className = "toast"; el.setAttribute("role", "status"); document.body.appendChild(el); }
    el.textContent = msg;
    el.classList.toggle("error", isError);
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, isError ? 6000 : 3500);
  }

  async function api(path, body, opts = {}) {
    const init = { method: body === undefined ? "GET" : "POST", headers: {} };
    if (body instanceof FormData) init.body = body;
    else if (body !== undefined) { init.body = JSON.stringify(body); init.headers["Content-Type"] = "application/json"; }
    let res;
    try { res = await fetch(path, init); } catch (e) { throw new Error("Can't reach the server. Check your connection and try again."); }
    let data = {};
    try { data = await res.json(); } catch (e) { /* non-JSON */ }
    if (!res.ok && !opts.allowError) throw new Error(data.error || `Request failed (${res.status}).`);
    return data;
  }

  // ---------------------------------------------------------------- navigation
  function showView(name) {
    $$(".nav button").forEach((b) => b.setAttribute("aria-current", b.dataset.view === name ? "page" : "false"));
    $$(".view").forEach((v) => v.classList.toggle("active", v.id === `view-${name}`));
    if (name === "performance") loadPerformance();
    if (name === "dashboard") requestAnimationFrame(layoutCallouts);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function setMode(mode) {
    state.mode = mode;
    $$(".modes button").forEach((b) => b.setAttribute("aria-checked", String(b.dataset.mode === mode)));
    $("#modeHint").textContent = MODE_HINT[mode];
    $("#runLabel").textContent = RUN_LABEL[mode];
    $("#stepTabs").hidden = mode !== "combined";
    if (mode === "symptoms") setStep("symptoms");
    else if (mode === "report") setStep("report");
    else setStep(state.step);
  }

  function setStep(step) {
    state.step = step;
    $$("#stepTabs button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.step === step)));
    $("#panel-symptoms").hidden = step !== "symptoms";
    $("#panel-report").hidden = step !== "report";
  }

  // ---------------------------------------------------------------- symptom picker
  function buildSymptomPicker() {
    const wrap = $("#symptomCats");
    wrap.innerHTML = state.meta.symptoms.map((cat, i) => `
      <div class="cat" data-cat="${esc(cat.id)}">
        <button type="button" aria-expanded="${i === 0}" aria-controls="cat-${esc(cat.id)}">
          <span>${esc(cat.title)}<span class="count" hidden></span></span><svg aria-hidden="true"><use href="#i-chev"/></svg>
        </button>
        <div class="chips" id="cat-${esc(cat.id)}" ${i === 0 ? "" : "hidden"}>
          ${cat.symptoms.map((s) => `<button type="button" class="chip" data-sym="${esc(s.key)}" aria-pressed="false">${esc(s.label)}</button>`).join("")}
        </div>
      </div>`).join("");
    wrap.addEventListener("click", (e) => {
      const head = e.target.closest(".cat > button");
      if (head) {
        const open = head.getAttribute("aria-expanded") !== "true";
        head.setAttribute("aria-expanded", String(open));
        head.nextElementSibling.hidden = !open;
        return;
      }
      const chip = e.target.closest("[data-sym]");
      if (chip) toggleSymptom(chip.dataset.sym);
    });
    $("#symptomSearch").addEventListener("input", (e) => filterSymptoms(e.target.value));
    $("#chosenSymptoms").addEventListener("click", (e) => {
      const chip = e.target.closest("[data-remove]");
      if (!chip) return;
      state.symptoms.delete(chip.dataset.remove);
      state.denied.delete(chip.dataset.remove);
      syncSymptoms();
    });
    $("#clearSymptoms").addEventListener("click", () => { state.symptoms.clear(); state.denied.clear(); state.skipped.clear(); syncSymptoms(); $("#followup").hidden = true; });
  }

  const symptomLabel = (key) => {
    for (const c of state.meta.symptoms) for (const s of c.symptoms) if (s.key === key) return s.label;
    return key;
  };

  function toggleSymptom(key) {
    if (state.symptoms.has(key)) state.symptoms.delete(key);
    else { state.symptoms.add(key); state.denied.delete(key); }
    syncSymptoms();
  }

  function syncSymptoms() {
    $$("[data-sym]").forEach((b) => b.setAttribute("aria-pressed", String(state.symptoms.has(b.dataset.sym))));
    const chosen = [...state.symptoms].map((k) => `<button type="button" class="chip" aria-pressed="true" data-remove="${esc(k)}" aria-label="Remove ${esc(symptomLabel(k))}">${esc(symptomLabel(k))}<span class="x" aria-hidden="true">×</span></button>`);
    const denied = [...state.denied].map((k) => `<button type="button" class="chip denied" data-remove="${esc(k)}" title="You said you don't have this. Click to undo.">${esc(symptomLabel(k))}</button>`);
    $("#chosenSymptoms").innerHTML = chosen.join("") + denied.join("");
    $$(".cat").forEach((cat) => {
      const n = $$("[data-sym]", cat).filter((b) => state.symptoms.has(b.dataset.sym)).length;
      const c = $(".count", cat);
      c.hidden = n === 0;
      c.textContent = n;
    });
  }

  function filterSymptoms(q) {
    q = q.trim().toLowerCase();
    $$(".cat").forEach((cat, i) => {
      let any = false;
      $$("[data-sym]", cat).forEach((b) => {
        const hit = !q || b.textContent.toLowerCase().includes(q);
        b.hidden = !hit;
        any = any || hit;
      });
      cat.hidden = !any;
      const head = $(":scope > button", cat);
      const open = q ? any : i === 0;
      head.setAttribute("aria-expanded", String(open));
      head.nextElementSibling.hidden = !open;
    });
  }

  // ---------------------------------------------------------------- vitals / lab inputs
  function markerField(m) {
    return `<div class="field"><label for="bm-${esc(m.key)}">${esc(m.label)}</label>
      <div class="input-unit"><input class="input" id="bm-${esc(m.key)}" data-bm="${esc(m.key)}" type="number" step="any"
        min="${m.plausible[0]}" max="${m.plausible[1]}" placeholder="${esc(m.normal_range.replace(m.unit, "").trim())}" title="Typical: ${esc(m.normal_range)}"><span>${esc(m.unit)}</span></div></div>`;
  }

  function buildMarkerInputs() {
    const byKey = Object.fromEntries(state.meta.biomarkers.map((m) => [m.key, m]));
    $("#vitalFields").innerHTML = KEY_FIELDS.map((k) => markerField(byKey[k])).join("");
    $("#moreFields").innerHTML = state.meta.biomarkers.filter((m) => !KEY_FIELDS.includes(m.key)).map(markerField).join("");
    $("#panel-report").addEventListener("input", (e) => {
      const el = e.target;
      if (el.dataset.bm) {
        const v = el.value.trim();
        if (v === "") delete state.biomarkers[el.dataset.bm];
        else state.biomarkers[el.dataset.bm] = Number(v);
      }
    });
    $("#showAllMarkers").addEventListener("click", (e) => {
      const more = $("#moreFields");
      more.hidden = !more.hidden;
      e.target.textContent = more.hidden ? "Show all lab values" : "Show fewer lab values";
    });
    $("#maxMb").textContent = state.meta.max_upload_mb;
  }

  function readPatient() {
    const p = {};
    const age = $("#p-age").value, sex = $("#p-sex").value, h = $("#p-height").value, w = $("#p-weight").value;
    if (age) p.age = Number(age);
    if (sex) p.sex = sex;
    if (h) p.height_cm = Number(h);
    if (w) p.weight_kg = Number(w);
    return p;
  }

  function applyExtraction(data) {
    Object.entries(data.biomarkers || {}).forEach(([k, v]) => {
      state.biomarkers[k] = v;
      const input = $(`[data-bm="${k}"]`);
      if (input) input.value = v;
      if (input && input.closest("#moreFields")) { $("#moreFields").hidden = false; $("#showAllMarkers").textContent = "Show fewer lab values"; }
    });
    const p = data.patient || {};
    if (p.age && !$("#p-age").value) $("#p-age").value = p.age;
    if (p.sex && !$("#p-sex").value) $("#p-sex").value = p.sex;
    $("#manualBox").open = true;
  }

  const METHOD_TEXT = { gemini_vision: "read with AI vision", pdf_text: "read from the PDF text", text: "read from your text" };

  async function uploadReport(file) {
    const status = $("#reportStatus");
    $("#fileInfo").innerHTML = `<div class="file-pill"><span>${esc(file.name)} · ${(file.size / 1024 / 1024).toFixed(2)} MB</span><span class="spinner" aria-hidden="true"></span></div>`;
    status.className = "status-line";
    status.textContent = "Reading your report…";
    const fd = new FormData();
    fd.append("file", file);
    try {
      const data = await api("/api/report", fd);
      handleExtraction(data);
    } catch (err) {
      status.className = "status-line error";
      status.textContent = err.message;
      $("#pasteBox").open = true;
    } finally {
      const sp = $("#fileInfo .spinner");
      if (sp) sp.remove();
    }
  }

  function handleExtraction(data) {
    const status = $("#reportStatus");
    applyExtraction(data);
    const warn = (data.warnings || []).join(" ");
    status.className = "status-line" + (data.found ? "" : " error");
    status.textContent = data.found
      ? `Found ${data.found} value${data.found === 1 ? "" : "s"} (${METHOD_TEXT[data.method] || "extracted"}). Check them below, then run the assessment. ${warn}`
      : warn || "No values found.";
    if (data.found) runAssessment();
  }

  // ---------------------------------------------------------------- assessment
  function payload() {
    return {
      mode: state.mode, symptoms: [...state.symptoms], denied: [...state.denied],
      biomarkers: state.biomarkers, patient: readPatient(), clinical: state.clinical,
    };
  }

  async function runAssessment() {
    const p = payload();
    const hasSym = p.symptoms.length > 0, hasLab = Object.keys(p.biomarkers).length > 0 || p.patient.height_cm;
    if (state.mode === "symptoms" && !hasSym) return toast("Choose at least one symptom first.", true);
    if (state.mode === "report" && !hasLab) return toast("Upload a report or enter at least one value first.", true);
    if (state.mode === "combined" && !hasSym && !hasLab) return toast("Add symptoms, lab values or both first.", true);
    const btn = $("#runBtn");
    btn.disabled = true;
    $("#runLabel").textContent = "Analysing…";
    try {
      const result = await api("/api/assess", p);
      state.result = result;
      renderResults(result);
      state.chatFresh = true;
      $("#chatBadge").hidden = $("#chat").classList.contains("open");
    } catch (err) {
      toast(err.message, true);
    } finally {
      btn.disabled = false;
      $("#runLabel").textContent = RUN_LABEL[state.mode];
    }
  }

  function renderResults(r) {
    renderOverview(r);
    renderGauges(r.ml_risks);
    renderDifferential(r.differential);
    renderSteps(r.next_steps);
    renderBody(r);
    renderBiomarkerGrid(r.biomarkers);
    renderFollowup(r.followup);
  }

  function renderOverview(r) {
    const alert = $("#alertBox");
    if (r.red_flags.length) {
      alert.hidden = false;
      alert.innerHTML = `<h3>Get urgent medical help</h3><ul>${r.red_flags.map((f) => `<li>${esc(f)}</li>`).join("")}</ul>`;
    } else alert.hidden = true;
    const s = r.summary;
    const pill = $("#overallPill");
    pill.className = `pill ${s.overall}`;
    pill.textContent = { normal: "Looks reassuring", borderline: "Worth checking", high_risk: "Needs attention" }[s.overall];
    if (s.markers) {
      $("#overallBig").innerHTML = `${s.abnormal_markers}<small> of ${s.markers} values out of range</small>`;
    } else {
      $("#overallBig").innerHTML = `${r.symptoms.length}<small> symptom${r.symptoms.length === 1 ? "" : "s"} analysed</small>`;
    }
    $("#overallSub").textContent = s.top ? `Most likely match: ${s.top}. This is a screening estimate, not a diagnosis.` : "No strong matches found.";
  }

  function gaugeSVG(p, level) {
    const n = 30, cx = 90, cy = 88, r1 = 62, r2 = 80;
    const active = Math.round(p * n);
    const color = { normal: "#18a46f", borderline: "#e99a1d", high_risk: "#e5484d" }[level];
    let ticks = "";
    for (let i = 0; i < n; i++) {
      const a = Math.PI - (i + 0.5) * (Math.PI / n);
      const x1 = cx + r1 * Math.cos(a), y1 = cy - r1 * Math.sin(a), x2 = cx + r2 * Math.cos(a), y2 = cy - r2 * Math.sin(a);
      ticks += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${i < active ? color : "#e1e7ef"}" stroke-width="5" stroke-linecap="round"/>`;
    }
    return `<svg viewBox="0 0 180 96" aria-hidden="true">${ticks}</svg>`;
  }

  function gaugeHTML(r) {
    return `<div class="gauge">${gaugeSVG(r.probability, r.level)}
      <div class="num">${Math.min(99, Math.round(r.probability * 100))}<small>%</small></div>
      <div class="lbl">${esc(r.title)} risk</div>
      <div class="note">${r.inputs_provided}/${r.inputs_total} inputs · <span class="${r.level}-c">${RISK_TEXT[r.level]}</span></div></div>`;
  }

  function renderGauges(risks) {
    const el = $("#gauges");
    el.innerHTML = risks.length ? risks.map(gaugeHTML).join("")
      : `<p class="empty-note" style="grid-column:1/-1">Add a glucose value (diabetes) or age with blood pressure / cholesterol (heart) to see model risk.</p>`;
  }

  const SRC_LABEL = { symptoms: "Symptoms", labs: "Lab values", ml_model: "ML model" };
  const KIND_NOTE = { probability: "model probability", lab_evidence: "lab-evidence score", model_risk: "model risk" };

  function renderDifferential(list) {
    const el = $("#diffList");
    if (!list.length) { el.innerHTML = `<li><p class="empty-note">No matches yet. Add more symptoms or values.</p></li>`; return; }
    el.innerHTML = list.map((d) => `
      <li>
        <div class="row1"><span class="name">${esc(d.name)}</span><span class="pct">${pct(d.confidence)}</span></div>
        <div class="bar" role="img" aria-label="${pct(d.confidence)} ${esc(KIND_NOTE[d.kind])}"><i style="width:${Math.max(2, d.confidence * 100)}%"></i></div>
        <div class="tags">
          ${d.sources.map((s) => `<span class="tag src-${esc(s)}">${esc(SRC_LABEL[s] || s)}</span>`).join("")}
          ${d.urgency !== "routine" ? `<span class="tag ${esc(d.urgency)}">${d.urgency === "urgent" ? "Urgent" : "See a doctor soon"}</span>` : ""}
        </div>
        <div class="meta">${esc(d.specialist)} · ${esc(KIND_NOTE[d.kind])}${d.evidence && d.evidence.length > 1 ? " · " + esc(d.evidence.slice(1, 3).join(", ")) : ""}</div>
      </li>`).join("");
  }

  function renderSteps(steps) {
    $("#nextSteps").innerHTML = steps.map((s) => `<li class="${esc(s.priority)}">${esc(s.text)}</li>`).join("");
  }

  function renderFollowup(f) {
    const box = $("#followup");
    if (state.mode === "report" || !f) { box.hidden = true; return; }
    if (state.skipped.has(f.symptom)) {
      api("/api/followup", { symptoms: [...state.symptoms], denied: [...state.denied], exclude: [...state.skipped] })
        .then((d) => renderFollowup(d.followup && !state.skipped.has(d.followup.symptom) ? d.followup : null)).catch(() => {});
      return;
    }
    box.hidden = false;
    box.dataset.sym = f.symptom;
    $("#followupQ").textContent = f.question;
    $("#followupWhy").textContent = f.why;
  }

  // ---------------------------------------------------------------- range bar
  function rangeBar(b) {
    const [lo, hi] = b.scale.normal;
    const pts = [b.value, lo, hi, ...b.scale.borderline.flat()].filter((x) => x != null && Number.isFinite(x));
    let min = Math.min(...pts), max = Math.max(...pts);
    const span = (max - min) || Math.abs(max) || 1;
    const nice = (x) => (Math.abs(x) >= 10 ? Math.round(x) : Math.round(x * 10) / 10);
    min = nice(Math.max(b.scale.plausible[0], lo === 0 || lo == null ? 0 : min - span * 0.25));
    max = nice(Math.min(b.scale.plausible[1], max + span * 0.25));
    const pos = (x) => Math.min(100, Math.max(0, ((x - min) / (max - min)) * 100));
    const seg = (a, z, cls) => `<span class="seg ${cls}" style="left:${pos(a ?? min)}%;width:${Math.max(0, pos(z ?? max) - pos(a ?? min))}%"></span>`;
    const border = b.scale.borderline.map(([a, z]) => seg(a, z, "borderline")).join("");
    return `<div class="range" role="img" aria-label="Value ${fmt(b.value)} ${esc(b.unit)}; typical ${esc(b.normal_range)}">${border}${seg(lo, hi, "normal")}<span class="pin" style="left:${pos(b.value)}%"></span></div>
      <div class="range-labels"><span>${fmt(min)}</span><span>Typical: ${esc(b.normal_range)}</span><span>${fmt(max)}</span></div>`;
  }

  function renderBiomarkerGrid(items) {
    const sec = $("#biomarkerSection");
    sec.hidden = !items.length;
    $("#bmGrid").innerHTML = items.map((b) => `
      <article class="bm">
        <div class="top"><span class="name">${esc(b.label)}</span><span class="pill ${b.status}">${STATUS_TEXT[b.status]}</span></div>
        <div class="val">${fmt(b.value)}<small>${esc(b.unit)}</small></div>
        ${rangeBar(b)}
        <p>${esc(b.status === "normal" ? b.about : b.meaning || b.about)}</p>
      </article>`).join("");
  }

  // ---------------------------------------------------------------- body map
  function organLine(o, items) {
    const byKey = Object.fromEntries(items.map((b) => [b.key, b]));
    const parts = [];
    if (o.markers.includes("systolic_bp") || o.markers.includes("diastolic_bp")) {
      parts.push(`BP ${fmt(byKey.systolic_bp?.value)}/${fmt(byKey.diastolic_bp?.value)} mmHg`);
    }
    o.markers.filter((k) => k !== "systolic_bp" && k !== "diastolic_bp").forEach((k) => {
      const b = byKey[k];
      if (b) parts.push(`${SHORT[k] || b.label} ${fmt(b.value)} ${b.unit}`);
    });
    const shown = parts.slice(0, 2);
    if (parts.length > 2) shown.push(`+${parts.length - 2} more`);
    if (o.ml_risk) shown.push(`${o.ml_risk.title} risk ${pct(o.ml_risk.probability)}`);
    if (!shown.length && o.symptoms.length) shown.push(o.symptoms.slice(0, 2).join(", ") + (o.symptoms.length > 2 ? ` +${o.symptoms.length - 2}` : ""));
    return shown.join(" · ");
  }

  function renderBody(r) {
    const stage = $("#stage");
    const organs = Object.values(r.organs).filter((o) => ANCHORS[o.organ]);
    stage.classList.toggle("has-data", organs.length > 0);
    $("#stageEmpty").hidden = organs.length > 0;
    $$(".organ").forEach((g) => { g.classList.remove("flagged", "normal", "borderline", "high_risk"); });
    const anchors = $(".anchors", stage);
    anchors.innerHTML = "";
    const colors = { normal: "#18a46f", borderline: "#e99a1d", high_risk: "#e5484d" };
    organs.forEach((o) => {
      const g = $(`#organ-${o.organ}`);
      if (g) g.classList.add("flagged", o.status);
      const [x, y] = ANCHORS[o.organ];
      anchors.insertAdjacentHTML("beforeend",
        (o.status !== "normal" ? `<circle class="anchor-ring" cx="${x}" cy="${y}" r="7" stroke="${colors[o.status]}"/>` : "") +
        `<circle class="anchor-dot" cx="${x}" cy="${y}" r="6" fill="${colors[o.status]}"/>`);
    });
    const order = { high_risk: 0, borderline: 1, normal: 2 };
    $("#callouts").innerHTML = organs.sort((a, b) => order[a.status] - order[b.status]).map((o) => {
      const status = o.sources.length === 1 && o.sources[0] === "symptoms" ? "Symptoms reported" : STATUS_TEXT[o.status];
      return `<button type="button" class="callout" data-organ="${esc(o.organ)}" aria-expanded="false" aria-haspopup="dialog">
        <span class="dot bg-${o.status}" aria-hidden="true"></span>
        <span><span class="t">${esc(o.title)}</span><span class="v">${esc(organLine(o, r.biomarkers))}</span>
        <span class="s ${o.status}-c">${esc(status)}</span></span></button>`;
    }).join("");
    closeOrganPop();
    requestAnimationFrame(layoutCallouts);
  }

  function layoutCallouts() {
    const stage = $("#stage");
    const leaders = $("#leaders");
    const calls = $$(".callout", stage);
    leaders.innerHTML = "";
    if (!calls.length || window.matchMedia("(max-width: 1000px)").matches) return;
    const sRect = stage.getBoundingClientRect();
    const svg = $(".body-svg", stage);
    const bRect = svg.getBoundingClientRect();
    const scale = bRect.width / 400;
    const W = sRect.width, H = stage.offsetHeight, gap = 10;
    const colors = { normal: "#18a46f", borderline: "#e99a1d", high_risk: "#e5484d" };
    const sides = { L: [], R: [] };
    calls.forEach((c) => {
      const [x, y, side] = ANCHORS[c.dataset.organ];
      sides[side].push({ c, ax: bRect.left - sRect.left + x * scale, ay: bRect.top - sRect.top + y * scale, h: c.offsetHeight, w: c.offsetWidth });
    });
    Object.entries(sides).forEach(([side, list]) => {
      list.sort((a, b) => a.ay - b.ay);
      let cursor = 0;
      list.forEach((it) => { it.top = Math.max(it.ay - it.h / 2, cursor); cursor = it.top + it.h + gap; });
      const overflow = cursor - gap - (H - 70);
      if (overflow > 0) { // push the stack back up, keeping order
        let limit = H - 70;
        for (let i = list.length - 1; i >= 0; i--) { list[i].top = Math.min(list[i].top, limit - list[i].h); limit = list[i].top - gap; }
      }
      list.forEach((it) => {
        const left = side === "L" ? 0 : W - it.w;
        it.c.style.left = `${left}px`;
        it.c.style.top = `${Math.max(0, it.top)}px`;
        const ex = side === "L" ? left + it.w : left;
        const ey = Math.max(0, it.top) + Math.min(26, it.h / 2);
        const elbow = side === "L" ? ex + 18 : ex - 18;
        const status = [...it.c.querySelector(".dot").classList].find((k) => k.startsWith("bg-")).slice(3);
        leaders.insertAdjacentHTML("beforeend",
          `<path d="M${ex},${ey} H${elbow} L${it.ax},${it.ay}" stroke="${colors[status]}"/>` +
          `<circle cx="${ex}" cy="${ey}" r="3" fill="${colors[status]}"/>`);
      });
    });
  }

  function openOrganPop(organ, trigger) {
    const r = state.result;
    if (!r || !r.organs[organ]) return;
    const o = r.organs[organ];
    const items = r.biomarkers.filter((b) => b.organ === organ);
    const pop = $("#organPop");
    pop.innerHTML = `<button type="button" class="close" aria-label="Close">×</button>
      <h3 id="organPopTitle">${esc(o.title)}</h3><span class="pill ${o.status}">${STATUS_TEXT[o.status]}</span>
      <div style="margin-top:10px">
      ${items.map((b) => `<div class="marker-row">
          <div class="top"><span class="name">${esc(b.label)}</span><span class="val ${b.status}-c">${fmt(b.value)} ${esc(b.unit)}</span></div>
          ${rangeBar(b)}
          <p>${esc(b.about)}${b.status !== "normal" && b.meaning ? " " + esc(b.meaning) : ""}</p></div>`).join("")}
      ${o.ml_risk ? `<div class="marker-row"><div class="top"><span class="name">${esc(o.ml_risk.title)} risk (ML model)</span><span class="val">${pct(o.ml_risk.probability)}</span></div><p>Estimated by a model trained on clinical data. It is a statistical estimate, not a diagnosis.</p></div>` : ""}
      ${o.symptoms.length ? `<div class="marker-row"><div class="name">Symptoms you reported</div><p>${esc(o.symptoms.join(", "))}</p></div>` : ""}
      </div>
      <button type="button" class="btn btn-sm btn-blue" data-ask="${esc(o.title)}" style="margin-top:12px">Ask the assistant about this</button>`;
    pop.hidden = false;
    const stage = $("#stage").getBoundingClientRect();
    const t = trigger.getBoundingClientRect();
    if (!window.matchMedia("(max-width: 1000px)").matches) {
      const left = t.left - stage.left < stage.width / 2 ? t.right - stage.left + 12 : t.left - stage.left - pop.offsetWidth - 12;
      pop.style.left = `${Math.max(0, Math.min(stage.width - pop.offsetWidth, left))}px`;
      pop.style.top = `${Math.max(0, Math.min($("#stage").offsetHeight - pop.offsetHeight - 10, t.top - stage.top - 10))}px`;
    }
    $$(".callout").forEach((c) => c.setAttribute("aria-expanded", String(c === trigger)));
    $(".close", pop).focus();
    $(".close", pop).addEventListener("click", () => { closeOrganPop(); trigger.focus(); });
    $("[data-ask]", pop).addEventListener("click", (e) => { openChat(`Can you explain my ${e.target.dataset.ask.toLowerCase()} results?`); });
  }

  function closeOrganPop() {
    $("#organPop").hidden = true;
    $$(".callout").forEach((c) => c.setAttribute("aria-expanded", "false"));
  }

  function setZoom(z) {
    state.zoom = Math.min(1.6, Math.max(0.8, z));
    $("#figure").style.transform = `translateX(-50%) scale(${state.zoom})`;
    setTimeout(layoutCallouts, 380);
  }

  // ---------------------------------------------------------------- clinical models view
  function buildModelForms() {
    const grid = $("#modelsGrid");
    const intro = {
      diabetes: "Estimates the chance of diabetes from routine measurements.",
      heart: "Estimates the chance of coronary heart disease. Stress-test fields come from a cardiology work-up.",
      parkinsons: "Uses 22 voice measurements from a sustained 'aaah' recording analysed with voice software.",
    };
    grid.innerHTML = Object.entries(state.meta.models).map(([key, m]) => `
      <section class="card" data-model="${esc(key)}">
        <h2>${esc(m.title)}</h2><p class="card-sub">${esc(intro[key])}</p>
        ${key === "parkinsons" ? `<div class="actions-row" style="margin-top:12px;flex-wrap:wrap"><button type="button" class="btn btn-sm" data-sample="healthy">Load a healthy sample</button><button type="button" class="btn btn-sm" data-sample="parkinsons">Load a Parkinson's sample</button></div>` : ""}
        <form class="model-form" novalidate>
          ${m.features.map((f) => f.type === "select"
            ? `<div class="field"><label for="m-${key}-${esc(f.name)}">${esc(f.label)}</label><select class="input" id="m-${key}-${esc(f.name)}" name="${esc(f.name)}"><option value="">Unknown</option>${f.options.map((o) => `<option value="${o[0]}">${esc(o[1])}</option>`).join("")}</select></div>`
            : `<div class="field"><label for="m-${key}-${esc(f.name)}">${esc(f.label)}</label><div class="input-unit"><input class="input" id="m-${key}-${esc(f.name)}" name="${esc(f.name)}" type="number" step="${f.step ?? "any"}" min="${f.min}" max="${f.max}" ${f.default != null ? `placeholder="${f.default}"` : ""}><span>${esc(f.unit || "")}</span></div>${f.help ? `<small>${esc(f.help)}</small>` : ""}</div>`).join("")}
          <div class="field wide"><button type="submit" class="btn btn-blue">Estimate risk</button></div>
        </form>
        <div class="model-result" aria-live="polite"></div>
      </section>`).join("");
    grid.addEventListener("click", (e) => {
      const s = e.target.closest("[data-sample]");
      if (!s) return;
      const sample = state.meta.parkinsons_samples[s.dataset.sample];
      const form = $("[data-model=parkinsons] form");
      Object.entries(sample).forEach(([k, v]) => { const el = form.elements.namedItem(k); if (el) el.value = v; });
    });
    grid.addEventListener("submit", async (e) => {
      e.preventDefault();
      const card = e.target.closest("[data-model]");
      const key = card.dataset.model;
      const values = {};
      $$("input, select", e.target).forEach((el) => { if (el.name && el.value !== "") values[el.name] = Number(el.value); });
      const out = $(".model-result", card);
      out.innerHTML = `<p class="empty-note">Calculating…</p>`;
      try {
        const r = await api(`/api/predict/${key}`, values);
        state.clinical[key] = values;
        out.innerHTML = `<div class="gauges" style="grid-template-columns:1fr">${gaugeHTML(r)}</div>
          <p class="card-sub" style="margin-top:8px">${esc(r.confidence_note)} These inputs are now included in your dashboard assessment.</p>`;
      } catch (err) {
        out.innerHTML = `<p class="status-line error">${esc(err.message)}</p>`;
      }
    });
  }

  // ---------------------------------------------------------------- performance view
  let perfLoaded = false;
  async function loadPerformance() {
    if (perfLoaded) return;
    const card = $("#perfCard");
    try {
      const d = await api("/api/performance");
      if (!d.comparison || !d.comparison.length) { card.innerHTML = `<p class="empty-note">No backtest results found. Run <code>python -m ml_pipeline.train</code>.</p>`; return; }
      const names = [["accuracy", "Accuracy"], ["precision", "Precision"], ["recall", "Recall (sensitivity)"], ["f1", "F1-score"], ["roc_auc", "ROC-AUC"], ["top3_accuracy", "Top-3 accuracy"]];
      card.innerHTML = d.comparison.map((row) => `
        <div class="perf-block">
          <h3>${esc(row.model)}</h3><p class="proto">${esc(row.protocol)} · deployed model: ${esc(row.selected)}</p>
          <div style="overflow-x:auto"><table class="perf-table">
            <thead><tr><th>Metric</th><th>Before</th><th>After</th><th>Change</th><th>Relative</th></tr></thead>
            <tbody>${names.filter(([k]) => row.before[k] != null).map(([k, label]) => {
              const b = row.before[k], a = row.after[k], dpp = (a - b) * 100, rel = b ? ((a - b) / b) * 100 : 0;
              const cls = Math.abs(dpp) < 0.05 ? "flat" : dpp > 0 ? "up" : "down";
              return `<tr><td>${label}</td><td>${(b * 100).toFixed(2)}%</td><td>${(a * 100).toFixed(2)}%</td>
                <td class="delta ${cls}">${dpp >= 0 ? "+" : ""}${dpp.toFixed(2)} pp</td><td class="delta ${cls}">${rel >= 0 ? "+" : ""}${rel.toFixed(1)}%</td></tr>`;
            }).join("")}</tbody></table></div>
        </div>`).join("") +
        `<h3 style="margin:8px 0 10px">Notes on method</h3><ul class="notes">${d.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>`;
      $("#perfSub").textContent = `Legacy models compared with the upgraded pipelines on identical cross-validation folds · generated ${d.generated_at}.`;
      perfLoaded = true;
    } catch (err) {
      card.innerHTML = `<p class="status-line error">${esc(err.message)}</p>`;
    }
  }

  // ---------------------------------------------------------------- chat
  function addMsg(role, text, source) {
    const el = document.createElement("div");
    el.className = `msg ${role}`;
    el.textContent = text;
    if (source) { const s = document.createElement("span"); s.className = "src"; s.textContent = source; el.appendChild(s); }
    $("#chatLog").appendChild(el);
    $("#chatLog").scrollTop = $("#chatLog").scrollHeight;
    return el;
  }

  async function sendChat(text, { hidden = false } = {}) {
    if (state.busy) return;
    state.busy = true;
    if (!hidden) addMsg("user", text);
    const pending = addMsg("assistant", "Thinking…");
    pending.classList.add("pending");
    try {
      const d = await api("/api/chat", { message: text, history: state.chat.slice(-12), assessment: payload() });
      pending.remove();
      addMsg("assistant", d.reply, d.source === "gemini" ? "Gemini · educational information only" : "Built-in guidance · educational information only");
      if (d.notice) toast(d.notice);
      state.chat.push({ role: "user", content: text }, { role: "assistant", content: d.reply });
    } catch (err) {
      pending.remove();
      addMsg("assistant", err.message);
    } finally {
      state.busy = false;
    }
  }

  function openChat(prefill) {
    const chat = $("#chat");
    chat.classList.add("open");
    chat.setAttribute("aria-hidden", "false");
    $("#chatFab").setAttribute("aria-expanded", "true");
    $("#chatBadge").hidden = true;
    if (!$("#chatLog").children.length) {
      addMsg("assistant", "Hi, I'm your health assistant. I can explain your symptoms and lab results in plain language and help you decide what to do next. I'll ask one question at a time.");
    }
    if (prefill) sendChat(prefill);
    else if (state.chatFresh && state.result) {
      state.chatFresh = false;
      sendChat("Please summarise my latest screening results in simple terms and ask your first clarifying question.", { hidden: true });
    }
    setTimeout(() => $("#chatInput").focus(), 300);
  }

  function closeChat() {
    $("#chat").classList.remove("open");
    $("#chat").setAttribute("aria-hidden", "true");
    $("#chatFab").setAttribute("aria-expanded", "false");
    $("#chatFab").focus();
  }

  // ---------------------------------------------------------------- reset
  function resetAll() {
    state.symptoms.clear(); state.denied.clear(); state.skipped.clear();
    state.biomarkers = {}; state.clinical = {}; state.result = null; state.chat = []; state.chatFresh = false;
    syncSymptoms();
    $$("#panel-report input, #panel-report select, #panel-report textarea").forEach((el) => { if (el.type !== "file") el.value = ""; });
    $("#fileInfo").innerHTML = ""; $("#reportStatus").textContent = "";
    $("#followup").hidden = true; $("#alertBox").hidden = true;
    $("#overallPill").className = "pill neutral"; $("#overallPill").textContent = "Waiting for input";
    $("#overallBig").textContent = "–"; $("#overallSub").textContent = "Run an assessment to see your screening summary.";
    $("#gauges").innerHTML = `<p class="empty-note">Enter glucose, blood pressure or cholesterol (or use Clinical models) to see model risk.</p>`;
    $("#diffList").innerHTML = `<li><p class="empty-note">Nothing to show yet.</p></li>`;
    $("#nextSteps").innerHTML = `<li>Choose symptoms or upload a report, then run the assessment.</li>`;
    $("#biomarkerSection").hidden = true;
    $("#callouts").innerHTML = ""; $("#leaders").innerHTML = ""; $(".anchors").innerHTML = "";
    $("#stage").classList.remove("has-data"); $("#stageEmpty").hidden = false;
    $$(".organ").forEach((g) => g.classList.remove("flagged", "normal", "borderline", "high_risk"));
    $("#chatLog").innerHTML = "";
    $$(".model-result").forEach((el) => { el.innerHTML = ""; });
    closeOrganPop();
    toast("Started a new assessment.");
  }

  // ---------------------------------------------------------------- init
  async function init() {
    try {
      state.meta = await api("/api/meta");
    } catch (err) {
      toast(err.message, true);
      return;
    }
    buildSymptomPicker();
    buildMarkerInputs();
    buildModelForms();
    setMode("symptoms");

    $$(".nav button").forEach((b) => b.addEventListener("click", () => showView(b.dataset.view)));
    $$(".modes button").forEach((b) => b.addEventListener("click", () => setMode(b.dataset.mode)));
    $(".modes").addEventListener("keydown", (e) => {
      if (!["ArrowLeft", "ArrowRight"].includes(e.key)) return;
      const modes = ["symptoms", "report", "combined"];
      const next = modes[(modes.indexOf(state.mode) + (e.key === "ArrowRight" ? 1 : 2)) % 3];
      setMode(next);
      $(`.modes [data-mode="${next}"]`).focus();
    });
    $$("#stepTabs button").forEach((b) => b.addEventListener("click", () => setStep(b.dataset.step)));
    $("#runBtn").addEventListener("click", runAssessment);
    $("#resetAll").addEventListener("click", resetAll);

    $("#followup").addEventListener("click", (e) => {
      const a = e.target.closest("[data-answer]");
      if (!a) return;
      const sym = $("#followup").dataset.sym;
      if (a.dataset.answer === "yes") state.symptoms.add(sym);
      else if (a.dataset.answer === "no") state.denied.add(sym);
      else state.skipped.add(sym);
      syncSymptoms();
      runAssessment();
    });

    const drop = $("#drop"), file = $("#fileInput");
    file.addEventListener("change", () => { if (file.files[0]) uploadReport(file.files[0]); file.value = ""; });
    drop.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); file.click(); } });
    ["dragenter", "dragover"].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add("drag"); }));
    ["dragleave", "drop"].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove("drag"); }));
    drop.addEventListener("drop", (e) => { const f = e.dataTransfer.files[0]; if (f) uploadReport(f); });
    $("#parseText").addEventListener("click", async () => {
      const text = $("#reportText").value;
      try { handleExtraction(await api("/api/report", { text })); } catch (err) { $("#reportStatus").className = "status-line error"; $("#reportStatus").textContent = err.message; }
    });

    $("#callouts").addEventListener("click", (e) => {
      const c = e.target.closest(".callout");
      if (!c) return;
      if (c.getAttribute("aria-expanded") === "true") closeOrganPop();
      else openOrganPop(c.dataset.organ, c);
    });
    $(".body-svg").addEventListener("click", (e) => {
      const g = e.target.closest(".organ.flagged");
      if (g) { const c = $(`.callout[data-organ="${g.dataset.organ}"]`); if (c) openOrganPop(g.dataset.organ, c); }
    });
    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      if (!$("#organPop").hidden) closeOrganPop();
      else if ($("#chat").classList.contains("open")) closeChat();
    });
    $("#zoomIn").addEventListener("click", () => setZoom(state.zoom + 0.15));
    $("#zoomOut").addEventListener("click", () => setZoom(state.zoom - 0.15));
    $("#zoomReset").addEventListener("click", () => setZoom(1));
    let rt;
    window.addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(layoutCallouts, 120); });

    $("#chatFab").addEventListener("click", () => ($("#chat").classList.contains("open") ? closeChat() : openChat()));
    $("#chatClose").addEventListener("click", closeChat);
    $("#chatForm").addEventListener("submit", (e) => {
      e.preventDefault();
      const t = $("#chatInput").value.trim();
      if (!t) return;
      $("#chatInput").value = "";
      sendChat(t);
    });
    $("#chatInput").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("#chatForm").requestSubmit(); }
    });
    $("#chatSuggest").addEventListener("click", (e) => { const c = e.target.closest("[data-q]"); if (c) sendChat(c.dataset.q); });
  }

  document.addEventListener("DOMContentLoaded", init);
})();
