"""Backtest the legacy models, train leakage-free upgraded pipelines, and export them.

Run from the project root:

    python -m ml_pipeline.train            # full run (≈15–30 min on 2 CPUs)
    python -m ml_pipeline.train --quick    # smaller search, for smoke tests

Protocol
--------
* Every dataset is evaluated with the SAME outer stratified 5-fold splits for
  the legacy ("before") and upgraded ("after") models.
* Upgraded models are tuned with nested cross-validation: hyper-parameters and
  the model family are chosen on the training folds only, then scored on the
  untouched outer fold. All preprocessing (missing-value handling, imputation,
  scaling, encoding, SMOTE) lives inside the pipeline, so nothing is fitted on
  test data.
* Parkinson's: recordings are grouped by person (≈6 per person). Folds are
  split by person so the same voice never appears in train and test.
* Symptoms: 94% of the 4,920 rows are exact duplicates. Folds are split over
  unique symptom profiles, and models are also tested on partial, shuffled
  symptom lists (how real users enter symptoms).
* A secondary hold-out test mirrors the legacy notebooks' 80/20 split.
"""
from __future__ import annotations

import argparse
import json
import time
import warnings
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
import sklearn
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from lightgbm import LGBMClassifier
from scipy.stats import loguniform
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier, VotingClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, f1_score, precision_score, recall_score, roc_auc_score,
                             top_k_accuracy_score)
from sklearn.model_selection import (RandomizedSearchCV, StratifiedGroupKFold, StratifiedKFold,
                                     cross_validate, train_test_split)
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, PowerTransformer, StandardScaler
from sklearn.svm import SVC
from xgboost import XGBClassifier

from . import legacy
from .config import (DATA_DIR, DIABETES_FEATURES, DIABETES_ZERO_AS_MISSING, HEART_CATEGORICAL, HEART_FEATURES,
                     HEART_LEGACY_FEATURES, HEART_NUMERIC, MODEL_SPECS, MODELS_DIR, PARKINSONS_FEATURE_NAMES,
                     RANDOM_STATE, REPORTS_DIR, SYMPTOM_MODEL_FILE)
from .symptom_catalog import ALL_SYMPTOMS
from .transformers import HeartCodeCleaner, ZeroToNaN

warnings.filterwarnings("ignore")
METRICS = ["accuracy", "precision", "recall", "f1", "roc_auc"]


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------
def load_diabetes():
    df = pd.read_csv(DATA_DIR / "diabetes.csv")
    X = df[[f["name"] for f in DIABETES_FEATURES]].astype(float)
    return X, df["Outcome"].astype(int).values, None


def load_heart():
    df = pd.read_csv(DATA_DIR / "heart.csv", encoding="utf-8-sig")
    X = df[[f["name"] for f in HEART_FEATURES]].astype(float)
    y = (1 - df["target"]).astype(int).values  # label correction: 1 = heart disease
    return X, y, None


def load_parkinsons():
    df = pd.read_csv(DATA_DIR / "parkinsons.csv")
    X = df[PARKINSONS_FEATURE_NAMES].astype(float)
    groups = df["name"].str.rsplit("_", n=1).str[0].values  # one group per person
    return X, df["status"].astype(int).values, groups


# ---------------------------------------------------------------------------
# Upgraded pipelines
# ---------------------------------------------------------------------------
def make_preprocessor(dataset: str):
    if dataset == "diabetes":
        return Pipeline([("zeros", ZeroToNaN(DIABETES_ZERO_AS_MISSING)),
                         ("impute", SimpleImputer(strategy="median", add_indicator=True)),
                         ("scale", StandardScaler())])
    if dataset == "heart":
        ct = ColumnTransformer([
            ("num", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]),
             HEART_NUMERIC),
            ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                              ("onehot", OneHotEncoder(handle_unknown="ignore"))]), HEART_CATEGORICAL),
        ])
        return Pipeline([("clean", HeartCodeCleaner()), ("ct", ct)])
    if dataset == "parkinsons":
        return Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
    raise ValueError(dataset)


def candidate_spaces(dataset: str, y: np.ndarray) -> dict:
    pos = y.mean()
    spw = float((1 - pos) / pos)
    cw = [None, "balanced"]
    rs = RANDOM_STATE
    scale_opts = {"prep__scale": [StandardScaler(), PowerTransformer()]} if dataset == "parkinsons" else {}
    tree_params = {"model__n_estimators": [300, 500], "model__max_depth": [None, 4, 6, 8, 12],
                   "model__min_samples_leaf": [1, 2, 4, 8], "model__max_features": ["sqrt", 0.5, 0.8],
                   "model__class_weight": [None, "balanced", "balanced_subsample"]}
    spaces = {
        "Logistic regression": (LogisticRegression(max_iter=5000),
                                {"model__C": loguniform(1e-3, 1e2), "model__class_weight": cw}),
        "Random forest": (RandomForestClassifier(random_state=rs, n_jobs=1), tree_params),
        "Extra trees": (ExtraTreesClassifier(random_state=rs, n_jobs=1), tree_params),
        "XGBoost": (XGBClassifier(random_state=rs, n_jobs=1, eval_metric="logloss", verbosity=0),
                    {"model__n_estimators": [150, 300, 500], "model__max_depth": [2, 3, 4, 5],
                     "model__learning_rate": [0.02, 0.05, 0.1], "model__subsample": [0.7, 0.85, 1.0],
                     "model__colsample_bytree": [0.6, 0.8, 1.0], "model__min_child_weight": [1, 3, 5],
                     "model__reg_lambda": [1, 3, 10], "model__scale_pos_weight": [1.0, spw]}),
        "LightGBM": (LGBMClassifier(random_state=rs, n_jobs=1, verbose=-1, subsample_freq=1),
                     {"model__n_estimators": [150, 300, 500], "model__num_leaves": [4, 8, 15, 31],
                      "model__learning_rate": [0.02, 0.05, 0.1], "model__min_child_samples": [5, 10, 20, 40],
                      "model__subsample": [0.7, 1.0], "model__colsample_bytree": [0.6, 0.8, 1.0],
                      "model__reg_lambda": [0, 1, 5], "model__class_weight": cw}),
        "SVM (linear)": (SVC(kernel="linear", probability=True, random_state=rs),
                         {"model__C": loguniform(1e-3, 1e1), "model__class_weight": cw}),
        "SVM (RBF)": (SVC(probability=True, random_state=rs),
                      {"model__C": loguniform(1e-1, 1e2), "model__gamma": ["scale", 0.01, 0.03, 0.1],
                       "model__class_weight": cw}),
    }
    out = {}
    for name, (model, params) in spaces.items():
        out[name] = (Pipeline([("prep", make_preprocessor(dataset)), ("model", model)]), {**params, **scale_opts})
    if pos < 0.4 or pos > 0.6:  # class imbalance -> also try SMOTE inside the pipeline
        for name in ("Logistic regression", "Random forest"):
            model, params = spaces[name]
            # imblearn pipelines cannot nest Pipelines, so the preprocessing steps are inlined
            pipe = ImbPipeline(make_preprocessor(dataset).steps + [("smote", SMOTE(random_state=rs)),
                                                                   ("model", model)])
            p = {k: v for k, v in params.items() if k != "model__class_weight"}
            flat_scale = {k.replace("prep__", ""): v for k, v in scale_opts.items()}
            out[f"SMOTE + {name.lower()}"] = (pipe, {**p, "smote__k_neighbors": [3, 5], **flat_scale})
    return out


def inner_cv(groups, n_splits=4, seed=RANDOM_STATE):
    if groups is not None:
        return StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)


def repeated_inner_splits(X, y, groups, n_splits=4, n_repeats=2, seed=RANDOM_STATE):
    """Repeated (re-shuffled) inner CV: averages out split noise so selection does not chase lucky folds."""
    splits = []
    for r in range(n_repeats):
        splits += list(inner_cv(groups, n_splits=n_splits, seed=seed + 1000 * r).split(X, y, groups))
    return splits


# Simplest first. Used by the one-standard-error rule: on small datasets, prefer the simplest model whose
# inner-CV score is statistically indistinguishable from the best (Hastie, Tibshirani & Friedman, ESL 7.10).
COMPLEXITY = ["Logistic regression", "SVM (linear)", "SVM (RBF)", "SMOTE + logistic regression", "Random forest",
              "Extra trees", "SMOTE + random forest", "XGBoost", "LightGBM"]


def select_and_fit(X, y, groups, dataset, n_iter, seed=RANDOM_STATE):
    """Tune each model family on (X, y) only, then pick the best single model or soft-voting ensemble.

    Score = inner-CV accuracy + inner-CV ROC-AUC, over 2 x 4-fold repeated splits. The final pick is the
    simplest candidate within one standard error of the best score (one-standard-error rule).
    """
    splits = repeated_inner_splits(X, y, groups, seed=seed)
    results = []
    for name, (pipe, params) in candidate_spaces(dataset, y).items():
        search = RandomizedSearchCV(pipe, params, n_iter=n_iter, cv=splits, random_state=seed, n_jobs=2,
                                    scoring={"accuracy": "accuracy", "roc_auc": "roc_auc"}, refit="accuracy",
                                    error_score=np.nan)
        search.fit(X, y)
        i = search.best_index_
        acc = search.cv_results_["mean_test_accuracy"][i]
        auc = search.cv_results_["mean_test_roc_auc"][i]
        per_split = np.array([search.cv_results_[f"split{k}_test_accuracy"][i] +
                              search.cv_results_[f"split{k}_test_roc_auc"][i] for k in range(len(splits))])
        results.append({"name": name, "estimator": search.best_estimator_, "accuracy": float(acc),
                        "roc_auc": float(auc), "score": float(acc + auc),
                        "se": float(per_split.std(ddof=1) / np.sqrt(len(per_split))),
                        "params": {k: (repr(v) if not isinstance(v, (int, float, str, type(None))) else v)
                                   for k, v in search.best_params_.items()}})
    results.sort(key=lambda r: r["score"], reverse=True)
    top = results[:3]
    voting = VotingClassifier([(f"m{i}", clone(r["estimator"])) for i, r in enumerate(top)], voting="soft")
    cvres = cross_validate(voting, X, y, cv=splits, scoring=["accuracy", "roc_auc"], n_jobs=2)
    v_acc, v_auc = float(cvres["test_accuracy"].mean()), float(cvres["test_roc_auc"].mean())
    v_score = v_acc + v_auc  # accuracy and ROC-AUC weighted equally (AUC is far less noisy)
    leaderboard = [{k: r[k] for k in ("name", "accuracy", "roc_auc", "score")} for r in results]
    leaderboard.append({"name": "Soft-voting ensemble (" + ", ".join(r["name"] for r in top) + ")",
                        "accuracy": v_acc, "roc_auc": v_auc, "score": v_score})
    best = top[0]
    if v_score > best["score"]:
        best = {"name": leaderboard[-1]["name"], "score": v_score, "se": best["se"], "voting": True}
    # One-standard-error rule: simplest single model within 1 SE of the best score
    threshold = best["score"] - best["se"]
    simple = [r for r in results if r["score"] >= threshold]
    simple.sort(key=lambda r: COMPLEXITY.index(r["name"]) if r["name"] in COMPLEXITY else 99)
    if simple:
        pick = simple[0]
        chosen = pick["estimator"]
        info = {"selected": pick["name"], "params": pick["params"],
                "rule": f"simplest model within 1 SE of best ({best['name']})"}
    else:  # pragma: no cover - the best single model always qualifies
        chosen = voting.fit(X, y)
        info = {"selected": leaderboard[-1]["name"], "members": [{"name": r["name"], "params": r["params"]}
                                                               for r in top]}
    info["leaderboard"] = sorted(leaderboard, key=lambda r: r["score"], reverse=True)
    return chosen, info


def binary_scores(model, X, y) -> dict:
    pred = model.predict(X)
    if hasattr(model, "predict_proba"):
        try:
            score = model.predict_proba(X)[:, 1]
        except Exception:  # SVC without probability
            score = model.decision_function(X)
    else:
        score = model.decision_function(X)
    return {"accuracy": accuracy_score(y, pred), "precision": precision_score(y, pred, zero_division=0),
            "recall": recall_score(y, pred, zero_division=0), "f1": f1_score(y, pred, zero_division=0),
            "roc_auc": roc_auc_score(y, score)}


def summarize(fold_scores: list[dict]) -> dict:
    return {m: {"mean": float(np.mean([f[m] for f in fold_scores])),
                "std": float(np.std([f[m] for f in fold_scores]))} for m in METRICS}


def backtest_tabular(dataset, loader, legacy_factory, legacy_cols, n_iter, grouped_protocols):
    X, y, groups = loader()
    report = {"dataset": dataset, "rows": int(len(y)), "positive_rate": float(y.mean()), "protocols": {}}
    for proto_name, use_groups in grouped_protocols:
        g = groups if use_groups else None
        outer = inner_cv(g, n_splits=5, seed=RANDOM_STATE)
        before, after, chosen_names = [], [], []
        for k, (tr, te) in enumerate(outer.split(X, y, g)):
            Xtr, Xte, ytr, yte = X.iloc[tr], X.iloc[te], y[tr], y[te]
            base = legacy_factory().fit(Xtr[legacy_cols], ytr)
            before.append(binary_scores(base, Xte[legacy_cols], yte))
            model, info = select_and_fit(Xtr, ytr, g[tr] if g is not None else None, dataset, n_iter)
            after.append(binary_scores(model, Xte, yte))
            chosen_names.append(info["selected"])
            log(f"  {dataset} [{proto_name}] fold {k + 1}/5: before acc={before[-1]['accuracy']:.3f} "
                f"after acc={after[-1]['accuracy']:.3f} ({info['selected']})")
        report["protocols"][proto_name] = {"before": summarize(before), "after": summarize(after),
                                           "before_folds": before, "after_folds": after,
                                           "selected_per_fold": chosen_names}
    # Secondary hold-out test mirroring the legacy notebooks (80/20, random_state=2)
    if groups is None:
        tr, te = train_test_split(np.arange(len(y)), test_size=0.2, stratify=y, random_state=2)
    else:
        tr, te = next(StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=2).split(X, y, groups))
    base = legacy_factory().fit(X.iloc[tr][legacy_cols], y[tr])
    model, _ = select_and_fit(X.iloc[tr], y[tr], groups[tr] if groups is not None else None, dataset, n_iter)
    report["holdout"] = {"before": binary_scores(base, X.iloc[te][legacy_cols], y[te]),
                         "after": binary_scores(model, X.iloc[te], y[te]), "test_rows": int(len(te))}
    # Final production model: same selection procedure on all data
    final, info = select_and_fit(X, y, groups, dataset, n_iter)
    report["production_model"] = info
    return report, final


# ---------------------------------------------------------------------------
# Symptom -> disease model
# ---------------------------------------------------------------------------
VOCAB = ALL_SYMPTOMS


def to_multihot(symptom_lists) -> np.ndarray:
    idx = {s: i for i, s in enumerate(VOCAB)}
    X = np.zeros((len(symptom_lists), len(VOCAB)), dtype=np.float32)
    for r, syms in enumerate(symptom_lists):
        for s in syms:
            if s in idx:
                X[r, idx[s]] = 1.0
    return X


def augment(symptom_sets, labels, rng, n_aug=20):
    """Each profile plus random partial versions, teaching the model to work from incomplete input."""
    out_x, out_y = [], []
    for syms, lab in zip(symptom_sets, labels):
        syms = list(syms)
        out_x.append(syms)
        out_y.append(lab)
        for _ in range(n_aug):
            k = max(2, int(round(len(syms) * rng.uniform(0.3, 0.9))))
            out_x.append(list(rng.choice(syms, size=min(k, len(syms)), replace=False)))
            out_y.append(lab)
    return out_x, out_y


def partial_variants(symptom_lists, labels, rng, n_var=5, min_keep=3):
    out_x, out_y = [], []
    for syms, lab in zip(symptom_lists, labels):
        for _ in range(n_var):
            k = max(min_keep, int(round(len(syms) * rng.uniform(0.5, 0.8))))
            k = min(k, len(syms))
            out_x.append(list(rng.choice(syms, size=k, replace=False)))  # random subset, random order
            out_y.append(lab)
    return out_x, out_y


def symptom_candidates():
    rs = RANDOM_STATE
    return {
        "Logistic regression": LogisticRegression(C=10, max_iter=3000),
        "Random forest": RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=rs, n_jobs=2),
        "Multinomial naive Bayes": MultinomialNB(alpha=0.1),
        "Soft-voting ensemble (LR + RF + NB)": VotingClassifier(
            [("lr", LogisticRegression(C=10, max_iter=3000)),
             ("rf", RandomForestClassifier(n_estimators=300, class_weight="balanced", random_state=rs, n_jobs=2)),
             ("nb", MultinomialNB(alpha=0.1))], voting="soft"),
    }


def select_symptom_model(sets, labels, seed):
    rng = np.random.default_rng(seed)
    skf = StratifiedKFold(n_splits=4, shuffle=True, random_state=seed)
    scores = {name: [] for name in symptom_candidates()}
    labels = np.asarray(labels)
    for tr, te in skf.split(np.zeros(len(labels)), labels):
        ax, ay = augment([sets[i] for i in tr], labels[tr], rng)
        px, py = partial_variants([sets[i] for i in te], labels[te], rng)
        Xa, Xp = to_multihot(ax), to_multihot(px)
        for name, est in symptom_candidates().items():
            scores[name].append(accuracy_score(py, clone(est).fit(Xa, ay).predict(Xp)))
    board = sorted(({"name": n, "partial_accuracy": float(np.mean(v))} for n, v in scores.items()),
                   key=lambda r: r["partial_accuracy"], reverse=True)
    best = board[0]["name"]
    ax, ay = augment(sets, labels, rng)
    model = clone(symptom_candidates()[best]).fit(to_multihot(ax), ay)
    return model, {"selected": best, "leaderboard": board}


def multiclass_scores(y_true, proba, classes, pred=None) -> dict:
    classes = list(classes)
    if pred is None:
        pred = np.array([classes[i] if proba[r].sum() > 0 else "__no_prediction__"
                         for r, i in enumerate(proba.argmax(1))])
    y_true = np.asarray(y_true)
    # Rows where a model gave no answer at all carry no information -> uniform scores for ranking metrics
    proba = proba.copy()
    empty = proba.sum(1) == 0
    proba[empty] = 1.0 / len(classes)
    proba = proba / proba.sum(1, keepdims=True)
    return {"accuracy": float(accuracy_score(y_true, pred)),
            "no_answer_rate": float(empty.mean()),
            "precision": float(precision_score(y_true, pred, labels=classes, average="macro", zero_division=0)),
            "recall": float(recall_score(y_true, pred, labels=classes, average="macro", zero_division=0)),
            "f1": float(f1_score(y_true, pred, labels=classes, average="macro", zero_division=0)),
            "roc_auc": float(roc_auc_score(y_true, proba, multi_class="ovr", average="macro", labels=classes)),
            "top3_accuracy": float(top_k_accuracy_score(y_true, proba, k=3, labels=classes))}


def backtest_symptoms():
    rows = legacy.load_legacy_symptom_rows(DATA_DIR / "legacy_symptom_sets")
    rows["key"] = rows["symptoms"].apply(lambda s: "|".join(sorted(s))) + "#" + rows["disease"]
    uniq = rows.drop_duplicates("key").reset_index(drop=True)
    classes = sorted(uniq["disease"].unique())
    log(f"symptoms: {len(rows)} rows -> {len(uniq)} unique profiles, {len(classes)} diseases")
    rng = np.random.default_rng(RANDOM_STATE)
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
    pooled = {s: {"y": [], "before": [], "after": []} for s in ("full", "partial")}
    chosen = []
    for k, (tr, te) in enumerate(skf.split(uniq, uniq["disease"])):
        train_keys = set(uniq.loc[tr, "key"])
        tr_rows = rows[rows["key"].isin(train_keys)]  # legacy trains on its raw (duplicated) rows
        base = legacy.LegacyPositionalSymptomModel(classes, random_state=RANDOM_STATE).fit(
            tr_rows["symptoms"].tolist(), tr_rows["disease"].tolist())
        model, info = select_symptom_model(uniq.loc[tr, "symptoms"].tolist(), uniq.loc[tr, "disease"].values,
                                           seed=RANDOM_STATE + k)
        chosen.append(info["selected"])
        te_sets, te_y = uniq.loc[te, "symptoms"].tolist(), uniq.loc[te, "disease"].tolist()
        scenarios = {"full": (te_sets, te_y), "partial": partial_variants(te_sets, te_y, rng)}
        for s, (sx, sy) in scenarios.items():
            pooled[s]["y"] += list(sy)
            pooled[s]["before"].append(base.predict_proba(sx))
            p = model.predict_proba(to_multihot(sx))
            aligned = np.zeros((len(sx), len(classes)))
            for j, c in enumerate(model.classes_):
                aligned[:, classes.index(c)] = p[:, j]
            pooled[s]["after"].append(aligned)
        log(f"  symptoms fold {k + 1}/5 done ({info['selected']})")
    report = {"dataset": "symptoms", "rows": int(len(rows)), "unique_profiles": int(len(uniq)),
              "duplicate_share": float(1 - len(uniq) / len(rows)), "classes": len(classes), "protocols": {}}
    for s, d in pooled.items():
        report["protocols"][s] = {"before": multiclass_scores(d["y"], np.vstack(d["before"]), classes),
                                  "after": multiclass_scores(d["y"], np.vstack(d["after"]), classes),
                                  "test_cases": len(d["y"])}
    report["selected_per_fold"] = chosen
    final, info = select_symptom_model(uniq["symptoms"].tolist(), uniq["disease"].values, seed=RANDOM_STATE)
    report["production_model"] = info
    return report, final


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------
def write_markdown(results: dict) -> str:
    lines = ["# Before vs. after performance comparison", "",
             f"Generated {results['generated_at']} · scikit-learn {results['sklearn_version']}", "",
             "Primary protocol: identical outer stratified 5-fold splits for both models; upgraded models are "
             "tuned with nested CV (selection on training folds only, one-standard-error rule). Values are mean across folds. "
             "Δ = absolute change in percentage points (relative change in brackets).", ""]
    names = {"accuracy": "Accuracy", "precision": "Precision", "recall": "Recall", "f1": "F1-score",
             "roc_auc": "ROC-AUC"}
    for row in results["comparison"]:
        lines += [f"## {row['model']} — {row['protocol']}", "", "| Metric | Before | After | Δ |", "|---|---|---|---|"]
        for m, label in names.items():
            b, a = row["before"][m], row["after"][m]
            rel = (a - b) / b * 100 if b else float("nan")
            lines.append(f"| {label} | {b * 100:.2f}% | {a * 100:.2f}% | {(a - b) * 100:+.2f} pp ({rel:+.1f}%) |")
        lines += ["", f"Deployed model (selected on all data): {row['selected']}", ""]
    lines += ["## Notes", ""] + [f"- {n}" for n in results["notes"]]
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="smaller search for smoke tests")
    ap.add_argument("--only", choices=["diabetes", "heart", "parkinsons", "symptoms"], action="append")
    args = ap.parse_args()
    n_iter = 3 if args.quick else 8
    MODELS_DIR.mkdir(exist_ok=True)
    REPORTS_DIR.mkdir(exist_ok=True)
    todo = args.only or ["diabetes", "heart", "parkinsons", "symptoms"]
    out_path = REPORTS_DIR / "backtest_results.json"
    results = json.loads(out_path.read_text()) if out_path.exists() and args.only else {"models": {}}
    meta_base = {"sklearn_version": sklearn.__version__, "trained_at": datetime.now(timezone.utc).isoformat()}

    tabular = {
        "diabetes": (load_diabetes, legacy.legacy_diabetes_model, [f["name"] for f in DIABETES_FEATURES],
                     [("Stratified 5-fold CV", False)]),
        "heart": (load_heart, legacy.legacy_heart_model, HEART_LEGACY_FEATURES, [("Stratified 5-fold CV", False)]),
        "parkinsons": (load_parkinsons, legacy.legacy_parkinsons_model, PARKINSONS_FEATURE_NAMES,
                       [("Person-grouped 5-fold CV (leakage-free)", True),
                        ("Random 5-fold CV (legacy protocol, leaks people across folds)", False)]),
    }
    for name in todo:
        t0 = time.time()
        log(f"=== {name} ===")
        if name == "symptoms":
            report, final = backtest_symptoms()
            features = VOCAB
            classes = list(final.classes_)
        else:
            loader, factory, legacy_cols, protos = tabular[name]
            report, final = backtest_tabular(name, loader, factory, legacy_cols, n_iter, protos)
            features = [f["name"] for f in MODEL_SPECS[name]["features"]]
            classes = [0, 1]
        bundle = {"pipeline": final, "features": features, "classes": classes,
                  "selected": report["production_model"]["selected"], **meta_base}
        fname = SYMPTOM_MODEL_FILE if name == "symptoms" else MODEL_SPECS[name]["file"]
        joblib.dump(bundle, MODELS_DIR / fname, compress=3)
        report["seconds"] = round(time.time() - t0, 1)
        results["models"][name] = report
        log(f"saved models/{fname} in {report['seconds']}s")

    titles = {"diabetes": "Diabetes", "heart": "Heart disease", "parkinsons": "Parkinson's disease",
              "symptoms": "Symptom-based disease classifier (41 diseases)"}
    comparison = []
    for name in ["diabetes", "heart", "parkinsons", "symptoms"]:
        r = results["models"].get(name)
        if not r:
            continue
        for proto, d in r["protocols"].items():
            if name == "symptoms":
                label = {"full": "All symptoms entered (unique profiles, 5-fold)",
                         "partial": "Partial & shuffled symptoms (realistic input, 5-fold)"}[proto]
                comparison.append({"key": name, "model": titles[name], "protocol": label,
                                   "before": d["before"], "after": d["after"],
                                   "selected": r["production_model"]["selected"]})
            else:
                comparison.append({"key": name, "model": titles[name], "protocol": proto,
                                   "before": {m: v["mean"] for m, v in d["before"].items()},
                                   "after": {m: v["mean"] for m, v in d["after"].items()},
                                   "before_std": {m: v["std"] for m, v in d["before"].items()},
                                   "after_std": {m: v["std"] for m, v in d["after"].items()},
                                   "selected": r["production_model"]["selected"]})
    results.update({
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "sklearn_version": sklearn.__version__, "comparison": comparison,
        "notes": [
            "Heart: the Kaggle heart.csv stores the label inverted (target=1 is the healthy group). Both models "
            "are scored against the corrected label (1 = heart disease); the legacy app therefore reported "
            "'heart disease' for the healthier profile.",
            "Heart: the upgraded model uses all 13 features (legacy dropped resting BP, resting ECG and vessel "
            "count) and treats invalid codes (ca=4, thal=0) as missing.",
            "Diabetes: zero values for glucose, blood pressure, skin thickness, insulin and BMI are treated as "
            "missing and imputed inside the pipeline (legacy model learned from them as real zeros).",
            "Parkinson's: ≈6 recordings per person; leakage-free scores split folds by person. The random-split "
            "row is shown only to compare with the legacy notebook protocol.",
            "Model selection (tabular models): each family is tuned by randomized search on 2x4-fold repeated "
            "inner CV, then the simplest model within one standard error of the best inner score is chosen. "
            "An earlier run that always picked the top inner score overfitted on the small diabetes and "
            "Parkinson's datasets; its results are kept in reports/backtest_report_v1_selection.md.",
            "Symptoms: 94% of the 4,920 training rows are duplicates, so any random split scores ~100%. "
            "Folds here are over unique symptom profiles. The legacy model needs symptoms in a fixed order and "
            "an exact count; in the partial/shuffled test it often cannot answer.",
        ],
    })
    out_path.write_text(json.dumps(results, indent=2, default=float))
    (REPORTS_DIR / "backtest_report.md").write_text(write_markdown(results))
    log("wrote reports/backtest_results.json and reports/backtest_report.md")


if __name__ == "__main__":
    main()
