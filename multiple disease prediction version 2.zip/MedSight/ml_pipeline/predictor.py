"""Production inference: loads the exported .joblib pipelines once and serves predictions."""
from __future__ import annotations

import logging
import math
import threading

import joblib
import numpy as np
import pandas as pd

from .config import DATA_DIR, MODEL_SPECS, MODELS_DIR, SYMPTOM_MODEL_FILE
from .symptom_catalog import ALL_SYMPTOMS, disease_info, normalize_disease, normalize_symptom, symptom_label, \
    symptom_organ

log = logging.getLogger(__name__)


def risk_level(p: float) -> str:
    return "high_risk" if p >= 0.6 else "borderline" if p >= 0.3 else "normal"


class ModelRegistry:
    def __init__(self, models_dir=MODELS_DIR):
        self.models_dir = models_dir
        self._bundles: dict[str, dict] = {}
        self._lock = threading.Lock()
        self._sym_freq: pd.DataFrame | None = None

    # ------------------------------------------------------------------ loading
    def _bundle(self, name: str) -> dict:
        if name not in self._bundles:
            with self._lock:
                if name not in self._bundles:
                    fname = SYMPTOM_MODEL_FILE if name == "symptoms" else MODEL_SPECS[name]["file"]
                    self._bundles[name] = joblib.load(self.models_dir / fname)
                    log.info("loaded model %s", fname)
        return self._bundles[name]

    def warm_up(self) -> None:
        for name in [*MODEL_SPECS, "symptoms"]:
            try:
                self._bundle(name)
            except FileNotFoundError:
                log.error("model file for %s is missing; run `python -m ml_pipeline.train`", name)
        self.symptom_frequencies()

    def info(self, name: str) -> dict:
        b = self._bundle(name)
        return {"selected": b.get("selected"), "trained_at": b.get("trained_at"),
                "sklearn_version": b.get("sklearn_version")}

    # ------------------------------------------------------------------ tabular models
    def predict_tabular(self, name: str, values: dict) -> dict:
        b = self._bundle(name)
        features = b["features"]
        row = {f: (float(values[f]) if values.get(f) is not None else np.nan) for f in features}
        provided = sum(1 for f in features if not math.isnan(row[f]))
        X = pd.DataFrame([row], columns=features)
        p = float(b["pipeline"].predict_proba(X)[0, 1])
        completeness = provided / len(features)
        return {"model": name, "title": MODEL_SPECS[name]["title"], "probability": round(p, 4),
                "level": risk_level(p), "inputs_provided": provided, "inputs_total": len(features),
                "completeness": round(completeness, 2),
                "confidence_note": ("Most inputs provided." if completeness >= 0.75 else
                                    "Several inputs were missing and were filled with typical values, "
                                    "so treat this estimate with caution.")}

    # ------------------------------------------------------------------ symptom model
    def symptom_frequencies(self) -> pd.DataFrame:
        """P(symptom | disease) estimated from the unique training profiles; drives follow-up questions."""
        if self._sym_freq is None:
            df = pd.read_csv(DATA_DIR / "symptoms_train.csv")
            df = df.loc[:, ~df.columns.str.startswith("Unnamed")]
            if "fluid_overload" in df.columns and "fluid_overload.1" in df.columns:
                df = df.drop(columns=["fluid_overload"])  # all-zero duplicate column in the source data
            df.columns = [normalize_symptom(c) if c != "prognosis" else c for c in df.columns]
            df["prognosis"] = df["prognosis"].map(normalize_disease)
            df = df.drop_duplicates()
            freq = df.groupby("prognosis")[ALL_SYMPTOMS].mean().astype(float)
            self._sym_freq = freq
        return self._sym_freq

    def predict_symptoms(self, symptoms: list[str], denied: list[str] | None = None, top: int = 8) -> list[dict]:
        b = self._bundle("symptoms")
        vocab = b["features"]
        idx = {s: i for i, s in enumerate(vocab)}
        x = np.zeros((1, len(vocab)), dtype=np.float32)
        for s in symptoms:
            if s in idx:
                x[0, idx[s]] = 1.0
        proba = b["pipeline"].predict_proba(x)[0]
        classes = [normalize_disease(c) for c in b["classes"]]
        probs = dict(zip(classes, proba))
        if denied:  # a confirmed "no" lowers diseases where that symptom is common
            freq = self.symptom_frequencies()
            for d in probs:
                if d in freq.index:
                    for s in denied:
                        if s in freq.columns:
                            probs[d] *= (1 - 0.85 * float(freq.at[d, s]))
            total = sum(probs.values()) or 1.0
            probs = {d: p / total for d, p in probs.items()}
        ranked = sorted(probs.items(), key=lambda t: t[1], reverse=True)[:top]
        return [{"disease": d, **self._disease_view(d), "probability": round(float(p), 4)} for d, p in ranked]

    @staticmethod
    def _disease_view(raw: str) -> dict:
        info = disease_info(raw)
        return {"name": info["name"], "organ": info["organ"], "specialist": info["specialist"],
                "urgency": info["urgency"], "tests": info["tests"]}

    def next_question(self, symptoms: list[str], denied: list[str], k: int = 6, exclude=()) -> dict | None:
        """Pick the unasked symptom with the highest expected information gain over the top-k diseases."""
        if not symptoms:
            return None
        preds = self.predict_symptoms(symptoms, denied, top=k)
        freq = self.symptom_frequencies()
        diseases = [p["disease"] for p in preds if p["disease"] in freq.index]
        if len(diseases) < 2:
            return None
        p = np.array([next(x["probability"] for x in preds if x["disease"] == d) for d in diseases])
        p = p / p.sum()
        asked = set(symptoms) | set(denied) | set(exclude)

        def entropy(q):
            q = q[q > 0]
            return float(-(q * np.log2(q)).sum())

        h0 = entropy(p)
        best, best_gain = None, 0.0
        for s in ALL_SYMPTOMS:
            if s in asked:
                continue
            f = freq.loc[diseases, s].values * 0.9 + 0.02  # smoothed P(yes | disease)
            p_yes = float((p * f).sum())
            if p_yes <= 0 or p_yes >= 1:
                continue
            post_yes = p * f / p_yes
            post_no = p * (1 - f) / (1 - p_yes)
            gain = h0 - (p_yes * entropy(post_yes) + (1 - p_yes) * entropy(post_no))
            if gain > best_gain:
                best, best_gain = s, gain
        if best is None or best_gain < 0.02:
            return None
        related = [self._disease_view(d)["name"] for d in diseases if freq.at[d, best] > 0.5][:2]
        return {"symptom": best, "label": symptom_label(best), "organ": symptom_organ(best),
                "question": f"Do you also have {symptom_label(best).lower()}?",
                "why": ("This helps tell apart " + " and ".join(related) + ".") if related else
                       "This helps narrow down the most likely conditions.",
                "information_gain": round(best_gain, 3)}


registry = ModelRegistry()
