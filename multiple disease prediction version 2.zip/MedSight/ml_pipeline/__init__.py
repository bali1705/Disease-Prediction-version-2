"""Machine-learning package for MedSight: training, backtesting and inference."""
