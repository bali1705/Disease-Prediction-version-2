"""Symptom vocabulary, plain-language labels, body-system grouping and disease guidance.

The vocabulary is the 131 distinct symptoms of the Kaggle "Disease Symptom
Prediction" dataset used by the original project (41 diseases).
"""
from __future__ import annotations

import re

CATEGORIES: dict[str, dict] = {
    "general": {
        "title": "General", "organ": None,
        "symptoms": ["fatigue", "malaise", "lethargy", "high_fever", "mild_fever", "chills", "shivering",
                     "sweating", "weight_loss", "weight_gain", "obesity", "loss_of_appetite",
                     "increased_appetite", "excessive_hunger", "dehydration", "restlessness",
                     "toxic_look_(typhos)", "swelled_lymph_nodes", "cold_hands_and_feets"],
    },
    "neuro": {
        "title": "Head, brain & nerves", "organ": "brain",
        "symptoms": ["headache", "dizziness", "spinning_movements", "loss_of_balance", "unsteadiness",
                     "altered_sensorium", "coma", "slurred_speech", "weakness_of_one_body_side",
                     "lack_of_concentration", "visual_disturbances", "blurred_and_distorted_vision",
                     "loss_of_smell", "drying_and_tingling_lips"],
    },
    "ent": {
        "title": "Eyes, nose & throat", "organ": None,
        "symptoms": ["redness_of_eyes", "watering_from_eyes", "pain_behind_the_eyes", "sunken_eyes",
                     "yellowing_of_eyes", "puffy_face_and_eyes", "continuous_sneezing", "runny_nose",
                     "congestion", "sinus_pressure", "throat_irritation", "patches_in_throat",
                     "ulcers_on_tongue", "red_sore_around_nose"],
    },
    "respiratory": {
        "title": "Breathing & chest", "organ": "lungs",
        "symptoms": ["cough", "breathlessness", "phlegm", "mucoid_sputum", "rusty_sputum",
                     "blood_in_sputum", "chest_pain"],
    },
    "cardio": {
        "title": "Heart & circulation", "organ": "heart",
        "symptoms": ["fast_heart_rate", "palpitations", "swollen_blood_vessels", "prominent_veins_on_calf",
                     "swollen_legs", "swollen_extremeties", "fluid_overload", "bruising", "cramps"],
    },
    "digestive": {
        "title": "Stomach & digestion", "organ": "stomach",
        "symptoms": ["stomach_pain", "abdominal_pain", "belly_pain", "acidity", "indigestion", "nausea",
                     "vomiting", "diarrhoea", "constipation", "passage_of_gases", "swelling_of_stomach",
                     "distention_of_abdomen", "stomach_bleeding", "bloody_stool",
                     "pain_during_bowel_movements", "pain_in_anal_region", "irritation_in_anus"],
    },
    "liver": {
        "title": "Liver", "organ": "liver",
        "symptoms": ["yellowish_skin", "dark_urine", "yellow_urine", "acute_liver_failure"],
    },
    "urinary": {
        "title": "Urinary", "organ": "bladder",
        "symptoms": ["burning_micturition", "spotting_urination", "bladder_discomfort", "foul_smell_of_urine",
                     "continuous_feel_of_urine", "polyuria"],
    },
    "endocrine": {
        "title": "Hormones & metabolism", "organ": "thyroid",
        "symptoms": ["irregular_sugar_level", "enlarged_thyroid", "abnormal_menstruation"],
    },
    "skin": {
        "title": "Skin, hair & nails", "organ": "skin",
        "symptoms": ["itching", "skin_rash", "nodal_skin_eruptions", "dischromic_patches", "internal_itching",
                     "red_spots_over_body", "pus_filled_pimples", "blackheads", "scurring", "skin_peeling",
                     "silver_like_dusting", "small_dents_in_nails", "inflammatory_nails", "blister",
                     "yellow_crust_ooze", "brittle_nails"],
    },
    "musculoskeletal": {
        "title": "Muscles, bones & joints", "organ": "joints",
        "symptoms": ["joint_pain", "knee_pain", "hip_joint_pain", "back_pain", "neck_pain", "stiff_neck",
                     "swelling_joints", "movement_stiffness", "painful_walking", "muscle_pain",
                     "muscle_weakness", "muscle_wasting", "weakness_in_limbs"],
    },
    "mood": {
        "title": "Mood & mind", "organ": "brain",
        "symptoms": ["anxiety", "depression", "irritability", "mood_swings"],
    },
    "history": {
        "title": "History & exposures", "organ": None,
        "symptoms": ["family_history", "history_of_alcohol_consumption", "extra_marital_contacts",
                     "receiving_blood_transfusion", "receiving_unsterile_injections"],
    },
}

# Organ overrides for symptoms whose category default is not specific enough
SYMPTOM_ORGAN_OVERRIDES = {
    "irregular_sugar_level": "pancreas", "excessive_hunger": "pancreas", "polyuria": "kidneys",
    "bladder_discomfort": "bladder", "diarrhoea": "intestines", "constipation": "intestines",
    "passage_of_gases": "intestines", "bloody_stool": "intestines", "pain_during_bowel_movements": "intestines",
    "pain_in_anal_region": "intestines", "irritation_in_anus": "intestines", "belly_pain": "intestines",
    "swollen_blood_vessels": "arteries", "prominent_veins_on_calf": "arteries", "bruising": "blood",
    "fast_heart_rate": "heart", "palpitations": "heart", "chest_pain": "heart", "yellowing_of_eyes": "liver",
    "swelled_lymph_nodes": "blood", "high_fever": "blood", "obesity": "body", "weight_gain": "body",
    "weight_loss": "body",
}

LABEL_OVERRIDES = {
    "cold_hands_and_feets": "Cold hands and feet", "scurring": "Scarring",
    "swollen_extremeties": "Swollen hands or feet", "toxic_look_(typhos)": "Looking very unwell (toxic look)",
    "burning_micturition": "Burning when urinating", "spotting_urination": "Blood spots in urine",
    "polyuria": "Passing a lot of urine", "dischromic_patches": "Discoloured skin patches",
    "extra_marital_contacts": "Unprotected sexual contact", "altered_sensorium": "Confusion or reduced alertness",
    "fluid_overload": "Fluid retention", "silver_like_dusting": "Silvery skin scales",
    "nodal_skin_eruptions": "Bumpy skin eruptions", "mucoid_sputum": "Mucus-like sputum",
    "rusty_sputum": "Rust-coloured sputum", "malaise": "Feeling generally unwell",
    "irregular_sugar_level": "Irregular blood-sugar levels", "continuous_feel_of_urine": "Constant urge to urinate",
    "diarrhoea": "Diarrhoea", "phlegm": "Phlegm", "spinning_movements": "Room-spinning sensation (vertigo)",
    "history_of_alcohol_consumption": "Regular alcohol use", "receiving_unsterile_injections": "Unsterile injections",
    "receiving_blood_transfusion": "Past blood transfusion", "family_history": "Family history of the condition",
    "swelled_lymph_nodes": "Swollen lymph nodes", "distention_of_abdomen": "Bloated, swollen abdomen",
    "acute_liver_failure": "Signs of acute liver failure", "yellow_crust_ooze": "Yellow crusting or ooze on skin",
    "red_sore_around_nose": "Red sore around the nose", "drying_and_tingling_lips": "Dry, tingling lips",
    "weakness_of_one_body_side": "Weakness on one side of the body", "fast_heart_rate": "Fast heart rate",
    "pain_behind_the_eyes": "Pain behind the eyes", "stomach_bleeding": "Vomiting blood or black stools",
}

ALL_SYMPTOMS: list[str] = [s for c in CATEGORIES.values() for s in c["symptoms"]]


def normalize_symptom(name: str) -> str:
    """Canonical key used everywhere: lower-case, single underscores, de-duplicated columns merged."""
    key = re.sub(r"[\s_]+", "_", str(name).strip().lower())
    if key == "fluid_overload.1":
        key = "fluid_overload"
    return key


def symptom_label(key: str) -> str:
    return LABEL_OVERRIDES.get(key) or key.replace("_", " ").capitalize()


def symptom_organ(key: str) -> str | None:
    if key in SYMPTOM_ORGAN_OVERRIDES:
        return SYMPTOM_ORGAN_OVERRIDES[key]
    for cat in CATEGORIES.values():
        if key in cat["symptoms"]:
            return cat["organ"]
    return None


def normalize_disease(name: str) -> str:
    return re.sub(r"\s+", " ", str(name).strip())


# Guidance per disease. urgency: "routine" | "soon" | "urgent"
DISEASE_INFO: dict[str, dict] = {
    "(vertigo) Paroymsal Positional Vertigo": {
        "name": "Benign paroxysmal positional vertigo (BPPV)", "organ": "brain", "specialist": "ENT specialist",
        "urgency": "routine", "tests": ["Dix-Hallpike test", "Hearing assessment"]},
    "AIDS": {"name": "HIV / AIDS", "organ": "blood", "specialist": "Infectious-disease specialist",
             "urgency": "soon", "tests": ["HIV-1/2 antigen-antibody test", "CD4 count", "Viral load"]},
    "Acne": {"name": "Acne", "organ": "skin", "specialist": "Dermatologist", "urgency": "routine",
             "tests": ["Clinical skin exam"]},
    "Alcoholic hepatitis": {"name": "Alcoholic hepatitis", "organ": "liver", "specialist": "Hepatologist",
                            "urgency": "soon", "tests": ["Liver function tests", "GGT", "Liver ultrasound"]},
    "Allergy": {"name": "Allergy", "organ": None, "specialist": "Allergist / GP", "urgency": "routine",
                "tests": ["Skin-prick test", "Serum IgE"]},
    "Arthritis": {"name": "Arthritis", "organ": "joints", "specialist": "Rheumatologist", "urgency": "routine",
                  "tests": ["ESR / CRP", "Rheumatoid factor", "Joint X-ray"]},
    "Bronchial Asthma": {"name": "Bronchial asthma", "organ": "lungs", "specialist": "Pulmonologist",
                         "urgency": "soon", "tests": ["Spirometry", "Peak-flow monitoring"]},
    "Cervical spondylosis": {"name": "Cervical spondylosis", "organ": "joints", "specialist": "Orthopaedist",
                             "urgency": "routine", "tests": ["Neck X-ray", "MRI of the cervical spine"]},
    "Chicken pox": {"name": "Chickenpox", "organ": "skin", "specialist": "GP", "urgency": "soon",
                    "tests": ["Clinical exam", "VZV PCR if unclear"]},
    "Chronic cholestasis": {"name": "Chronic cholestasis", "organ": "liver", "specialist": "Hepatologist",
                            "urgency": "soon", "tests": ["ALP & GGT", "Bilirubin", "Abdominal ultrasound"]},
    "Common Cold": {"name": "Common cold", "organ": "lungs", "specialist": "GP", "urgency": "routine",
                    "tests": ["Usually none needed"]},
    "Dengue": {"name": "Dengue fever", "organ": "blood", "specialist": "GP / Physician", "urgency": "urgent",
               "tests": ["NS1 antigen", "Dengue IgM/IgG", "Platelet count (CBC)"]},
    "Diabetes": {"name": "Diabetes", "organ": "pancreas", "specialist": "Endocrinologist", "urgency": "soon",
                 "tests": ["Fasting glucose", "HbA1c", "Oral glucose tolerance test"]},
    "Dimorphic hemmorhoids(piles)": {"name": "Haemorrhoids (piles)", "organ": "intestines",
                                     "specialist": "General surgeon", "urgency": "routine",
                                     "tests": ["Proctoscopy"]},
    "Drug Reaction": {"name": "Drug reaction", "organ": "skin", "specialist": "GP / Dermatologist",
                      "urgency": "soon", "tests": ["Medication review"]},
    "Fungal infection": {"name": "Fungal skin infection", "organ": "skin", "specialist": "Dermatologist",
                         "urgency": "routine", "tests": ["KOH skin scraping"]},
    "GERD": {"name": "Acid reflux (GERD)", "organ": "stomach", "specialist": "Gastroenterologist",
             "urgency": "routine", "tests": ["Trial of acid suppression", "Upper endoscopy if persistent"]},
    "Gastroenteritis": {"name": "Gastroenteritis", "organ": "intestines", "specialist": "GP", "urgency": "soon",
                        "tests": ["Stool test if prolonged", "Electrolytes"]},
    "Heart attack": {"name": "Heart attack", "organ": "heart", "specialist": "Emergency care / Cardiologist",
                     "urgency": "urgent", "tests": ["ECG", "Troponin", "Echocardiogram"]},
    "Hepatitis B": {"name": "Hepatitis B", "organ": "liver", "specialist": "Hepatologist", "urgency": "soon",
                    "tests": ["HBsAg", "Anti-HBc", "HBV DNA", "Liver function tests"]},
    "Hepatitis C": {"name": "Hepatitis C", "organ": "liver", "specialist": "Hepatologist", "urgency": "soon",
                    "tests": ["Anti-HCV", "HCV RNA", "Liver function tests"]},
    "Hepatitis D": {"name": "Hepatitis D", "organ": "liver", "specialist": "Hepatologist", "urgency": "soon",
                    "tests": ["Anti-HDV", "HBsAg", "Liver function tests"]},
    "Hepatitis E": {"name": "Hepatitis E", "organ": "liver", "specialist": "Hepatologist", "urgency": "soon",
                    "tests": ["Anti-HEV IgM", "Liver function tests"]},
    "Hypertension": {"name": "High blood pressure", "organ": "heart", "specialist": "Physician / Cardiologist",
                     "urgency": "soon", "tests": ["Repeated BP readings", "Kidney function", "ECG"]},
    "Hyperthyroidism": {"name": "Overactive thyroid", "organ": "thyroid", "specialist": "Endocrinologist",
                        "urgency": "soon", "tests": ["TSH", "Free T4 / T3"]},
    "Hypoglycemia": {"name": "Low blood sugar", "organ": "pancreas", "specialist": "Endocrinologist",
                     "urgency": "urgent", "tests": ["Blood glucose during symptoms", "HbA1c"]},
    "Hypothyroidism": {"name": "Underactive thyroid", "organ": "thyroid", "specialist": "Endocrinologist",
                       "urgency": "routine", "tests": ["TSH", "Free T4"]},
    "Impetigo": {"name": "Impetigo", "organ": "skin", "specialist": "GP / Dermatologist", "urgency": "soon",
                 "tests": ["Clinical exam", "Swab culture if recurrent"]},
    "Jaundice": {"name": "Jaundice", "organ": "liver", "specialist": "Gastroenterologist", "urgency": "soon",
                 "tests": ["Bilirubin (total & direct)", "Liver function tests", "Abdominal ultrasound"]},
    "Malaria": {"name": "Malaria", "organ": "blood", "specialist": "Physician", "urgency": "urgent",
                "tests": ["Peripheral blood smear", "Malaria rapid antigen test"]},
    "Migraine": {"name": "Migraine", "organ": "brain", "specialist": "Neurologist", "urgency": "routine",
                 "tests": ["Headache diary", "Neurological exam"]},
    "Osteoarthristis": {"name": "Osteoarthritis", "organ": "joints", "specialist": "Orthopaedist",
                        "urgency": "routine", "tests": ["Joint X-ray"]},
    "Paralysis (brain hemorrhage)": {"name": "Stroke / brain haemorrhage", "organ": "brain",
                                     "specialist": "Emergency care / Neurologist", "urgency": "urgent",
                                     "tests": ["Emergency CT or MRI of the brain"]},
    "Peptic ulcer diseae": {"name": "Peptic ulcer", "organ": "stomach", "specialist": "Gastroenterologist",
                            "urgency": "soon", "tests": ["H. pylori test", "Upper endoscopy"]},
    "Pneumonia": {"name": "Pneumonia", "organ": "lungs", "specialist": "Physician / Pulmonologist",
                  "urgency": "urgent", "tests": ["Chest X-ray", "CBC", "Oxygen saturation"]},
    "Psoriasis": {"name": "Psoriasis", "organ": "skin", "specialist": "Dermatologist", "urgency": "routine",
                  "tests": ["Clinical skin exam"]},
    "Tuberculosis": {"name": "Tuberculosis", "organ": "lungs", "specialist": "Pulmonologist", "urgency": "soon",
                     "tests": ["Sputum test (CBNAAT/GeneXpert)", "Chest X-ray"]},
    "Typhoid": {"name": "Typhoid fever", "organ": "intestines", "specialist": "Physician", "urgency": "soon",
                "tests": ["Blood culture", "CBC"]},
    "Urinary tract infection": {"name": "Urinary tract infection", "organ": "bladder", "specialist": "GP / Urologist",
                                "urgency": "soon", "tests": ["Urine routine & culture"]},
    "Varicose veins": {"name": "Varicose veins", "organ": "arteries", "specialist": "Vascular surgeon",
                       "urgency": "routine", "tests": ["Venous Doppler ultrasound"]},
    "hepatitis A": {"name": "Hepatitis A", "organ": "liver", "specialist": "Physician / Hepatologist",
                    "urgency": "soon", "tests": ["Anti-HAV IgM", "Liver function tests"]},
}


def disease_info(raw_name: str) -> dict:
    key = normalize_disease(raw_name)
    info = DISEASE_INFO.get(key)
    if info is None:
        return {"name": key, "organ": None, "specialist": "GP", "urgency": "routine", "tests": []}
    return info


def catalog_for_ui() -> list[dict]:
    return [
        {"id": cid, "title": c["title"],
         "symptoms": [{"key": s, "label": symptom_label(s), "organ": symptom_organ(s)} for s in c["symptoms"]]}
        for cid, c in CATEGORIES.items()
    ]
