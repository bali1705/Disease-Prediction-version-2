"""Shared paths and feature specifications for every clinical model.

The same specs drive training, server-side input validation and the
frontend forms, so a feature can never drift between those three places.
"""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
MODELS_DIR = ROOT / "models"
REPORTS_DIR = ROOT / "reports"

RANDOM_STATE = 42

# ---------------------------------------------------------------------------
# Diabetes (Pima Indians Diabetes Database, 768 women aged 21+)
# ---------------------------------------------------------------------------
DIABETES_FEATURES = [
    {"name": "Pregnancies", "label": "Number of pregnancies", "unit": "", "min": 0, "max": 20,
     "step": 1, "default": 0, "help": "Enter 0 if not applicable."},
    {"name": "Glucose", "label": "Plasma glucose", "unit": "mg/dL", "min": 40, "max": 500, "step": 1,
     "help": "Ideally 2-hour glucose after a glucose drink (OGTT); post-meal or fasting glucose also works."},
    {"name": "BloodPressure", "label": "Diastolic blood pressure", "unit": "mmHg", "min": 30, "max": 150,
     "step": 1, "help": "The lower number of your blood-pressure reading."},
    {"name": "SkinThickness", "label": "Triceps skinfold thickness", "unit": "mm", "min": 5, "max": 100,
     "step": 1, "help": "Optional. Leave blank if unknown."},
    {"name": "Insulin", "label": "2-hour serum insulin", "unit": "µU/mL", "min": 10, "max": 900, "step": 1,
     "help": "Optional. Leave blank if unknown."},
    {"name": "BMI", "label": "Body-mass index", "unit": "kg/m²", "min": 10, "max": 70, "step": 0.1,
     "help": "Weight (kg) divided by height (m) squared."},
    {"name": "DiabetesPedigreeFunction", "label": "Family-history score", "unit": "", "min": 0.05,
     "max": 2.5, "step": 0.001, "help": "Optional. Around 0.2 with no diabetic relatives, 0.5–1.0+ with several."},
    {"name": "Age", "label": "Age", "unit": "years", "min": 1, "max": 120, "step": 1},
]
DIABETES_ZERO_AS_MISSING = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]

# ---------------------------------------------------------------------------
# Heart disease (Cleveland subset as distributed on Kaggle, 303 patients)
#
# NOTE: In this Kaggle copy the `target` column is inverted relative to the
# original UCI data (target=1 is the *healthy* group: younger, higher max
# heart rate, less ST depression, fewer blocked vessels). The training code
# therefore uses disease = 1 - target. Category codes are documented below
# exactly as they appear in this file.
# ---------------------------------------------------------------------------
HEART_FEATURES = [
    {"name": "age", "label": "Age", "unit": "years", "min": 1, "max": 120, "step": 1},
    {"name": "sex", "label": "Sex", "type": "select", "options": [[1, "Male"], [0, "Female"]]},
    {"name": "cp", "label": "Chest-pain type", "type": "select",
     "options": [[3, "Typical angina"], [1, "Atypical angina"], [2, "Non-anginal pain"],
                 [0, "No chest pain (asymptomatic)"]]},
    {"name": "trestbps", "label": "Resting systolic blood pressure", "unit": "mmHg", "min": 70, "max": 240,
     "step": 1},
    {"name": "chol", "label": "Total cholesterol", "unit": "mg/dL", "min": 80, "max": 700, "step": 1},
    {"name": "fbs", "label": "Fasting blood sugar above 120 mg/dL", "type": "select",
     "options": [[0, "No"], [1, "Yes"]]},
    {"name": "restecg", "label": "Resting ECG", "type": "select",
     "options": [[1, "Normal"], [2, "ST-T wave abnormality"], [0, "Left-ventricular hypertrophy"]]},
    {"name": "thalach", "label": "Maximum heart rate during exercise test", "unit": "bpm", "min": 60,
     "max": 230, "step": 1, "help": "From a treadmill/stress test — not your resting pulse."},
    {"name": "exang", "label": "Chest pain during exercise", "type": "select",
     "options": [[0, "No"], [1, "Yes"]]},
    {"name": "oldpeak", "label": "ST depression on exercise ECG", "unit": "mm", "min": 0, "max": 7,
     "step": 0.1},
    {"name": "slope", "label": "ST-segment slope at peak exercise", "type": "select",
     "options": [[2, "Upsloping"], [1, "Flat"], [0, "Downsloping"]]},
    {"name": "ca", "label": "Major vessels seen on fluoroscopy", "type": "select",
     "options": [[0, "0"], [1, "1"], [2, "2"], [3, "3"]]},
    {"name": "thal", "label": "Thallium stress-test result", "type": "select",
     "options": [[2, "Normal"], [1, "Fixed defect"], [3, "Reversible defect"]]},
]
HEART_NUMERIC = ["age", "trestbps", "chol", "thalach", "oldpeak"]
HEART_CATEGORICAL = ["sex", "cp", "fbs", "restecg", "exang", "slope", "ca", "thal"]
# Legacy model used only these 10 columns (dropped trestbps, restecg, ca)
HEART_LEGACY_FEATURES = ["age", "sex", "cp", "chol", "fbs", "thalach", "exang", "oldpeak", "slope", "thal"]

# ---------------------------------------------------------------------------
# Parkinson's disease (Oxford voice recordings, 195 recordings / 32 people)
# ---------------------------------------------------------------------------
PARKINSONS_FEATURE_NAMES = [
    "MDVP:Fo(Hz)", "MDVP:Fhi(Hz)", "MDVP:Flo(Hz)", "MDVP:Jitter(%)", "MDVP:Jitter(Abs)", "MDVP:RAP",
    "MDVP:PPQ", "Jitter:DDP", "MDVP:Shimmer", "MDVP:Shimmer(dB)", "Shimmer:APQ3", "Shimmer:APQ5",
    "MDVP:APQ", "Shimmer:DDA", "NHR", "HNR", "RPDE", "DFA", "spread1", "spread2", "D2", "PPE",
]
PARKINSONS_LABELS = {
    "MDVP:Fo(Hz)": "Average vocal pitch (Hz)", "MDVP:Fhi(Hz)": "Maximum vocal pitch (Hz)",
    "MDVP:Flo(Hz)": "Minimum vocal pitch (Hz)", "MDVP:Jitter(%)": "Jitter (%)",
    "MDVP:Jitter(Abs)": "Jitter (absolute)", "MDVP:RAP": "Jitter RAP", "MDVP:PPQ": "Jitter PPQ",
    "Jitter:DDP": "Jitter DDP", "MDVP:Shimmer": "Shimmer", "MDVP:Shimmer(dB)": "Shimmer (dB)",
    "Shimmer:APQ3": "Shimmer APQ3", "Shimmer:APQ5": "Shimmer APQ5", "MDVP:APQ": "Shimmer APQ",
    "Shimmer:DDA": "Shimmer DDA", "NHR": "Noise-to-harmonics ratio", "HNR": "Harmonics-to-noise ratio",
    "RPDE": "RPDE (signal complexity)", "DFA": "DFA (fractal scaling)", "spread1": "Spread 1",
    "spread2": "Spread 2", "D2": "Correlation dimension D2", "PPE": "Pitch period entropy",
}
PARKINSONS_FEATURES = [
    {"name": n, "label": PARKINSONS_LABELS[n], "unit": "", "min": -20, "max": 700, "step": "any"}
    for n in PARKINSONS_FEATURE_NAMES
]

MODEL_SPECS = {
    "diabetes": {"title": "Diabetes", "features": DIABETES_FEATURES, "file": "diabetes_pipeline.joblib"},
    "heart": {"title": "Heart disease", "features": HEART_FEATURES, "file": "heart_pipeline.joblib"},
    "parkinsons": {"title": "Parkinson's disease", "features": PARKINSONS_FEATURES,
                   "file": "parkinsons_pipeline.joblib"},
}
SYMPTOM_MODEL_FILE = "symptom_pipeline.joblib"
