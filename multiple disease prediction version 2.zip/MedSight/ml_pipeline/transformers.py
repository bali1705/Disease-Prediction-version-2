"""Custom, picklable preprocessing steps used inside the scikit-learn pipelines.

They live in their own module so joblib can import them at inference time.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class ZeroToNaN(BaseEstimator, TransformerMixin):
    """Treat physiologically impossible zeros (e.g. glucose = 0) as missing values."""

    def __init__(self, columns=None):
        self.columns = columns

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = pd.DataFrame(X).copy()
        for col in self.columns or []:
            if col in X.columns:
                X[col] = X[col].astype(float).replace(0.0, np.nan)
        return X


class HeartCodeCleaner(BaseEstimator, TransformerMixin):
    """Map invalid category codes in the Kaggle heart data to missing.

    `ca` = 4 and `thal` = 0 do not exist in the original UCI coding; they mark
    unknown values and are imputed downstream instead of being learned as
    real categories.
    """

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X = pd.DataFrame(X).copy()
        if "ca" in X.columns:
            X["ca"] = X["ca"].astype(float).where(X["ca"].astype(float) <= 3)
        if "thal" in X.columns:
            X["thal"] = X["thal"].astype(float).where(X["thal"].astype(float) >= 1)
        return X
