"""Faithful reproductions of the original project's models, used only for backtesting.

These mirror the notebooks / app.py of the legacy system exactly so the
"before" numbers are an honest baseline:
  * diabetes  -> svm.SVC(kernel="linear") on raw features
  * heart     -> LogisticRegression() on 10 of 13 features, no scaling
  * parkinson -> svm.SVC(kernel="linear") on raw features
  * symptoms  -> RandomForestClassifier per symptom count, symptoms encoded as
                 integer IDs by their *position* in the user's list
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from .symptom_catalog import normalize_disease, normalize_symptom

# Copied verbatim from the legacy app.py
LEGACY_SYMPTOM_CODES = {'abdominal_pain': 1, 'abnormal_menstruation': 2, 'acidity': 3, 'acute_liver_failure': 4,
    'altered_sensorium': 5, 'anxiety': 6, 'back_pain': 7, 'belly_pain': 8, 'blackheads': 9, 'bladder_discomfort': 10,
    'blister': 11, 'blood_in_sputum': 12, 'bloody_stool': 13, 'blurred_and_distorted_vision': 14,
    'breathlessness': 15, 'brittle_nails': 16, 'bruising': 17, 'burning_micturition': 18, 'chest_pain': 19,
    'chills': 20, 'cold_hands_and_feets': 21, 'coma': 22, 'congestion': 23, 'constipation': 24,
    'continuous_feel_of_urine': 25, 'continuous_sneezing': 26, 'cough': 27, 'cramps': 28, 'dark_urine': 29,
    'dehydration': 30, 'depression': 31, 'diarrhoea': 32, 'dischromic patches': 33, 'distention_of_abdomen': 34,
    'dizziness': 35, 'drying_and_tingling_lips': 36, 'enlarged_thyroid': 37, 'excessive_hunger': 38,
    'extra_marital_contacts': 39, 'family_history': 40, 'fast_heart_rate': 41, 'fatigue': 42, 'fluid_overload': 43,
    'fluid_overload.1': 44, 'foul_smell_of urine': 45, 'headache': 46, 'high_fever': 47, 'hip_joint_pain': 48,
    'history_of_alcohol_consumption': 49, 'increased_appetite': 50, 'indigestion': 51, 'inflammatory_nails': 52,
    'internal_itching': 53, 'irregular_sugar_level': 54, 'irritability': 55, 'irritation_in_anus': 56,
    'itching': 57, 'joint_pain': 58, 'knee_pain': 59, 'lack_of_concentration': 60, 'lethargy': 61,
    'loss_of_appetite': 62, 'loss_of_balance': 63, 'loss_of_smell': 64, 'malaise': 65, 'mild_fever': 66,
    'mood_swings': 67, 'movement_stiffness': 68, 'mucoid_sputum': 69, 'muscle_pain': 70, 'muscle_wasting': 71,
    'muscle_weakness': 72, 'nausea': 73, 'neck_pain': 74, 'nodal_skin_eruptions': 75, 'obesity': 76,
    'pain_behind_the_eyes': 77, 'pain_during_bowel_movements': 78, 'pain_in_anal_region': 79, 'painful_walking': 80,
    'palpitations': 81, 'passage_of_gases': 82, 'patches_in_throat': 83, 'phlegm': 84, 'polyuria': 85,
    'prognosis': 86, 'prominent_veins_on_calf': 87, 'puffy_face_and_eyes': 88, 'pus_filled_pimples': 89,
    'receiving_blood_transfusion': 90, 'receiving_unsterile_injections': 91, 'red_sore_around_nose': 92,
    'red_spots_over_body': 93, 'redness_of_eyes': 94, 'restlessness': 95, 'runny_nose': 96, 'rusty_sputum': 97,
    'scurring': 98, 'shivering': 99, 'silver_like_dusting': 100, 'sinus_pressure': 101, 'skin_peeling': 102,
    'skin_rash': 103, 'slurred_speech': 104, 'small_dents_in_nails': 105, 'spinning_movements': 106,
    'spotting urination': 107, 'stiff_neck': 108, 'stomach_bleeding': 109, 'stomach_pain': 110, 'sunken_eyes': 111,
    'sweating': 112, 'swelled_lymph_nodes': 113, 'swelling_joints': 114, 'swelling_of_stomach': 115,
    'swollen_blood_vessels': 116, 'swollen_extremeties': 117, 'swollen_legs': 118, 'throat_irritation': 119,
    'toxic_look_(typhos)': 120, 'ulcers_on_tongue': 121, 'unsteadiness': 122, 'visual_disturbances': 123,
    'vomiting': 124, 'watering_from_eyes': 125, 'weakness_in_limbs': 126, 'weakness_of_one_body_side': 127,
    'weight_gain': 128, 'weight_loss': 129, 'yellow_crust_ooze': 130, 'yellow_urine': 131, 'yellowing_of_eyes': 132,
    'yellowish_skin': 133}
LEGACY_DISEASE_CODES = {'(vertigo) Paroymsal  Positional Vertigo': 0, 'AIDS': 1, 'Acne': 2, 'Alcoholic hepatitis': 3,
    'Allergy': 4, 'Arthritis': 5, 'Bronchial Asthma': 6, 'Cervical spondylosis': 7, 'Chicken pox': 8,
    'Chronic cholestasis': 9, 'Common Cold': 10, 'Dengue': 11, 'Diabetes ': 12, 'Dimorphic hemmorhoids(piles)': 13,
    'Drug Reaction': 14, 'Fungal infection': 15, 'GERD': 16, 'Gastroenteritis': 17, 'Heart attack': 18,
    'Hepatitis B': 19, 'Hepatitis C': 20, 'Hepatitis D': 21, 'Hepatitis E': 22, 'Hypertension ': 23,
    'Hyperthyroidism': 24, 'Hypoglycemia': 25, 'Hypothyroidism': 26, 'Impetigo': 27, 'Jaundice': 28, 'Malaria': 29,
    'Migraine': 30, 'Osteoarthristis': 31, 'Paralysis (brain hemorrhage)': 32, 'Peptic ulcer diseae': 33,
    'Pneumonia': 34, 'Psoriasis': 35, 'Tuberculosis': 36, 'Typhoid': 37, 'Urinary tract infection': 38,
    'Varicose veins': 39, 'hepatitis A': 40}

CODE_TO_SYMPTOM = {code: normalize_symptom(name) for name, code in LEGACY_SYMPTOM_CODES.items()}
SYMPTOM_TO_CODE = {}
for _name, _code in LEGACY_SYMPTOM_CODES.items():
    SYMPTOM_TO_CODE.setdefault(normalize_symptom(_name), _code)
CODE_TO_DISEASE = {code: normalize_disease(name) for name, code in LEGACY_DISEASE_CODES.items()}


def legacy_diabetes_model():
    return svm.SVC(kernel="linear")


def legacy_heart_model():
    return LogisticRegression()


def legacy_parkinsons_model():
    return svm.SVC(kernel="linear")


def load_legacy_symptom_rows(legacy_dir) -> pd.DataFrame:
    """Read Health_Disease_M3..M17.csv into rows of (ordered symptom list, disease)."""
    rows = []
    for n in range(3, 18):
        df = pd.read_csv(legacy_dir / f"Health_Disease_M{n}.csv")
        sym_cols = [f"symptom{i + 1}" for i in range(n)]
        for codes, label in zip(df[sym_cols].values.tolist(), df["prognosis"].tolist()):
            rows.append({"symptoms": [CODE_TO_SYMPTOM[int(c)] for c in codes],
                         "disease": CODE_TO_DISEASE[int(label)]})
    return pd.DataFrame(rows)


class LegacyPositionalSymptomModel:
    """One RandomForest per symptom count; features are symptom IDs in list order (legacy behaviour)."""

    def __init__(self, classes, random_state=None):
        self.classes = list(classes)
        self.random_state = random_state
        self.models: dict[int, RandomForestClassifier] = {}

    def fit(self, symptom_lists, diseases):
        by_len: dict[int, tuple[list, list]] = {}
        for syms, dis in zip(symptom_lists, diseases):
            by_len.setdefault(len(syms), ([], []))
            by_len[len(syms)][0].append([SYMPTOM_TO_CODE[s] for s in syms])
            by_len[len(syms)][1].append(dis)
        for n, (X, y) in by_len.items():
            self.models[n] = RandomForestClassifier(random_state=self.random_state).fit(np.array(X), y)
        return self

    def predict_proba(self, symptom_lists) -> np.ndarray:
        out = np.zeros((len(symptom_lists), len(self.classes)))
        idx = {c: i for i, c in enumerate(self.classes)}
        for r, syms in enumerate(symptom_lists):
            model = self.models.get(len(syms))
            if model is None:  # legacy app has no model for this symptom count -> no usable answer
                continue
            p = model.predict_proba(np.array([[SYMPTOM_TO_CODE[s] for s in syms]]))[0]
            for cls, prob in zip(model.classes_, p):
                out[r, idx[cls]] = prob
        return out
